<?php
// Habilitar reporte de errores (SOLO EN DESARROLLO)
error_reporting(E_ALL);
ini_set('display_errors', 1);

$page = 'login';

// Verificar configuración
$configPath = __DIR__ . '/server/config.php';
if (!file_exists($configPath)) {
    die("❌ Error: No se encontró server/config.php");
}
require_once $configPath;
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Iniciar sesión - BarberMonkey">
    <meta name="csrf-token" content="<?= generateCsrfToken() ?>">

    <title>Login - BarberMonkey</title>

    <!-- CSS con rutas relativas al proyecto /P/ -->
    <link rel="stylesheet" href="/P/css/base.css">
    <link rel="stylesheet" href="/P/css/styles.css">
    <link rel="stylesheet" href="/P/css/animations.css">

    <!-- Estilos inline como fallback -->
    <style>
        body {
            background: #121212;
            color: #e0e0e0;
            font-family: 'Segoe UI', system-ui, sans-serif;
            margin: 0;
            padding: 0;
        }

        .auth-page {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
        }

        .auth-container {
            width: 100%;
            max-width: 450px;
        }

        .auth-card {
            background: #1e1e1e;
            padding: 2.5rem;
            border-radius: 16px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
        }

        .logo {
            font-size: 2rem;
            font-weight: bold;
            color: #d4af37;
            text-decoration: none;
            display: block;
            text-align: center;
            margin-bottom: 2rem;
        }

        .auth-header {
            text-align: center;
            margin-bottom: 2rem;
        }

        .auth-header h1 {
            color: #d4af37;
            margin: 1rem 0 0.5rem;
        }

        .auth-header p {
            color: #888;
            margin-bottom: 2rem;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
        }

        .form-group input {
            width: 100%;
            padding: 0.8rem;
            border-radius: 4px;
            border: 1px solid #444;
            background: #2a2a2a;
            color: #e0e0e0;
            font-size: 1rem;
            box-sizing: border-box;
        }

        .form-group input:focus {
            outline: none;
            border-color: #d4af37;
        }

        .btn {
            width: 100%;
            padding: 1rem;
            background: #d4af37;
            color: #000;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            font-size: 1.1rem;
        }

        .btn:hover {
            opacity: 0.9;
        }

        .auth-footer {
            text-align: center;
            margin-top: 1.5rem;
            color: #888;
        }

        .auth-footer a {
            color: #d4af37;
            text-decoration: none;
        }

        .error-msg {
            color: #e57373;
            font-size: 0.8rem;
            margin-top: 0.3rem;
        }

        #login-message {
            margin-top: 1rem;
            padding: 1rem;
            border-radius: 8px;
            text-align: center;
            display: none;
        }

        #login-message.success {
            background: #81c784;
            color: #000;
            display: block;
        }

        #login-message.error {
            background: #e57373;
            color: #fff;
            display: block;
        }
    </style>
</head>

<body class="auth-page">
    <div class="auth-container">
        <div class="auth-card">
            <a href="/P/index.php" class="logo">🐒 BarberMonkey</a>

            <div class="auth-header">
                <h1>Iniciar Sesión</h1>
                <p>Accede a tu cuenta para gestionar tus citas</p>
            </div>

            <form id="login-form" novalidate>
                <div class="form-group">
                    <label for="login-email">Correo Electrónico</label>
                    <input type="email" id="login-email" name="email" required autocomplete="email" placeholder="tu@email.com">
                    <span class="error-msg" id="login-email-error"></span>
                </div>

                <div class="form-group">
                    <label for="login-password">Contraseña</label>
                    <input type="password" id="login-password" name="password" required autocomplete="current-password" placeholder="••••••••">
                    <span class="error-msg" id="login-password-error"></span>
                </div>

                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem;font-size:0.9rem;">
                    <label style="display:flex;align-items:center;gap:0.5rem;cursor:pointer;">
                        <input type="checkbox" id="remember-me" name="remember">
                        <span>Recordarme</span>
                    </label>
                    <a href="/P/recovery.php" style="color:#d4af37;text-decoration:none;">¿Olvidaste tu contraseña?</a>
                </div>

                <button type="submit" class="btn">🔐 Ingresar</button>
            </form>

            <p class="auth-footer">
                ¿No tienes cuenta? <a href="/P/register.php">Regístrate aquí</a>
            </p>

            <div id="login-message" role="alert" aria-live="polite"></div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('login-form');
            const msgEl = document.getElementById('login-message');

            if (!form) return console.error('❌ Formulario NO encontrado');

            form.addEventListener('submit', async function(e) {
                e.preventDefault();
                if (msgEl) {
                    msgEl.textContent = '';
                    msgEl.className = '';
                    msgEl.style.display = 'none';
                }

                const email = document.getElementById('login-email')?.value.trim();
                const pass = document.getElementById('login-password')?.value;
                if (!email || !pass) return showError('Completa todos los campos');

                console.log('📡 Login:', email);
                const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';

                try {
                    const response = await fetch('/P/server/api.php?route=auth/login', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-Token': csrfToken
                        },
                        body: JSON.stringify({
                            email,
                            password: pass
                        }),
                        credentials: 'same-origin'
                    });

                    const rawText = await response.text();
                    console.log('📥 Status:', response.status);
                    console.log('📥 Raw:', rawText.substring(0, 300));

                    let result;
                    try {
                        result = JSON.parse(rawText);
                    } catch (parseErr) {
                        return showError('Respuesta inválida del servidor');
                    }


                    // ✅ Aceptar ambos formatos de respuesta: {success: true} o {status: 'success'}
                    const isSuccess = result.success === true || result.status === 'success';
                    if (!isSuccess) {
                        return showError(result.error || result.message || `Error ${response.status}`);
                    }

                    // ✅ Guardar token si existe
                    if (result.access_token) {
                        localStorage.setItem('bm_access_token', result.access_token);
                    }

                    // ✅ Mostrar éxito
                    showSuccess(result.message || '¡Bienvenido!');

                    // ✅ Redirección robusta (aceptar rutas relativas o absolutas)
                    let redirectUrl = result.redirect || '/P/index.php';
                    if (!redirectUrl.startsWith('/')) {
                        redirectUrl = '/P/' + redirectUrl;
                    }

                    console.log('🔄 Redirigiendo a:', redirectUrl);
                    setTimeout(() => {
                        window.location.href = redirectUrl;
                    }, 1000);

                } catch (err) {
                    console.error('❌ Fetch error:', err);
                    showError(err.message || 'Error de conexión');
                }
            });

            function showError(msg) {
                console.error('❌', msg);
                if (msgEl) {
                    msgEl.textContent = '❌ ' + msg;
                    msgEl.className = 'error';
                    msgEl.style.cssText = 'display:block;background:#e57373;color:#fff;padding:1rem;border-radius:8px;margin-top:1rem;text-align:center;';
                }
            }

            function showSuccess(msg) {
                console.log('✅', msg);
                if (msgEl) {
                    msgEl.textContent = '✅ ' + msg;
                    msgEl.className = 'success';
                    msgEl.style.cssText = 'display:block;background:#81c784;color:#000;padding:1rem;border-radius:8px;margin-top:1rem;text-align:center;';
                }
            }
        });
    </script>

    <!-- app.js se carga al final para funcionalidad extra (sin interferir) -->
    <script type="module" src="/P/js/app.js"></script>
</body>

</html>