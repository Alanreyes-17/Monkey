-- 1. CREACIÓN DE LA BASE DE DATOS
-- 1. BASE DE DATOS
CREATE DATABASE IF NOT EXISTS barbermonkey_auth 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE barbermonkey_auth;

-- 2. ROLES
CREATE TABLE roles (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name ENUM('admin', 'editor', 'user') NOT NULL UNIQUE,
    description VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 3. USERS
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100),
    phone VARCHAR(20),
    avatar_url VARCHAR(255),
    role_id INT DEFAULT 3,
    is_active BOOLEAN DEFAULT FALSE,
    is_verified BOOLEAN DEFAULT FALSE,
    mfa_enabled BOOLEAN DEFAULT FALSE,
    secret_question_id INT,
    preferences JSON,
    last_login_at TIMESTAMP NULL DEFAULT NULL,
    failed_login_attempts INT DEFAULT 0,
    locked_until TIMESTAMP NULL DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE SET NULL,
    INDEX idx_email (email)
) ENGINE=InnoDB;

-- 4. SESSIONS (Modificado para evitar el error)
CREATE TABLE sessions (
    id VARCHAR(64) PRIMARY KEY,
    user_id INT NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    user_agent TEXT NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NULL DEFAULT NULL, -- Cambiado para compatibilidad
    device_name VARCHAR(100),
    location VARCHAR(100),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 5. REFRESH TOKENS
CREATE TABLE refresh_tokens (
    id INT PRIMARY KEY AUTO_INCREMENT,
    token_hash VARCHAR(64) UNIQUE NOT NULL,
    token_id VARCHAR(32) UNIQUE NOT NULL,
    user_id INT NOT NULL,
    audience VARCHAR(100) DEFAULT 'barbermonkey',
    revoked BOOLEAN DEFAULT FALSE,
    revoked_at TIMESTAMP NULL DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NULL DEFAULT NULL, -- Cambiado
    ip_address VARCHAR(45),
    user_agent TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 6. PASSWORD RESETS
CREATE TABLE password_resets (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    token VARCHAR(64) UNIQUE NOT NULL,
    used BOOLEAN DEFAULT FALSE,
    used_at TIMESTAMP NULL DEFAULT NULL,
    expires_at TIMESTAMP NULL DEFAULT NULL, -- Cambiado
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    requested_ip VARCHAR(45),
    requested_user_agent TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 7. MFA CODES
CREATE TABLE mfa_codes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    code VARCHAR(6) NOT NULL,
    type ENUM('auth', 'sms_recovery', 'call_recovery', 'email_recovery') DEFAULT 'auth',
    used BOOLEAN DEFAULT FALSE,
    used_at TIMESTAMP NULL DEFAULT NULL,
    expires_at TIMESTAMP NULL DEFAULT NULL, -- Cambiado
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    sent_to VARCHAR(100),
    attempts INT DEFAULT 0,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 8. SECRET QUESTIONS
CREATE TABLE secret_questions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT UNIQUE NOT NULL,
    question_hash VARCHAR(255) NOT NULL,
    answer_hash VARCHAR(255) NOT NULL,
    max_attempts INT DEFAULT 3,
    failed_attempts INT DEFAULT 0,
    locked_until TIMESTAMP NULL DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 9. EMAIL VERIFICATIONS
CREATE TABLE email_verifications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    token VARCHAR(64) UNIQUE NOT NULL,
    used BOOLEAN DEFAULT FALSE,
    used_at TIMESTAMP NULL DEFAULT NULL,
    expires_at TIMESTAMP NULL DEFAULT NULL, -- Cambiado
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    requested_ip VARCHAR(45),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 10. TOKEN BLACKLIST
CREATE TABLE token_blacklist (
    id INT PRIMARY KEY AUTO_INCREMENT,
    jti VARCHAR(64) UNIQUE NOT NULL,
    expires_at TIMESTAMP NULL DEFAULT NULL, -- Cambiado
    reason VARCHAR(100) DEFAULT 'user_logout',
    blacklisted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    blacklisted_by INT NULL
) ENGINE=InnoDB;

-- 11. SECURITY LOGS
CREATE TABLE security_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NULL,
    action VARCHAR(100) NOT NULL,
    ip_address VARCHAR(45),
    user_agent TEXT,
    context TEXT,
    status ENUM('success', 'failed', 'blocked') DEFAULT 'success',
    error_message TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- 12. CITAS
CREATE TABLE citas (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NULL,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    servicio VARCHAR(50) NOT NULL,
    barbero VARCHAR(50),
    fecha_servicio DATETIME NULL DEFAULT NULL,
    estado ENUM('Pendiente', 'Confirmado', 'En-curso', 'Completado', 'Cancelado', 'No-show') DEFAULT 'Pendiente',
    notas TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- 13. DATA
INSERT INTO roles (name, description) VALUES 
('admin', 'Acceso completo al sistema'),
('editor', 'Puede gestionar citas y contenido'),
('user', 'Usuario estándar');

INSERT INTO users (username, email, password_hash, role_id, is_active, is_verified, full_name) VALUES
('admin', 'admin@barbermonkey.com', '$2y$12$KIXxPZv8qJZ9qJZ9qJZ9qO8xKIXxPZv8qJZ9qJZ9qJZ9qJZ9qJZ9q', 1, TRUE, TRUE, 'Administrador');