<?php
session_start();
require_once __DIR__ . '/server/config.php';

if (!isset($_SESSION['user_id']) && !isset($_COOKIE['access_token'])) {
    header('Location: /P/login.php');
    exit;
}

// Obtener user_id
$userId = $_SESSION['user_id'] ?? null;
if (!$userId && isset($_COOKIE['access_token'])) {
    require_once __DIR__ . '/server/services/JWTService.php';
    $payload = JWTService::decode($_COOKIE['access_token']);
    $userId = $payload['id'] ?? null;
}

// Cancelar cita si se solicita
if (isset($_GET['cancelar']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $citaId = (int)$_GET['cancelar'];
    $stmt = $pdo->prepare("UPDATE citas SET estado = 'Cancelado' WHERE id = ? AND user_id = ?");
    $stmt->execute([$citaId, $userId]);
    header('Location: /P/mis-citas.php');
    exit;
}

// Obtener citas del usuario
$stmt = $pdo->prepare("
    SELECT * FROM citas 
    WHERE user_id = ? 
    ORDER BY fecha_servicio DESC, created_at DESC
");
$stmt->execute([$userId]);
$citas = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Citas - BarberMonkey</title>
    <style>
        body { background: #121212; color: #e0e0e0; font-family: system-ui, sans-serif; margin: 0; }
        .header { background: #1e1e1e; padding: 1rem 2rem; border-bottom: 2px solid #d4af37; display: flex; justify-content: space-between; align-items: center; }
        .logo { color: #d4af37; font-size: 1.5rem; font-weight: bold; text-decoration: none; }
        .container { max-width: 1000px; margin: 2rem auto; padding: 2rem; background: #1e1e1e; border-radius: 16px; }
        h1 { color: #d4af37; margin-bottom: 1.5rem; }
        .cita-card { background: #2a2a2a; padding: 1.5rem; border-radius: 12px; margin-bottom: 1rem; border-left: 4px solid #d4af37; }
        .cita-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; }
        .servicio { font-size: 1.2rem; font-weight: bold; color: #d4af37; }
        .estado { padding: 0.3rem 0.8rem; border-radius: 4px; font-size: 0.9rem; font-weight: bold; }
        .estado.Pendiente { background: #ffb74d; color: #000; }
        .estado.Confirmado { background: #81c784; color: #000; }
        .estado.Completado { background: #4fc3f7; color: #000; }
        .estado.Cancelado { background: #e57373; color: #fff; }
        .cita-info { color: #888; margin-bottom: 0.5rem; }
        .btn { padding: 0.5rem 1rem; border-radius: 4px; text-decoration: none; display: inline-block; cursor: pointer; border: none; }
        .btn-danger { background: #e57373; color: #fff; }
        .btn-primary { background: #d4af37; color: #000; }
        .empty { text-align: center; padding: 3rem; color: #888; }
    </style>
</head>
<body>
    <header class="header">
        <a href="/P/dashboard/user.php" class="logo">🐒 BarberMonkey</a>
        <a href="/P/citas.php" class="btn btn-primary">+ Nueva Cita</a>
    </header>

    <div class="container">
        <h1>📋 Mis Citas</h1>

        <?php if (empty($citas)): ?>
            <div class="empty">
                <p>No tienes citas programadas</p>
                <a href="/P/citas.php" class="btn btn-primary" style="margin-top:1rem;">Agendar tu primera cita</a>
            </div>
        <?php else: ?>
            <?php foreach ($citas as $cita): ?>
                <div class="cita-card">
                    <div class="cita-header">
                        <span class="servicio"><?= htmlspecialchars($cita['servicio']) ?></span>
                        <span class="estado <?= $cita['estado'] ?>"><?= $cita['estado'] ?></span>
                    </div>
                    <div class="cita-info">
                        📅 <?= date('d/m/Y', strtotime($cita['fecha_servicio'])) ?> 
                        ⏰ <?= date('H:i', strtotime($cita['fecha_servicio'])) ?>
                    </div>
                    <?php if ($cita['notas']): ?>
                        <div class="cita-info">📝 <?= htmlspecialchars($cita['notas']) ?></div>
                    <?php endif; ?>
                    <?php if ($cita['estado'] === 'Pendiente'): ?>
                        <form method="POST" style="display:inline;" onsubmit="return confirm('¿Cancelar esta cita?')">
                            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                            <button type="submit" name="cancelar" value="<?= $cita['id'] ?>" class="btn btn-danger">Cancelar Cita</button>
                        </form>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</body>
</html>