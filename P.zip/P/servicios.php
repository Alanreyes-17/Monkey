<?php
session_start();
require_once __DIR__ . '/server/config.php';

// Servicios disponibles
$servicios = [
    [
        'nombre' => 'Corte de Pelo Clásico',
        'precio' => 150,
        'duracion' => '30 min',
        'descripcion' => 'Corte tradicional adaptado a tu estilo',
        'icon' => '✂️'
    ],
    [
        'nombre' => 'Arreglo de Barba',
        'precio' => 100,
        'duracion' => '20 min',
        'descripcion' => 'Perfilado y arreglo completo de barba',
        'icon' => '🧔'
    ],
    [
        'nombre' => 'Afeitado Clásico',
        'precio' => 80,
        'duracion' => '25 min',
        'descripcion' => 'Afeitado tradicional con navaja y toalla caliente',
        'icon' => '🪒'
    ],
    [
        'nombre' => 'Corte + Barba',
        'precio' => 220,
        'duracion' => '50 min',
        'descripcion' => 'Servicio completo de corte y barba',
        'icon' => '👑'
    ],
    [
        'nombre' => 'Rapeado',
        'precio' => 100,
        'duracion' => '20 min',
        'descripcion' => 'Rapeado completo con máquina',
        'icon' => '⚡'
    ],
    [
        'nombre' => 'Degradado/Fade',
        'precio' => 180,
        'duracion' => '40 min',
        'descripcion' => 'Degradado perfecto de bajo a alto',
        'icon' => '📐'
    ],
    [
        'nombre' => 'Diseño de Cejas',
        'precio' => 50,
        'duracion' => '10 min',
        'descripcion' => 'Perfilado y limpieza de cejas',
        'icon' => '👁️'
    ],
    [
        'nombre' => 'Tratamiento Capilar',
        'precio' => 120,
        'duracion' => '30 min',
        'descripcion' => 'Hidratación y cuidado del cabello',
        'icon' => '💆'
    ]
];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Servicios - BarberMonkey</title>
    <style>
        body { background: #121212; color: #e0e0e0; font-family: system-ui, sans-serif; margin: 0; }
        .header { background: #1e1e1e; padding: 1rem 2rem; border-bottom: 2px solid #d4af37; display: flex; justify-content: space-between; align-items: center; }
        .logo { color: #d4af37; font-size: 1.5rem; font-weight: bold; text-decoration: none; }
        .container { max-width: 1200px; margin: 2rem auto; padding: 2rem; }
        h1 { color: #d4af37; text-align: center; margin-bottom: 3rem; font-size: 2.5rem; }
        .servicios-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem; }
        .servicio-card { background: #1e1e1e; padding: 2rem; border-radius: 16px; border: 2px solid #333; transition: all 0.3s; }
        .servicio-card:hover { border-color: #d4af37; transform: translateY(-5px); box-shadow: 0 10px 30px rgba(212,175,55,0.2); }
        .servicio-header { display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem; }
        .icon { font-size: 2.5rem; }
        .servicio-nombre { font-size: 1.3rem; font-weight: bold; color: #d4af37; }
        .servicio-desc { color: #888; margin-bottom: 1rem; line-height: 1.6; }
        .servicio-info { display: flex; justify-content: space-between; align-items: center; margin-top: 1.5rem; }
        .precio { font-size: 1.8rem; font-weight: bold; color: #d4af37; }
        .duracion { color: #888; }
        .btn { display: inline-block; padding: 0.8rem 1.5rem; background: #d4af37; color: #000; text-decoration: none; border-radius: 8px; font-weight: bold; margin-top: 1rem; }
        .btn:hover { opacity: 0.9; }
    </style>
</head>
<body>
    <header class="header">
        <a href="/P/index.php" class="logo">🐒 BarberMonkey</a>
        <nav>
            <?php if (isset($_SESSION['user_id']) || isset($_COOKIE['access_token'])): ?>
                <a href="/P/dashboard/user.php" style="color:#e0e0e0;text-decoration:none;margin-right:1rem;">Dashboard</a>
            <?php else: ?>
                <a href="/P/login.php" style="color:#e0e0e0;text-decoration:none;margin-right:1rem;">Login</a>
            <?php endif; ?>
        </nav>
    </header>

    <div class="container">
        <h1>✂️ Nuestros Servicios</h1>
        
        <div class="servicios-grid">
            <?php foreach ($servicios as $servicio): ?>
                <div class="servicio-card">
                    <div class="servicio-header">
                        <span class="icon"><?= $servicio['icon'] ?></span>
                        <span class="servicio-nombre"><?= $servicio['nombre'] ?></span>
                    </div>
                    <p class="servicio-desc"><?= $servicio['descripcion'] ?></p>
                    <div class="servicio-info">
                        <div>
                            <div class="precio">$<?= $servicio['precio'] ?></div>
                            <div class="duracion">⏱️ <?= $servicio['duracion'] ?></div>
                        </div>
                        <a href="/P/citas.php" class="btn">Reservar</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>