<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - No Encontrado | BarberMonkey</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body style="display:flex;align-items:center;justify-content:center;height:100vh;text-align:center;">
    <div class="container">
        <h1 style="font-size:8rem;color:var(--primary);margin-bottom:0;">404</h1>
        <h2 style="color:var(--text);margin-bottom:1rem;">Página no encontrada</h2>
        <p style="color:#888;margin-bottom:2rem;">Lo sentimos, la página que buscas no existe o fue movida.</p>
        <a href="index.php" class="btn">🏠 Volver al Inicio</a>
    </div>
</body>
</html>