<?php
/**
 * DASHBOARD DE USUARIO - BarberMonkey
 * Página protegida que requiere autenticación
 */

// Iniciar sesión y cargar configuración
session_start();
require_once __DIR__ . '/../server/config.php';

// Verificar autenticación (método 1: sesión PHP)
if (!isset($_SESSION['user_id']) && !isset($_COOKIE['access_token'])) {
    // No autenticado → redirigir a login
    header('Location: /P/login.php');
    exit;
}

// Obtener datos del usuario (de la sesión o del token)
$user = $_SESSION['user'] ?? null;

// Si no hay datos en sesión pero hay token, podrías decodificarlo aquí
// Por ahora, usaremos datos de ejemplo si es desarrollo
if (!$user && defined('IS_DEV') && IS_DEV) {
    $user = [
        'id' => 5,
        'email' => 'hola.exe2005@gmail.com',
        'username' => 'Alan123',
        'role' => 'user',
        'full_name' => 'Alan Reyes'
    ];
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?= generateCsrfToken() ?>">
    <title>Dashboard - BarberMonkey</title>
    
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            background: #121212; 
            color: #e0e0e0; 
            font-family: 'Segoe UI', system-ui, sans-serif;
            min-height: 100vh;
        }
        
        /* Header */
        .header {
            background: #1e1e1e;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #d4af37;
            box-shadow: 0 2px 8px rgba(0,0,0,0.3);
        }
        .logo {
            font-size: 1.5rem;
            font-weight: bold;
            color: #d4af37;
            text-decoration: none;
        }
        .user-info {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        .user-name {
            color: #e0e0e0;
            font-weight: 500;
        }
        .btn-logout {
            background: #e57373;
            color: #fff;
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 500;
            text-decoration: none;
        }
        .btn-logout:hover { background: #f44336; }
        
        /* Main Content */
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }
        .welcome {
            margin-bottom: 2rem;
        }
        .welcome h1 {
            color: #d4af37;
            margin-bottom: 0.5rem;
        }
        .welcome p { color: #888; }
        
        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        .stat-card {
            background: #1e1e1e;
            padding: 1.5rem;
            border-radius: 12px;
            border-left: 4px solid #d4af37;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        }
        .stat-card h3 {
            color: #888;
            font-size: 0.9rem;
            margin-bottom: 0.5rem;
        }
        .stat-card .value {
            font-size: 2rem;
            font-weight: bold;
            color: #d4af37;
        }
        
        /* Actions */
        .actions {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }
        .btn {
            padding: 1rem 2rem;
            border-radius: 8px;
            font-weight: bold;
            text-decoration: none;
            display: inline-block;
            cursor: pointer;
            border: none;
            font-size: 1rem;
        }
        .btn-primary {
            background: #d4af37;
            color: #000;
        }
        .btn-primary:hover { opacity: 0.9; }
        .btn-secondary {
            background: #424242;
            color: #e0e0e0;
        }
        .btn-secondary:hover { background: #555; }
        
        /* Responsive */
        @media (max-width: 768px) {
            .header { flex-direction: column; gap: 1rem; }
            .stats-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <a href="/P/index.php" class="logo">🐒 BarberMonkey</a>
        <div class="user-info">
            <span class="user-name">👤 <?= htmlspecialchars($user['username'] ?? 'Usuario') ?></span>
            <a href="/P/server/logout.php" class="btn-logout">Cerrar Sesión</a>
        </div>
    </header>
    
    <!-- Main Content -->
    <div class="container">
        <div class="welcome">
            <h1>¡Bienvenido, <?= htmlspecialchars($user['full_name'] ?? $user['username'] ?? 'Usuario') ?>! 👋</h1>
            <p>Gestiona tus citas y tu perfil desde aquí</p>
        </div>
        
        <!-- Stats -->
        <div class="stats-grid">
            <div class="stat-card">
                <h3>📅 Citas Programadas</h3>
                <div class="value">3</div>
            </div>
            <div class="stat-card">
                <h3>✅ Citas Completadas</h3>
                <div class="value">12</div>
            </div>
            <div class="stat-card">
                <h3>⭐ Puntos de Lealtad</h3>
                <div class="value">450</div>
            </div>
            <div class="stat-card">
                <h3>🎁 Descuentos Disponibles</h3>
                <div class="value">2</div>
            </div>
        </div>
        
        <!-- Actions -->
        <div class="actions">
            <a href="/P/citas.php" class="btn btn-primary">📅 Agendar Nueva Cita</a>
            <a href="/P/mis-citas.php" class="btn btn-secondary">📋 Ver Mis Citas</a>
            <a href="/P/perfil.php" class="btn btn-secondary">👤 Editar Perfil</a>
            <a href="/P/servicios.php" class="btn btn-secondary">✂️ Ver Servicios</a>
        </div>
    </div>
    
    <script>
        console.log('✅ Dashboard cargado');
        console.log('👤 Usuario:', <?= json_encode($user) ?>);
    </script>
</body>
</html>