<?php 
$page = 'barberos'; 
require_once 'server/config.php'; 
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Conoce a nuestro equipo de barberos profesionales en BarberMonkey.">
    
    <!-- Token CSRF para seguridad -->
    <meta name="csrf-token" content="<?= generateCsrfToken() ?>">
    
    <title>Equipo - BarberMonkey</title>
    
    <!-- CSS: Orden correcto para cascada -->
    <link rel="stylesheet" href="css/base.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/animations.css">
</head>
<body>
    <!-- HEADER & NAV -->
    <header>
        <div class="container nav-wrapper">
            <a href="index.php" class="logo" aria-label="Ir al inicio">
                <span aria-hidden="true">🐒</span> BarberMonkey
            </a>
            
            <nav aria-label="Navegación principal">
                <ul>
                    <li><a href="index.php">Inicio</a></li>
                    <li><a href="servicios.php">Servicios</a></li>
                    <li><a href="barberos.php" class="active" aria-current="page">Equipo</a></li>
                    <li><a href="reservas.php">Agendar Cita</a></li>
                    <!-- 🔐 Admin: Visible solo para admin/editor (RBAC) -->
                    <li><a href="admin.php" data-role="admin,editor">🔐 Admin</a></li>
                </ul>
            </nav>
            
            <!-- 🔑 Contenedor de autenticación (se llena con JS) -->
            <div class="auth-buttons">
                <div id="auth-container"></div>
            </div>
            
            <!-- Botón de modo oscuro -->
            <button id="theme-toggle" class="magnetic-btn" aria-label="Cambiar modo oscuro/claro" title="Cambiar tema">🌙</button>
        </div>
    </header>

    <!-- BREADCRUMBS -->
    <div class="container">
        <nav id="breadcrumbs" aria-label="Migas de pan">
            <a href="index.php">Inicio</a> <span aria-hidden="true">/</span> <span>Equipo</span>
        </nav>
    </div>

    <!-- MAIN CONTENT -->
    <main class="container section">
        <h1 class="section-title">✂️ Encuentra a tu Barbero Ideal</h1>
        
        <!-- FILTRO DE EXPERIENCIA -->
        <div class="filters" style="margin-bottom:2rem; justify-content:center;">
            <label for="filtro-experiencia" class="visually-hidden">Filtrar por experiencia</label>
            <select id="filtro-experiencia" aria-label="Filtrar barberos por experiencia">
                <option value="all">Toda la experiencia</option>
                <option value="Más de 5 años">Más de 5 años</option>
                <option value="Más de 8 años">Más de 8 años</option>
                <option value="Más de 10 años">Más de 10 años</option>
            </select>
        </div>

        <h2 style="color:var(--primary); margin-bottom:1.5rem;">Nuestro Equipo</h2>
        
        <!-- LISTA DE BARBEROS (se llena con JS) -->
        <div id="barberos-list" class="grid-3" aria-live="polite">
            <!-- Fallback para usuarios sin JavaScript -->
            <article class="card hover-lift scroll-reveal">
                <div class="card-body" style="text-align:center;">
                    <img src="https://via.placeholder.com/200x200?text=Juan" alt="Foto de Juan Pérez" style="width:120px;height:120px;border-radius:50%;object-fit:cover;margin:0 auto 1rem;">
                    <h3>Juan Pérez</h3>
                    <p>Cortes clásicos y degradados</p>
                    <p style="color:var(--primary);font-weight:bold;margin-top:0.5rem;">Más de 10 años</p>
                    <a href="reservas.php?barbero=Juan Pérez" class="btn" style="margin-top:1rem;">Seleccionar</a>
                </div>
            </article>
            <article class="card hover-lift scroll-reveal">
                <div class="card-body" style="text-align:center;">
                    <img src="https://via.placeholder.com/200x200?text=Pedro" alt="Foto de Pedro García" style="width:120px;height:120px;border-radius:50%;object-fit:cover;margin:0 auto 1rem;">
                    <h3>Pedro García</h3>
                    <p>Especialista en barba y afeitados</p>
                    <p style="color:var(--primary);font-weight:bold;margin-top:0.5rem;">Más de 8 años</p>
                    <a href="reservas.php?barbero=Pedro García" class="btn" style="margin-top:1rem;">Seleccionar</a>
                </div>
            </article>
            <article class="card hover-lift scroll-reveal">
                <div class="card-body" style="text-align:center;">
                    <img src="https://via.placeholder.com/200x200?text=Carlos" alt="Foto de Carlos López" style="width:120px;height:120px;border-radius:50%;object-fit:cover;margin:0 auto 1rem;">
                    <h3>Carlos López</h3>
                    <p>Estilos urbanos y modernos</p>
                    <p style="color:var(--primary);font-weight:bold;margin-top:0.5rem;">Más de 5 años</p>
                    <a href="reservas.php?barbero=Carlos López" class="btn" style="margin-top:1rem;">Seleccionar</a>
                </div>
            </article>
        </div>
    </main>

    <!-- FOOTER -->
    <footer>
        <div class="container footer-grid">
            <div>
                <h4>BarberMonkey</h4>
                <p>Tu barbería de confianza desde 2020.</p>
            </div>
            <div>
                <h4>Enlaces</h4>
                <ul>
                    <li><a href="index.php">Inicio</a></li>
                    <li><a href="servicios.php">Servicios</a></li>
                    <li><a href="barberos.php">Equipo</a></li>
                    <li><a href="reservas.php">Reservas</a></li>
                    <li><a href="login.php">Iniciar Sesión</a></li>
                </ul>
            </div>
            <div>
                <h4>Contacto</h4>
                <p>📍 Av. Principal 123</p>
                <p>📞 +52 123 456 7890</p>
                <p>✉️ info@barbermonkey.com</p>
            </div>
        </div>
        <div class="container footer-bottom">
            <p>© 2026 BarberMonkey | Desarrollado para IDGS 8B - UTA</p>
        </div>
    </footer>

    <!-- SCRIPTS -->
    <script type="module" src="js/app.js"></script>
    
    <!-- Fallback para no-JS -->
    <noscript>
        <style>
            .scroll-reveal { opacity: 1 !important; transform: none !important; }
            #auth-container { display: none; }
            #barberos-list img { display: block; }
        </style>
        <div class="container" style="text-align:center;padding:1rem;background:var(--surface);border-radius:8px;margin:1rem 0;">
            <p>⚠️ El filtrado dinámico requiere JavaScript habilitado.</p>
        </div>
    </noscript>
    
    <!-- Estilos utilitarios para accesibilidad -->
    <style>
        .visually-hidden {
            position: absolute;
            width: 1px;
            height: 1px;
            padding: 0;
            margin: -1px;
            overflow: hidden;
            clip: rect(0, 0, 0, 0);
            white-space: nowrap;
            border: 0;
        }
    </style>
</body>
</html>