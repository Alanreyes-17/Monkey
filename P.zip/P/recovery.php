<?php
session_start();
require_once __DIR__ . '/server/config.php';

$step = $_GET['step'] ?? 'request';
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrfToken = $_POST['csrf_token'] ?? '';
    if (!verifyCsrfToken($csrfToken)) {
        $message = 'Token CSRF inválido';
        $messageType = 'error';
    } else {
        if ($step === 'request') {
            $email = trim($_POST['email'] ?? '');
            if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                // Generar código de recuperación
                $code = sprintf('%06d', mt_rand(0, 999999));
                $codeHash = hash('sha256', $code);
                
                try {
                    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
                    $stmt->execute([$email]);
                    $user = $stmt->fetch();
                    
                    if ($user) {
                        // Guardar código en BD
                        $stmt = $pdo->prepare("
                            INSERT INTO password_resets (user_id, token, expires_at) 
                            VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 15 MINUTE))
                            ON DUPLICATE KEY UPDATE token = ?, expires_at = DATE_ADD(NOW(), INTERVAL 15 MINUTE)
                        ");
                        $stmt->execute([$user['id'], $codeHash, $codeHash]);
                        
                        // En desarrollo, mostrar código
                        if (defined('IS_DEV') && IS_DEV) {
                            $message = "Código de recuperación: <strong>$code</strong>";
                            $messageType = 'success';
                            $_SESSION['recovery_email'] = $email;
                        } else {
                            // TODO: Enviar email real
                            $message = 'Si el correo existe, recibirás un código de recuperación.';
                            $messageType = 'success';
                        }
                    } else {
                        $message = 'Si el correo existe, recibirás un código de recuperación.';
                        $messageType = 'success';
                    }
                } catch (PDOException $e) {
                    $message = 'Error al procesar la solicitud';
                    $messageType = 'error';
                }
            } else {
                $message = 'Correo electrónico inválido';
                $messageType = 'error';
            }
        } elseif ($step === 'verify') {
            $email = $_SESSION['recovery_email'] ?? '';
            $code = trim($_POST['code'] ?? '');
            
            if ($email && $code) {
                $codeHash = hash('sha256', $code);
                try {
                    $stmt = $pdo->prepare("
                        SELECT pr.user_id FROM password_resets pr
                        JOIN users u ON pr.user_id = u.id
                        WHERE u.email = ? AND pr.token = ? AND pr.expires_at > NOW()
                    ");
                    $stmt->execute([$email, $codeHash]);
                    $reset = $stmt->fetch();
                    
                    if ($reset) {
                        $_SESSION['recovery_verified'] = true;
                        $_SESSION['recovery_user_id'] = $reset['user_id'];
                        header('Location: /P/recovery.php?step=reset');
                        exit;
                    } else {
                        $message = 'Código inválido o expirado';
                        $messageType = 'error';
                    }
                } catch (PDOException $e) {
                    $message = 'Error al verificar el código';
                    $messageType = 'error';
                }
            }
        } elseif ($step === 'reset') {
            if (!($_SESSION['recovery_verified'] ?? false)) {
                header('Location: /P/recovery.php');
                exit;
            }
            
            $password = $_POST['password'] ?? '';
            $confirmPassword = $_POST['confirm_password'] ?? '';
            
            if ($password === $confirmPassword && strlen($password) >= 8) {
                $passwordHash = password_hash($password, PASSWORD_BCRYPT);
                try {
                    $stmt = $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
                    $stmt->execute([$passwordHash, $_SESSION['recovery_user_id']]);
                    
                    // Invalidar código usado
                    $stmt = $pdo->prepare("UPDATE password_resets SET used = TRUE WHERE user_id = ?");
                    $stmt->execute([$_SESSION['recovery_user_id']]);
                    
                    // Limpiar sesión
                    unset($_SESSION['recovery_verified'], $_SESSION['recovery_user_id'], $_SESSION['recovery_email']);
                    
                    $message = 'Contraseña actualizada correctamente. <a href="/P/login.php">Inicia sesión</a>';
                    $messageType = 'success';
                } catch (PDOException $e) {
                    $message = 'Error al actualizar la contraseña';
                    $messageType = 'error';
                }
            } else {
                $message = 'Las contraseñas deben coincidir y tener al menos 8 caracteres';
                $messageType = 'error';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?= generateCsrfToken() ?>">
    <title>Recuperar Contraseña - BarberMonkey</title>
    <style>
        body { background: #121212; color: #e0e0e0; font-family: system-ui, sans-serif; margin: 0; padding: 0; }
        .container { max-width: 500px; margin: 4rem auto; padding: 2rem; background: #1e1e1e; border-radius: 16px; }
        h1 { color: #d4af37; text-align: center; margin-bottom: 2rem; }
        .form-group { margin-bottom: 1.5rem; }
        label { display: block; margin-bottom: 0.5rem; font-weight: 500; }
        input { width: 100%; padding: 0.8rem; border-radius: 4px; border: 1px solid #444; background: #2a2a2a; color: #e0e0e0; }
        .btn { width: 100%; padding: 1rem; background: #d4af37; color: #000; border: none; border-radius: 8px; font-weight: bold; cursor: pointer; }
        .message { padding: 1rem; border-radius: 8px; margin-bottom: 1rem; text-align: center; }
        .message.success { background: #81c784; color: #000; }
        .message.error { background: #e57373; color: #fff; }
        .steps { display: flex; justify-content: center; gap: 1rem; margin-bottom: 2rem; }
        .step { padding: 0.5rem 1rem; border-radius: 4px; background: #2a2a2a; }
        .step.active { background: #d4af37; color: #000; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔐 Recuperar Contraseña</h1>
        
        <div class="steps">
            <div class="step <?= $step === 'request' ? 'active' : '' ?>">1. Solicitar</div>
            <div class="step <?= $step === 'verify' ? 'active' : '' ?>">2. Verificar</div>
            <div class="step <?= $step === 'reset' ? 'active' : '' ?>">3. Cambiar</div>
        </div>

        <?php if ($message): ?>
            <div class="message <?= $messageType ?>">
                <?= $message ?>
            </div>
        <?php endif; ?>

        <?php if ($step === 'request'): ?>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                <div class="form-group">
                    <label>Correo Electrónico</label>
                    <input type="email" name="email" required placeholder="tu@email.com">
                </div>
                <button type="submit" class="btn">Enviar Código</button>
            </form>
        <?php elseif ($step === 'verify'): ?>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                <div class="form-group">
                    <label>Código de Verificación</label>
                    <input type="text" name="code" required placeholder="000000" maxlength="6" pattern="[0-9]{6}">
                </div>
                <button type="submit" class="btn">Verificar Código</button>
            </form>
        <?php elseif ($step === 'reset'): ?>
            <?php if ($_SESSION['recovery_verified'] ?? false): ?>
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                    <div class="form-group">
                        <label>Nueva Contraseña</label>
                        <input type="password" name="password" required minlength="8">
                    </div>
                    <div class="form-group">
                        <label>Confirmar Contraseña</label>
                        <input type="password" name="confirm_password" required minlength="8">
                    </div>
                    <button type="submit" class="btn">Cambiar Contraseña</button>
                </form>
            <?php else: ?>
                <p style="text-align:center;">Acceso denegado</p>
            <?php endif; ?>
        <?php endif; ?>

        <p style="text-align:center;margin-top:2rem;">
            <a href="/P/login.php" style="color:#d4af37;">← Volver al login</a>
        </p>
    </div>
</body>
</html>