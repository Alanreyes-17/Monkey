<?php
$page = 'index';
require_once 'server/config.php';
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="BarberMonkey - Tu barbería de confianza. Cortes, barba y afeitado profesional.">

    <!-- Token CSRF para seguridad en formularios -->
    <meta name="csrf-token" content="<?= generateCsrfToken() ?>">

    <title>BarberMonkey - Tu Barbería de Confianza</title>

    <!-- CSS: Orden correcto para cascada de estilos -->
    <link rel="stylesheet" href="css/base.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/animations.css">

    <!-- Preload de imágenes críticas -->
    <link rel="preload" href="https://images.unsplash.com/photo-1585747860715-2ba37e788b70?w=1200" as="image">
</head>

<body>
    <!-- HEADER & NAV -->
    <header>
        <div class="container nav-wrapper">
            <a href="index.php" class="logo" aria-label="Ir al inicio">
                <span aria-hidden="true">🐒</span> BarberMonkey
            </a>

            <nav aria-label="Navegación principal">
                <ul>
                    <li><a href="index.php" class="active" aria-current="page">Inicio</a></li>
                    <li>
                        <a href="servicios.php" aria-haspopup="true">Servicios</a>
                        <ul aria-label="Submenú de servicios">
                            <li><a href="servicios.php#corte-pelo">Corte de Pelo</a></li>
                            <li><a href="servicios.php#barba">Barba</a></li>
                            <li><a href="servicios.php#afeitado">Afeitado</a></li>
                        </ul>
                    </li>
                    <li><a href="barberos.php">Equipo</a></li>
                    <li><a href="reservas.php">Agendar Cita</a></li>
                    <!-- 🔐 Admin: Visible solo para admin/editor (RBAC visual) -->
                    <li><a href="admin.php" data-role="admin,editor">🔐 Admin</a></li>
                </ul>
            </nav>

            <!-- 🔑 Contenedor de autenticación (se llena con JS) -->
            <div class="auth-buttons">
                <div id="auth-container"></div>
            </div>
            <!-- 🔑 Contenedor de autenticación con fallback estático -->
            <div class="auth-buttons">
                <div id="auth-container">
                    <!-- Fallback: se muestra si JS no carga -->
                    <a href="login.php" class="btn-auth login magnetic-btn" id="fallback-login">🔐 Iniciar Sesión</a>
                </div>
            </div>

            <!-- Botón de modo oscuro -->
            <button id="theme-toggle" class="magnetic-btn" aria-label="Cambiar modo oscuro/claro" title="Cambiar tema">🌙</button>
        </div>
    </header>

    <!-- BREADCRUMBS -->
    <div class="container">
        <nav id="breadcrumbs" aria-label="Migas de pan">
            <a href="index.php">Inicio</a> <span aria-hidden="true">/</span> <span>Inicio</span>
        </nav>
    </div>

    <!-- MAIN CONTENT -->
    <main>
        <!-- HERO / CARRUSEL -->
        <div class="container">
            <section class="hero parallax-element" aria-label="Galería destacada">
                <div class="carousel-track">
                    <div class="slide">
                        <img src="https://images.unsplash.com/photo-1585747860715-2ba37e788b70?w=1200"
                            alt="Corte de pelo clásico profesional"
                            width="1200" height="400"
                            loading="eager">
                        <div class="slide-content">
                            <h1>Bienvenido a BarberMonkey</h1>
                            <p>Donde el estilo encuentra su esencia</p>
                            <a href="reservas.php" class="btn">Reserva tu Cita</a>
                        </div>
                    </div>
                    <div class="slide">
                        <img src="https://images.unsplash.com/photo-1503951914875-452162b28f1f?w=1200"
                            alt="Cortes personalizados para cada estilo"
                            width="1200" height="400"
                            loading="lazy">
                        <div class="slide-content">
                            <h2>Cortes Personalizados</h2>
                            <p>Los mejores estilos para ti</p>
                            <a href="servicios.php" class="btn">Ver Servicios</a>
                        </div>
                    </div>
                    <div class="slide">
                        <img src="https://images.unsplash.com/photo-1621605815971-fbc98d665033?w=1200"
                            alt="Experiencia premium de afeitado"
                            width="1200" height="400"
                            loading="lazy">
                        <div class="slide-content">
                            <h2>Experiencia Premium</h2>
                            <p>Tratamientos exclusivos para caballeros</p>
                            <a href="barberos.php" class="btn">Nuestro Equipo</a>
                        </div>
                    </div>
                </div>

                <button class="carousel-btn prev" aria-label="Diapositiva anterior">❮</button>
                <button class="carousel-btn next" aria-label="Siguiente diapositiva">❯</button>
                <div class="carousel-indicators" role="tablist" aria-label="Navegación del carrusel"></div>
            </section>
        </div>

        <!-- SECCIÓN DE SERVICIOS -->
        <section class="section" style="background:var(--surface);">
            <div class="container">
                <h2 class="section-title">✨ Nuestros Servicios</h2>

                <div class="grid-3">
                    <article class="card hover-lift scroll-reveal">
                        <div class="card-body" style="text-align:center;">
                            <span style="font-size:3rem;" aria-hidden="true">✂️</span>
                            <h3 id="corte-pelo">Corte de Pelo</h3>
                            <p>Cortes modernos y clásicos adaptados a tu estilo personal. Incluye lavado y peinado.</p>
                            <a href="reservas.php?servicio=Corte de Pelo" class="btn" style="margin-top:1rem;">Agendar</a>
                        </div>
                    </article>

                    <article class="card hover-lift scroll-reveal">
                        <div class="card-body" style="text-align:center;">
                            <span style="font-size:3rem;" aria-hidden="true">🧔</span>
                            <h3 id="barba">Arreglo de Barba</h3>
                            <p>Diseño y perfilado de barba con toallas calientes y productos premium.</p>
                            <a href="reservas.php?servicio=Barba" class="btn" style="margin-top:1rem;">Agendar</a>
                        </div>
                    </article>

                    <article class="card hover-lift scroll-reveal">
                        <div class="card-body" style="text-align:center;">
                            <span style="font-size:3rem;" aria-hidden="true">🪒</span>
                            <h3 id="afeitado">Afeitado Clásico</h3>
                            <p>Experiencia tradicional con navaja, toallas calientes y espuma de afeitar.</p>
                            <a href="reservas.php?servicio=Afeitado" class="btn" style="margin-top:1rem;">Agendar</a>
                        </div>
                    </article>
                </div>
            </div>
        </section>

        <!-- SECCIÓN DE TESTIMONIOS -->
        <section class="section">
            <div class="container">
                <h2 class="section-title">💬 Lo que dicen nuestros clientes</h2>
                <div class="grid-3">
                    <blockquote class="testimonial scroll-reveal">
                        <p>"El mejor lugar para un corte de calidad. Los barberos son profesionales y el ambiente es excelente."</p>
                        <footer><cite class="author">- Carlos M.</cite></footer>
                    </blockquote>
                    <blockquote class="testimonial scroll-reveal">
                        <p>"Desde que descubrí BarberMonkey no voy a otro lado. Mi barba nunca había lucido tan bien."</p>
                        <footer><cite class="author">- Roberto D.</cite></footer>
                    </blockquote>
                    <blockquote class="testimonial scroll-reveal">
                        <p>"Excelente atención y precios justos. Recomendado 100% para quienes buscan calidad."</p>
                        <footer><cite class="author">- Andrés P.</cite></footer>
                    </blockquote>
                </div>
            </div>
        </section>
    </main>

    <!-- FOOTER -->
    <footer>
        <div class="container footer-grid">
            <div>
                <h4>BarberMonkey</h4>
                <p>Tu barbería de confianza desde 2020. Comprometidos con tu estilo y satisfacción.</p>
            </div>
            <div>
                <h4>Enlaces Rápidos</h4>
                <ul>
                    <li><a href="index.php">Inicio</a></li>
                    <li><a href="servicios.php">Servicios</a></li>
                    <li><a href="barberos.php">Equipo</a></li>
                    <li><a href="reservas.php">Reservas</a></li>
                    <li><a href="login.php">Iniciar Sesión</a></li>
                </ul>
            </div>
            <div>
                <h4>Horario</h4>
                <p>Lunes - Sábado: 9am - 8pm</p>
                <p>Domingo: Cerrado</p>
            </div>
            <div>
                <h4>Contacto</h4>
                <p>📍 Av. Principal 123</p>
                <p>📞 +52 123 456 7890</p>
                <p>✉️ info@barbermonkey.com</p>
            </div>
        </div>
        <div class="container footer-bottom">
            <p>© 2026 BarberMonkey | Desarrollado para IDGS 8B - UTA</p>
        </div>
    </footer>

    <!-- SCRIPTS -->
    <script type="module" src="js/app.js"></script>

    <!-- Fallback para no-JS -->
    <noscript>
        <style>
            .scroll-reveal {
                opacity: 1 !important;
                transform: none !important;
            }

            .carousel-track {
                display: block !important;
            }

            .slide {
                display: block !important;
                margin-bottom: 1rem;
            }

            #auth-container {
                display: none;
            }
        </style>
        <div class="container" style="text-align:center;padding:1rem;background:var(--surface);">
            <p>⚠️ Algunas funciones interactivas requieren JavaScript habilitado.</p>
            <p><a href="login.php" style="color:var(--primary);">🔐 Iniciar Sesión</a></p>
        </div>
    </noscript>
</body>

</html>