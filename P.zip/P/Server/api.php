<?php
/**
 * API ROUTER PRINCIPAL (BACKEND)
 * Versión corregida: $pdo disponible globalmente
 */

// ==================== 1. CONFIGURACIÓN DE CABECERAS ====================
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-CSRF-Token');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// ==================== 2. CARGAR DEPENDENCIAS EN ORDEN CORRECTO ====================
// Config primero (define constantes y funciones)
require_once __DIR__ . '/config.php';

// db.php crea $pdo GLOBAL - verificar que se cargó correctamente
require_once __DIR__ . '/db.php';

// ⚠️ VERIFICAR QUE $pdo EXISTE Y ES VÁLIDO
if (!isset($pdo) || !$pdo instanceof PDO) {
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'message' => 'Error crítico: Conexión a base de datos no disponible',
        'debug' => isDev() ? 'db.php no definió $pdo correctamente' : null
    ]);
    exit;
}

// Cargar el resto de módulos (ya pueden usar $pdo global)
require_once __DIR__ . '/security.php';
require_once __DIR__ . '/middleware.php';
require_once __DIR__ . '/services/JWTService.php';
require_once __DIR__ . '/auth.php';

// ==================== 3. OBTENER DATOS DE ENTRADA ====================
$input = json_decode(file_get_contents('php://input'), true) ?? [];
$route = $_GET['route'] ?? '';
$requestData = array_merge($_GET, $input);

// ==================== 4. FUNCIÓN AUXILIAR PARA RESPUESTAS ====================
function sendJSON($data, $httpCode = 200) {
    if (!headers_sent()) {
        http_response_code($httpCode);
        header('Content-Type: application/json; charset=utf-8');
    }
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    // ==================== ROUTING PRINCIPAL ====================

    // ─────────────────────────────────────────────────────────
    // AUTHENTICATION
    // ─────────────────────────────────────────────────────────
    if (str_starts_with($route, 'auth/')) {
        
        switch ($route) {
            
            case 'auth/login':
                rateLimitHandler('login:' . ($requestData['email'] ?? 'unknown'), 5, 900);
                
                if (empty($requestData['email']) || empty($requestData['password'])) {
                    throw new Exception('Credenciales incompletas');
                }
                // $pdo ya está disponible globalmente desde db.php
                $result = Auth::login($requestData['email'], $requestData['password'], $pdo);
                sendJSON($result, isset($result['error']) ? 401 : 200);
                break;

            case 'auth/mfa':
                if (empty($requestData['code']) || empty($requestData['user_id'])) {
                    throw new Exception('Código MFA y user_id requeridos');
                }
                $result = Auth::verifyMFA($requestData['user_id'], $requestData['code'], $pdo);
                sendJSON($result, isset($result['error']) ? 403 : 200);
                break;

            case 'auth/register':
                rateLimitHandler('register', 3, 3600);
                $result = Auth::register($requestData, $pdo);
                sendJSON($result, isset($result['error']) ? 400 : 201);
                break;

            case 'auth/recover':
                if (empty($requestData['email'])) throw new Exception('Email requerido');
                $result = Auth::requestReset($requestData['email'], $pdo);
                sendJSON($result);
                break;

            case 'auth/refresh':
                $refreshToken = $_COOKIE['refresh_token'] ?? null;
                if (!$refreshToken) throw new Exception('Refresh token requerido');
                
                $result = JWTService::refreshAccessToken($refreshToken, $pdo);
                if (!$result) throw new Exception('Refresh token inválido o expirado');
                
                setcookie('access_token', $result['access_token'], [
                    'expires' => time() + JWT_EXPIRE,
                    'path' => '/',
                    'secure' => !isDev(),
                    'httponly' => true,
                    'samesite' => 'Lax'
                ]);
                sendJSON($result);
                break;

            case 'auth/logout':
                $result = Auth::logout($pdo);
                sendJSON($result);
                break;

            case 'auth/reset-password':
                if (empty($requestData['token']) || empty($requestData['new_password']) || empty($requestData['confirm_password'])) {
                    throw new Exception('Datos incompletos');
                }
                $result = Auth::resetPassword(
                    $requestData['token'],
                    $requestData['new_password'],
                    $requestData['confirm_password'],
                    $pdo
                );
                sendJSON($result, isset($result['error']) ? 400 : 200);
                break;
        }
    }

    // ─────────────────────────────────────────────────────────
    // CITAS CRUD
    // ─────────────────────────────────────────────────────────
    elseif (str_starts_with($route, 'citas/')) {
        
        // Protección: solo admin/editor
        requireAuth(['admin', 'editor']);
        csrfProtect();
        
        switch ($route) {
            
            case 'citas/list':
                $q = $requestData['q'] ?? '';
                $estado = $requestData['estado'] ?? 'all';
                $page = max(1, (int)($requestData['page'] ?? 1));
                $limit = min(100, (int)($requestData['limit'] ?? 20));
                $offset = ($page - 1) * $limit;
                
                $sql = "SELECT * FROM citas WHERE 1=1";
                $countSql = "SELECT COUNT(*) as total FROM citas WHERE 1=1";
                $params = [];
                $countParams = [];
                
                if (!empty($q)) {
                    $filter = "%$q%";
                    $sql .= " AND (nombre LIKE ? OR servicio LIKE ? OR email LIKE ?)";
                    $countSql .= " AND (nombre LIKE ? OR servicio LIKE ? OR email LIKE ?)";
                    $params = [$filter, $filter, $filter];
                    $countParams = [$filter, $filter, $filter];
                }
                
                if ($estado !== 'all') {
                    $sql .= " AND estado = ?";
                    $countSql .= " AND estado = ?";
                    $params[] = $estado;
                    $countParams[] = $estado;
                }
                
                $totalStmt = $pdo->prepare($countSql);
                $totalStmt->execute($countParams);
                $totalRows = $totalStmt->fetch()['total'];
                
                $sql .= " ORDER BY id DESC LIMIT ? OFFSET ?";
                $params[] = $limit;
                $params[] = $offset;
                
                $stmt = $pdo->prepare($sql);
                $stmt->execute($params);
                
                sendJSON([
                    'success' => true,
                    'data' => $stmt->fetchAll(),
                    'pagination' => [
                        'page' => $page,
                        'limit' => $limit,
                        'total' => $totalRows,
                        'pages' => ceil($totalRows / $limit)
                    ]
                ]);
                break;

            case 'citas/add':
                if (empty($requestData['nombre']) || empty($requestData['servicio'])) {
                    throw new Exception('Campos requeridos: nombre y servicio');
                }
                $stmt = $pdo->prepare("INSERT INTO citas (nombre, email, servicio, barbero, estado, user_id) VALUES (?, ?, ?, ?, 'Pendiente', ?)");
                $stmt->execute([
                    Security::sanitize($requestData['nombre']),
                    Security::sanitize($requestData['email'] ?? ''),
                    Security::sanitize($requestData['servicio']),
                    Security::sanitize($requestData['barbero'] ?? ''),
                    $_SESSION['user_id'] ?? null
                ]);
                sendJSON(['success' => true, 'message' => 'Cita registrada', 'id' => $pdo->lastInsertId()]);
                break;

            case 'citas/update':
                if (empty($requestData['id'])) throw new Exception('ID de cita requerido');
                $stmt = $pdo->prepare("UPDATE citas SET nombre=?, email=?, servicio=?, barbero=?, estado=? WHERE id=?");
                $stmt->execute([
                    Security::sanitize($requestData['nombre']),
                    Security::sanitize($requestData['email'] ?? ''),
                    Security::sanitize($requestData['servicio']),
                    Security::sanitize($requestData['barbero'] ?? ''),
                    Security::sanitize($requestData['estado'] ?? 'Pendiente'),
                    $requestData['id']
                ]);
                sendJSON(['success' => true, 'message' => 'Cita actualizada']);
                break;

            case 'citas/delete':
                if (empty($requestData['id'])) throw new Exception('ID de cita requerido');
                $stmt = $pdo->prepare("DELETE FROM citas WHERE id=?");
                $stmt->execute([$requestData['id']]);
                sendJSON(['success' => true, 'message' => 'Cita eliminada']);
                break;
        }
    }

    // ─────────────────────────────────────────────────────────
    // USUARIOS
    // ─────────────────────────────────────────────────────────
    elseif (str_starts_with($route, 'users/')) {
        
        $payload = requireAuth();
        
        switch ($route) {
            
            case 'users/profile':
                $stmt = $pdo->prepare("SELECT id, username, email, role_id, created_at, mfa_enabled FROM users WHERE id = ?");
                $stmt->execute([$payload['id']]);
                $user = $stmt->fetch();
                if (!$user) throw new Exception('Usuario no encontrado');
                sendJSON(['success' => true, 'data' => $user]);
                break;
                
            case 'users/update-profile':
                csrfProtect();
                if (empty($requestData['username']) || empty($requestData['email'])) {
                    throw new Exception('Username y email son requeridos');
                }
                $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
                $stmt->execute([$requestData['email'], $payload['id']]);
                if ($stmt->fetch()) throw new Exception('El email ya está registrado');
                
                $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, updated_at = NOW() WHERE id = ?");
                $stmt->execute([
                    Security::sanitize($requestData['username']),
                    Security::sanitize($requestData['email']),
                    $payload['id']
                ]);
                sendJSON(['success' => true, 'message' => 'Perfil actualizado']);
                break;
                
            case 'users/change-password':
                csrfProtect();
                if (empty($requestData['current_password']) || empty($requestData['new_password'])) {
                    throw new Exception('Contraseñas requeridas');
                }
                $stmt = $pdo->prepare("SELECT password_hash FROM users WHERE id = ?");
                $stmt->execute([$payload['id']]);
                $user = $stmt->fetch();
                
                if (!$user || !password_verify($requestData['current_password'], $user['password_hash'])) {
                    throw new Exception('Contraseña actual incorrecta');
                }
                
                if (!Security::validatePasswordStrength($requestData['new_password'])) {
                    throw new Exception('La nueva contraseña no cumple con los requisitos');
                }
                
                $newHash = password_hash($requestData['new_password'], PASSWORD_BCRYPT, ['cost' => 12]);
                $pdo->prepare("UPDATE users SET password_hash = ?, updated_at = NOW() WHERE id = ?")
                    ->execute([$newHash, $payload['id']]);
                
                sendJSON(['success' => true, 'message' => 'Contraseña actualizada']);
                break;
        }
    }

    // ─────────────────────────────────────────────────────────
    // SESIONES (Solo Admin)
    // ─────────────────────────────────────────────────────────
    elseif (str_starts_with($route, 'sessions/')) {
        
        requireAuth(['admin']);
        
        switch ($route) {
            case 'sessions/list':
                $stmt = $pdo->query("SELECT s.id, s.ip_address as ip, s.user_agent as agent, s.created_at as date, s.is_active as active, u.email FROM sessions s JOIN users u ON s.user_id = u.id ORDER BY s.created_at DESC LIMIT 50");
                sendJSON(['success' => true, 'data' => $stmt->fetchAll()]);
                break;
                
            case 'sessions/revoke':
                csrfProtect();
                if (empty($requestData['session_id'])) throw new Exception('Session ID requerido');
                $stmt = $pdo->prepare("UPDATE sessions SET is_active = 0 WHERE id = ?");
                $stmt->execute([$requestData['session_id']]);
                sendJSON(['success' => true, 'message' => 'Sesión revocada']);
                break;
        }
    }

    // ─────────────────────────────────────────────────────────
    // SERVICIOS Y BARBEROS (Lectura pública)
    // ─────────────────────────────────────────────────────────
    elseif (str_starts_with($route, 'servicios/') || str_starts_with($route, 'barberos/')) {
        
        switch ($route) {
            case 'servicios/list':
                $servicios = [
                    ['id' => 1, 'nombre' => 'Corte de Pelo', 'descripcion' => 'Cortes clásicos y modernos', 'icono' => '✂️'],
                    ['id' => 2, 'nombre' => 'Barba', 'descripcion' => 'Diseño y perfilado premium', 'icono' => '🧔'],
                    ['id' => 3, 'nombre' => 'Afeitado', 'descripcion' => 'Experiencia tradicional', 'icono' => '🪒']
                ];
                sendJSON(['success' => true, 'data' => $servicios]);
                break;
                
            case 'barberos/list':
                $barberos = [
                    ['id' => 1, 'nombre' => 'Juan Pérez', 'especialidad' => 'Cortes clásicos', 'experiencia' => 'Más de 10 años'],
                    ['id' => 2, 'nombre' => 'Pedro García', 'especialidad' => 'Barba y afeitados', 'experiencia' => 'Más de 8 años'],
                    ['id' => 3, 'nombre' => 'Carlos López', 'especialidad' => 'Estilos urbanos', 'experiencia' => 'Más de 5 años']
                ];
                sendJSON(['success' => true, 'data' => $barberos]);
                break;
        }
    }

    // ─────────────────────────────────────────────────────────
    // RUTA NO ENCONTRADA
    // ─────────────────────────────────────────────────────────
    else {
        throw new Exception("Endpoint no encontrado: $route");
    }

} catch (Exception $e) {
    if (isDev()) {
        error_log("API Error [{$route}]: " . $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine());
    }
    
    sendJSON([
        'success' => false,
        'message' => $e->getMessage(),
        'debug' => isDev() ? ['file' => $e->getFile(), 'line' => $e->getLine()] : null
    ], 500);
}