<?php
/**
 * MIDDLEWARE DE SEGURIDAD Y AUTENTICACIÓN (Práctica 1 U3)
 * Gestiona protección de rutas, roles, CSRF, rate limiting y prevención de hijacking
 * 
 * @package BarberMonkey\Middleware
 */

// Cargar dependencias en orden correcto
require_once __DIR__ . '/config.php';  // Primero: define constantes y funciones
require_once __DIR__ . '/db.php';       // Segundo: crea $pdo global
require_once __DIR__ . '/services/JWTService.php'; // Tercero: servicios JWT

/**
 * Verifica que $pdo esté disponible globalmente
 * @return PDO
 * @throws RuntimeException si no hay conexión
 */
function getPdo(): PDO {
    global $pdo;
    if (!isset($pdo) || !$pdo instanceof PDO) {
        throw new RuntimeException('Conexión a base de datos no disponible');
    }
    return $pdo;
}

/**
 * Verifica autenticación, validez de sesión en BD y control de acceso por roles
 * @param array $allowedRoles - Roles permitidos (vacío = cualquier rol autenticado)
 * @return array Payload del usuario (id, email, role, exp)
 * @throws Redirección HTTP 302 o respuesta JSON 401/403
 */
function requireAuth(array $allowedRoles = []): array {
    $pdo = getPdo();
    
    // 1. Obtener token de acceso
    $token = $_COOKIE['access_token'] ?? $_GET['token'] ?? null;
    if (!$token) {
        redirectToLogin('Sesión no iniciada');
    }

    // 2. Decodificar y validar JWT
    $payload = JWTService::decode($token);
    if (!$payload || !isset($payload['id'], $payload['role'], $payload['exp'])) {
        clearAuthCookies();
        redirectToLogin('Token inválido o expirado');
    }

    // 3. Validar integridad de sesión en BD
    $sessionId = $_COOKIE['session_id'] ?? null;
    $currentIp = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $currentUserAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
    
    if ($sessionId) {
        $sessionValid = validateSessionInDB($payload['id'], $sessionId, $currentIp, $currentUserAgent);
        
        if (!$sessionValid) {
            auditLog('session_validation_failed', [
                'user_id' => $payload['id'],
                'session_id' => $sessionId,
                'ip' => $currentIp,
                'user_agent' => $currentUserAgent
            ]);
            clearAuthCookies();
            redirectToLogin('Sesión invalidada por seguridad');
        }
        
        if (!checkSessionIdleTimeout($sessionId, $pdo)) {
            auditLog('session_idle_timeout', ['user_id' => $payload['id'], 'session_id' => $sessionId]);
            clearAuthCookies();
            redirectToLogin('Sesión expirada por inactividad');
        }
    }

    // 4. Control de acceso por roles (RBAC)
    if (!empty($allowedRoles) && !in_array($payload['role'], $allowedRoles, true)) {
        auditLog('access_denied_role', [
            'user_id' => $payload['id'],
            'required_roles' => $allowedRoles,
            'user_role' => $payload['role']
        ]);
        
        http_response_code(403);
        header('Content-Type: application/json');
        echo json_encode([
            'error' => 'Acceso denegado: Rol insuficiente',
            'required' => $allowedRoles,
            'current' => $payload['role']
        ]);
        exit;
    }

    // 5. Actualizar último acceso de la sesión
    if ($sessionId) {
        updateSessionLastActivity($sessionId, $pdo);
    }

    // 6. Almacenar en sesión PHP
    $_SESSION['user'] = $payload;
    $_SESSION['user_id'] = $payload['id'];
    $_SESSION['last_activity'] = time();
    
    return $payload;
}

/**
 * Protege rutas contra CSRF en métodos que modifican datos
 * @return void
 * @throws HTTP 403 Si el token CSRF es inválido
 */
function csrfProtect(): void {
    $method = $_SERVER['REQUEST_METHOD'];
    $safeMethods = ['GET', 'HEAD', 'OPTIONS'];
    
    if (in_array($method, $safeMethods, true)) {
        return;
    }

    $csrfToken = $_POST['csrf_token'] 
        ?? $_SERVER['HTTP_X_CSRF_TOKEN'] 
        ?? $_GET['csrf_token'] 
        ?? null;
    
    $sessionToken = $_SESSION['csrf_token'] ?? '';
    
    // ✅ Usa verifyCsrfToken() de config.php (NO la redeclares aquí)
    if (!$csrfToken || !verifyCsrfToken($csrfToken)) {
        auditLog('csrf_validation_failed', [
            'method' => $method,
            'uri' => $_SERVER['REQUEST_URI'] ?? 'unknown',
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
        ]);
        
        http_response_code(403);
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Token CSRF inválido o expirado']);
        exit;
    }
}

/**
 * Rate Limiting con bloqueo temporal y respuesta HTTP 429
 */
function rateLimitHandler(string $key, int $maxAttempts = 5, int $window = 900): bool {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $sessionKey = "rate_{$key}_{$ip}";
    
    $attempts = $_SESSION[$sessionKey] ?? ['count' => 0, 'time' => time()];
    
    if (time() - $attempts['time'] > $window) {
        $attempts = ['count' => 0, 'time' => time()];
    }
    
    $attempts['count']++;
    $_SESSION[$sessionKey] = $attempts;
    
    if ($attempts['count'] > $maxAttempts) {
        $retryAfter = $window - (time() - $attempts['time']);
        
        auditLog('rate_limit_exceeded', [
            'key' => $key,
            'ip' => $ip,
            'attempts' => $attempts['count'],
            'retry_after' => $retryAfter
        ]);
        
        http_response_code(429);
        header('Content-Type: application/json');
        header("Retry-After: {$retryAfter}");
        echo json_encode([
            'error' => 'Demasiados intentos. Bloqueo temporal activo.',
            'retry_after' => $retryAfter,
            'message' => 'Por seguridad, espera antes de intentar nuevamente.'
        ]);
        return false;
    }
    
    return true;
}

/**
 * Registra intento fallido para funciones auxiliares de auth
 */
function recordFailedAttempt(string $identifier): void {
    $key = "failed_attempts_{$identifier}";
    $attempts = $_SESSION[$key] ?? ['count' => 0, 'last_attempt' => time()];
    $attempts['count']++;
    $attempts['last_attempt'] = time();
    $_SESSION[$key] = $attempts;
    
    auditLog('failed_attempt_recorded', [
        'identifier' => $identifier,
        'total_attempts' => $attempts['count']
    ]);
}

/**
 * Resetea intentos fallidos
 */
function resetFailedAttempts(string $identifier): void {
    unset($_SESSION["failed_attempts_{$identifier}"]);
}

/**
 * Verifica si la cuenta está bloqueada por intentos fallidos
 */
function isAccountLocked(string $identifier, int $maxAttempts = 5, int $lockoutTime = 900): bool {
    $key = "failed_attempts_{$identifier}";
    $attempts = $_SESSION[$key] ?? ['count' => 0, 'last_attempt' => 0];
    
    if ($attempts['count'] >= $maxAttempts) {
        if (time() - $attempts['last_attempt'] < $lockoutTime) {
            return true;
        }
        resetFailedAttempts($identifier);
    }
    return false;
}

/**
 * Valida que la sesión esté activa y coincida con IP/User-Agent
 */
function validateSessionInDB(int $userId, string $sessionId, string $ip, string $userAgent): bool {
    try {
        $pdo = getPdo();
        $stmt = $pdo->prepare("
            SELECT id, ip_address, user_agent 
            FROM sessions 
            WHERE id = ? AND user_id = ? AND is_active = 1 
            AND expires_at > NOW()
            LIMIT 1
        ");
        $stmt->execute([$sessionId, $userId]);
        $session = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$session) {
            return false;
        }
        
        $ipMatch = ($session['ip_address'] === $ip);
        $uaMatch = ($session['user_agent'] === $userAgent);
        
        if (isDev()) {
            return $ipMatch;
        }
        
        return $ipMatch && $uaMatch;
        
    } catch (PDOException $e) {
        error_log("Session validation error: " . $e->getMessage());
        auditLog('session_validation_error', ['error' => $e->getMessage(), 'user_id' => $userId]);
        return false;
    }
}

/**
 * Verifica si la sesión ha excedido el tiempo de inactividad
 */
function checkSessionIdleTimeout(string $sessionId, PDO $pdo): bool {
    try {
        $stmt = $pdo->prepare("
            SELECT last_activity, expires_at 
            FROM sessions 
            WHERE id = ? AND is_active = 1
        ");
        $stmt->execute([$sessionId]);
        $session = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$session) {
            return false;
        }
        
        if (strtotime($session['expires_at']) < time()) {
            return false;
        }
        
        $idleTimeout = defined('SESSION_IDLE_TIMEOUT') ? SESSION_IDLE_TIMEOUT : 1800;
        $lastActivity = strtotime($session['last_activity'] ?? $session['created_at']);
        
        return (time() - $lastActivity) < $idleTimeout;
        
    } catch (PDOException $e) {
        error_log("Idle timeout check error: " . $e->getMessage());
        return true;
    }
}

/**
 * Actualiza el timestamp de última actividad de la sesión
 */
function updateSessionLastActivity(string $sessionId, PDO $pdo): void {
    try {
        $stmt = $pdo->prepare("
            UPDATE sessions 
            SET last_activity = NOW() 
            WHERE id = ? AND (last_activity IS NULL OR last_activity < DATE_SUB(NOW(), INTERVAL 1 MINUTE))
        ");
        $stmt->execute([$sessionId]);
    } catch (PDOException $e) {
        error_log("Session activity update error: " . $e->getMessage());
    }
}

/**
 * Redirección segura a login con limpieza de cookies
 */
function redirectToLogin(string $reason = '', string $redirectUrl = ''): void {
    clearAuthCookies();
    
    if ($reason && isDev()) {
        error_log("Auth redirect: {$reason} | IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
    }
    
    auditLog('auth_redirect', [
        'reason' => $reason ?: 'unknown',
        'redirect_url' => $redirectUrl ?: 'login.php'
    ]);
    
    $target = $redirectUrl ?: (SITE_URL . 'auth/login.php');
    if (!filter_var($target, FILTER_VALIDATE_URL) || strpos($target, SITE_URL) !== 0) {
        $target = SITE_URL . 'auth/login.php';
    }
    
    if (empty($redirectUrl) && isset($_SERVER['REQUEST_URI'])) {
        $return = urlencode($_SERVER['REQUEST_URI']);
        $target .= '?return=' . $return;
    }
    
    header('Location: ' . $target);
    exit;
}

/**
 * Limpia cookies de autenticación de forma segura
 */
function clearAuthCookies(): void {
    if (!headers_sent()) {
        $params = session_get_cookie_params();
        $domain = $params['domain'] ?? '';
        $path = $params['path'] ?? '/';
        $secure = $params['secure'] ?? !isDev();
        
        $cookies = ['access_token', 'refresh_token', 'session_id'];
        foreach ($cookies as $name) {
            setcookie($name, '', [
                'expires' => time() - 3600,
                'path' => $path,
                'domain' => $domain,
                'secure' => $secure,
                'httponly' => true,
                'samesite' => 'Strict'
            ]);
            setcookie($name, '', time() - 3600, $path, $domain);
        }
    }
}

/**
 * Middleware para APIs: devuelve JSON en lugar de redirigir
 */
function requireAuthApi(array $allowedRoles = []): ?array {
    $token = $_COOKIE['access_token'] ?? $_GET['token'] 
        ?? (function() {
            $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
            if (preg_match('/Bearer\s+(.+)$/i', $authHeader, $matches)) {
                return $matches[1];
            }
            return null;
        })();
    
    if (!$token) {
        http_response_code(401);
        echo json_encode(['error' => 'Authentication required']);
        return null;
    }

    $payload = JWTService::decode($token);
    if (!$payload || !isset($payload['id'], $payload['role'])) {
        http_response_code(401);
        echo json_encode(['error' => 'Invalid or expired token']);
        return null;
    }

    if (!empty($allowedRoles) && !in_array($payload['role'], $allowedRoles, true)) {
        http_response_code(403);
        echo json_encode(['error' => 'Access denied: insufficient role']);
        return null;
    }

    return $payload;
}

/**
 * Middleware para CORS preflight (OPTIONS requests)
 */
function handleCorsPreflight(): void {
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization, X-CSRF-Token');
        header('Access-Control-Max-Age: 86400');
        http_response_code(204);
        exit;
    }
}