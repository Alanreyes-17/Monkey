<?php
/**
 * SECURITY UTILITIES (Práctica 1 Unidad 3)
 * Handles CSRF, XSS prevention, Password Hashing, and Input Validation.
 * 
 * @package BarberMonkey\Security
 */

class Security {

    /**
     * Genera y retorna un token CSRF para formularios.
     * Si no existe, crea uno nuevo en la sesión.
     * @return string Token único.
     */
    public static function generateCsrfToken(): string {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }

    /**
     * Verifica si el token CSRF proporcionado es válido.
     * Usa hash_equals para prevención de ataques de tiempo (Timing Attacks).
     * @param string $token Token enviado por el usuario.
     * @return bool
     */
    public static function verifyCsrfToken(string $token): bool {
        return hash_equals($_SESSION['csrf_token'] ?? '', $token);
    }

    /**
     * Limpia y sanitiza datos para prevenir XSS (Cross-Site Scripting).
     * @param mixed $data Cadena o array de cadenas.
     * @return mixed Dato sanitizado.
     */
    public static function sanitize($data) {
        if (is_array($data)) {
            return array_map([self::class, 'sanitize'], $data);
        }
        // htmlspecialchars convierte caracteres especiales en entidades HTML
        return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
    }

    /**
     * Limpia input para uso en Base de Datos (aunque usamos PDO, es buena práctica).
     * Elimina etiquetas HTML no deseadas.
     * @param string $string
     * @return string
     */
    public static function cleanInput(string $string): string {
        // Elimina etiquetas HTML excepto las básicas
        $string = strip_tags(trim($string));
        // Remueve caracteres nulos
        return str_replace(chr(0), '', $string);
    }

    /**
     * Hashea una contraseña de forma segura usando Bcrypt.
     * Requisito de la práctica: "Contraseña hasheada".
     * @param string $password
     * @return string
     */
    public static function hashPassword(string $password): string {
        // Coste 12 es un balance entre seguridad y rendimiento
        return password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    }

    /**
     * Verifica una contraseña contra su hash.
     * @param string $password
     * @param string $hash
     * @return bool
     */
    public static function verifyPassword(string $password, string $hash): bool {
        return password_verify($password, $hash);
    }

    /**
     * Valida la fuerza de una contraseña (Requisito de seguridad).
     * Mínimo 8 caracteres, 1 mayúscula, 1 número.
     * @param string $password
     * @return bool
     */
    public static function validatePasswordStrength(string $password): bool {
        // Regex: Min 8 chars, 1 Upper, 1 Lower, 1 Digit
        $pattern = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/';
        return preg_match($pattern, $password) === 1;
    }

    /**
     * Valida formato de correo electrónico.
     * @param string $email
     * @return bool
     */
    public static function validateEmail(string $email): bool {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }
}
?>