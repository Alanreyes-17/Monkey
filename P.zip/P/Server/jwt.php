<?php
/**
 * SERVICIO DE JSON WEB TOKENS (Práctica 1 U3)
 * Implementa codificación, decodificación y gestión segura de tokens JWT
 * 
 * @package BarberMonkey\Services
 */

require_once __DIR__ . '/../config.php';

class JWTService {

    /**
     * Codifica un payload en token JWT firmado con HS256
     */
    public static function encode(array $payload, array $options = []): string {
        if (empty($payload['id']) && empty($payload['sub'])) {
            throw new InvalidArgumentException('El payload debe contener "id" o "sub"');
        }

        $defaultClaims = [
            'iss' => SITE_URL,
            'iat' => time(),
            'nbf' => time(),
            'jti' => bin2hex(random_bytes(16)),
            'aud' => $options['aud'] ?? 'barbermonkey'
        ];

        $claims = array_merge($defaultClaims, $options, $payload);

        if (!isset($claims['exp'])) {
            $claims['exp'] = time() + JWT_EXPIRE;
        }

        $header = json_encode(['alg' => JWT_ALGO, 'typ' => 'JWT']);
        $b64Header = self::base64UrlEncode($header);
        $b64Payload = self::base64UrlEncode(json_encode($claims));
        $signature = hash_hmac('sha256', "{$b64Header}.{$b64Payload}", JWT_SECRET, true);
        $b64Signature = self::base64UrlEncode($signature);

        if (isDev()) {
            auditLog('token_generated', ['jti' => $claims['jti'], 'user_id' => $payload['id'] ?? null]);
        }

        return "{$b64Header}.{$b64Payload}.{$b64Signature}";
    }

    /**
     * Decodifica y valida un token JWT
     */
    public static function decode(string $token, array $options = []) {
        try {
            $parts = explode('.', $token);
            if (count($parts) !== 3) {
                return false;
            }

            list($b64Header, $b64Payload, $b64Signature) = $parts;

            $expectedSig = hash_hmac('sha256', "{$b64Header}.{$b64Payload}", JWT_SECRET, true);
            $providedSig = self::base64UrlDecode($b64Signature);
            
            if (!hash_equals($expectedSig, $providedSig)) {
                return false;
            }

            $payload = json_decode(self::base64UrlDecode($b64Payload), true);
            if (!$payload || !is_array($payload)) {
                return false;
            }

            if (isset($payload['exp']) && $payload['exp'] < time()) {
                return false;
            }

            if (isset($payload['nbf']) && $payload['nbf'] > time()) {
                return false;
            }

            if (isset($payload['iss']) && $payload['iss'] !== SITE_URL) {
                return false;
            }

            $expectedAud = $options['audience'] ?? 'barbermonkey';
            if (isset($payload['aud']) && $payload['aud'] !== $expectedAud) {
                return false;
            }

            // Verificar blacklist (solo si hay conexión PDO disponible)
            // Nota: Este método se llama desde middleware que tiene acceso a $pdo
            // Aquí omitimos la verificación para mantener el método puro

            return $payload;

        } catch (Exception $e) {
            if (isDev()) {
                error_log("JWT Decode Error: " . $e->getMessage());
            }
            return false;
        }
    }

    /**
     * Genera y almacena un refresh token seguro
     */
    public static function generateRefreshToken(int $userId, PDO $pdo, string $audience = 'barbermonkey'): string {
        $token = bin2hex(random_bytes(32));
        $tokenHash = hash('sha256', $token);
        $tokenId = bin2hex(random_bytes(16));

        $stmt = $pdo->prepare("
            INSERT INTO refresh_tokens 
            (token_hash, token_id, user_id, audience, expires_at, created_at) 
            VALUES (?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL 7 DAY), NOW())
        ");
        $stmt->execute([$tokenHash, $tokenId, $userId, $audience]);

        setcookie('refresh_token', $token, [
            'expires' => time() + REFRESH_EXPIRE,
            'path' => '/',
            'domain' => '',
            'secure' => !isDev(),
            'httponly' => true,
            'samesite' => 'Strict'
        ]);

        auditLog('refresh_token_generated', ['user_id' => $userId, 'token_id' => $tokenId]);

        return $token;
    }

    /**
     * Revoca un refresh token por su ID
     */
    public static function revokeRefreshToken(string $tokenId, PDO $pdo): bool {
        $stmt = $pdo->prepare("
            UPDATE refresh_tokens 
            SET revoked = TRUE, revoked_at = NOW() 
            WHERE token_id = ? AND revoked = FALSE
        ");
        $result = $stmt->execute([$tokenId]);
        
        if ($result) {
            auditLog('refresh_token_revoked', ['token_id' => $tokenId]);
        }
        
        return $result;
    }

    /**
     * Valida un refresh token y retorna el user_id si es válido
     */
    public static function validateRefreshToken(string $token, PDO $pdo, string $audience = 'barbermonkey') {
        $tokenHash = hash('sha256', $token);
        
        $stmt = $pdo->prepare("
            SELECT user_id, token_id, audience
            FROM refresh_tokens 
            WHERE token_hash = ? 
            AND revoked = FALSE 
            AND expires_at > NOW()
            LIMIT 1
        ");
        $stmt->execute([$tokenHash]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($result && $result['audience'] !== $audience) {
            return false;
        }
        
        return $result ? (int)$result['user_id'] : false;
    }

    /**
     * Renueva un access token usando refresh token
     */
    public static function refreshAccessToken(string $refreshToken, PDO $pdo, string $audience = 'barbermonkey') {
        $userId = self::validateRefreshToken($refreshToken, $pdo, $audience);
        if (!$userId) {
            return false;
        }

        $stmt = $pdo->prepare("
            SELECT u.id, u.email, r.name as role 
            FROM users u 
            JOIN roles r ON u.role_id = r.id 
            WHERE u.id = ? AND u.is_active = 1
        ");
        $stmt->execute([$userId]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$user) {
            return false;
        }

        $newAccessToken = self::encode([
            'id' => $user['id'],
            'email' => $user['email'],
            'role' => $user['role'],
            'sub' => $user['id']
        ], ['aud' => $audience]);

        auditLog('access_token_refreshed', ['user_id' => $userId]);

        return [
            'access_token' => $newAccessToken,
            'token_type' => 'Bearer',
            'expires_in' => JWT_EXPIRE
        ];
    }

    /**
     * Añade un token a la blacklist (para logout anticipado)
     */
    public static function blacklistToken(string $jti, int $exp, PDO $pdo): bool {
        if ($exp < time()) {
            return true;
        }
        
        try {
            $stmt = $pdo->prepare("
                INSERT INTO token_blacklist (jti, expires_at, created_at) 
                VALUES (?, FROM_UNIXTIME(?), NOW())
                ON DUPLICATE KEY UPDATE expires_at = FROM_UNIXTIME(?)
            ");
            return $stmt->execute([$jti, $exp, $exp]);
        } catch (PDOException $e) {
            error_log("Blacklist error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Verifica si un token está en la blacklist
     */
    public static function isTokenBlacklisted(string $jti, int $exp, PDO $pdo): bool {
        try {
            if (random_int(1, 100) <= 5) {
                $pdo->prepare("DELETE FROM token_blacklist WHERE expires_at < NOW()")->execute();
            }
            
            $stmt = $pdo->prepare("SELECT id FROM token_blacklist WHERE jti = ? AND expires_at > NOW()");
            $stmt->execute([$jti]);
            return (bool) $stmt->fetch();
        } catch (PDOException $e) {
            return false;
        }
    }

    /**
     * Obtiene metadata de un token sin validar firma (SOLO PARA DEBUG)
     */
    public static function debugPayload(string $token): ?array {
        if (!isDev()) {
            return null;
        }
        
        $parts = explode('.', $token);
        if (count($parts) !== 3) return null;
        
        try {
            return json_decode(self::base64UrlDecode($parts[1]), true);
        } catch (Throwable $e) {
            return null;
        }
    }

    /**
     * Obtiene información detallada de un token válido
     */
    public static function getTokenInfo(string $token): ?array {
        $payload = self::decode($token);
        if (!$payload) return null;
        
        return [
            'jti' => $payload['jti'] ?? null,
            'sub' => $payload['sub'] ?? null,
            'iss' => $payload['iss'] ?? null,
            'aud' => $payload['aud'] ?? null,
            'issued_at' => $payload['iat'] ?? null,
            'expires_at' => $payload['exp'] ?? null,
            'remaining_seconds' => isset($payload['exp']) ? max(0, $payload['exp'] - time()) : null,
            'is_expired' => isset($payload['exp']) && $payload['exp'] < time()
        ];
    }

    /**
     * ✅ CORREGIDO: Codifica datos en Base64URL (estándar JWT RFC 7515)
     */
    private static function base64UrlEncode(string $data): string {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    /**
     * ✅ CORREGIDO: Decodifica Base64URL a datos originales
     * Esta es la línea que suele dar error - versión simplificada y segura
     */
    private static function base64UrlDecode(string $data): string {
        // Reemplazar caracteres URL-safe a estándar Base64
        $data = strtr($data, '-_', '+/');
        
        // Agregar padding si es necesario (Base64 requiere múltiplo de 4)
        $pad = strlen($data) % 4;
        if ($pad === 2) {
            $data .= '==';
        } elseif ($pad === 3) {
            $data .= '=';
        }
        // Si pad === 1, es dato inválido, pero base64_decode lo maneja
        
        return base64_decode($data, true);
    }
}