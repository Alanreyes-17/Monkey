<?php
/**
 * MÓDULO DE AUTENTICACIÓN (Práctica 1 U3)
 * Gestiona login, registro, MFA, recuperación y tokens JWT
 * 
 * @package BarberMonkey\Auth
 */

require_once 'middleware.php';
require_once 'security.php';
require_once 'services/JWTService.php';

class Auth {

    /**
     * Inicia sesión de usuario con validación y MFA opcional
     */
    public static function login($email, $password, $pdo) {
        // 1. Validación básica
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return ['status' => 'error', 'message' => 'Formato de correo inválido'];
        }

        // 2. Rate limiting (previene fuerza bruta)
        if (!rateLimitHandler('login:' . $email, 5, 900)) {
            // rateLimitHandler ya envía respuesta HTTP 429 y exit
            exit; 
        }

        // 3. Consultar usuario con rol
        $stmt = $pdo->prepare("
            SELECT u.*, r.name as role 
            FROM users u 
            JOIN roles r ON u.role_id = r.id 
            WHERE u.email = ? AND u.is_active = 1
        ");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // 4. Verificar credenciales
        if (!$user || !password_verify($password, $user['password_hash'])) {
            self::recordFailedAttempt($email);
            return ['status' => 'error', 'message' => 'Credenciales incorrectas'];
        }

        // 5. Resetear intentos fallidos si el login fue exitoso
        self::resetFailedAttempts($email);

        // 6. Prevención de Session Fixation: regenerar ID de sesión PHP
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_regenerate_id(true);
        }

        // 7. Verificar bloqueo de cuenta (por si acaso)
        if (self::isAccountLocked($email)) {
            return ['status' => 'error', 'message' => 'Cuenta bloqueada temporalmente. Intenta más tarde.'];
        }

        // 8. Si el usuario tiene MFA activado, requerir verificación adicional
        if ($user['mfa_enabled']) {
            $otp = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
            $stmt = $pdo->prepare("
                INSERT INTO mfa_codes (user_id, code, type, expires_at) 
                VALUES (?, ?, 'auth', DATE_ADD(NOW(), INTERVAL 5 MINUTE))
            ");
            $stmt->execute([$user['id'], $otp]);
            
            // Log seguro (no mostrar OTP completo en producción)
            error_log("MFA code generated for user: {$user['id']}");
            
            return [
                'status' => 'mfa_required',
                'message' => 'Se requiere verificación de dos factores',
                'user_id' => $user['id'],
                'email' => self::maskEmail($user['email'])
            ];
        }

        // 9. Generar tokens JWT
        $accessToken = JWTService::encode([
            'id' => $user['id'],
            'email' => $user['email'],
            'role' => $user['role'],
            'iat' => time(),
            'exp' => time() + JWT_EXPIRE
        ]);

        $refreshToken = JWTService::generateRefreshToken($user['id'], $pdo);

        // 10. Configurar cookies seguras
        setcookie('access_token', $accessToken, [
            'expires' => time() + JWT_EXPIRE,
            'path' => '/',
            'secure' => !self::isDev(),
            'httponly' => true,
            'samesite' => 'Lax'
        ]);

        setcookie('refresh_token', $refreshToken, [
            'expires' => time() + REFRESH_EXPIRE,
            'path' => '/',
            'secure' => !self::isDev(),
            'httponly' => true,
            'samesite' => 'Strict'
        ]);

        // 11. Registrar sesión en base de datos (multisesiones)
        $sessionId = bin2hex(random_bytes(32));
        $stmt = $pdo->prepare("
            INSERT INTO sessions (id, user_id, ip_address, user_agent, expires_at) 
            VALUES (?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL 7 DAY))
        ");
        $stmt->execute([
            $sessionId,
            $user['id'],
            $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0',
            $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
        ]);

        // 12. Auditoría de seguridad
        self::auditEvent('login_success', ['user_id' => $user['id'], 'email' => $user['email']], $pdo);

        // 13. Respuesta exitosa (sin datos sensibles)
        return [
            'status' => 'success',
            'message' => 'Autenticación exitosa',
            'user' => [
                'id' => $user['id'],
                'email' => $user['email'],
                'role' => $user['role'],
                'username' => $user['username']
            ],
            'redirect' => self::getRedirectByRole($user['role'])
        ];
    }

    /**
     * Verifica código MFA y completa la autenticación
     */
    public static function verifyMFA($userId, $code, $pdo) {
        if (!preg_match('/^\d{6}$/', $code)) {
            return ['status' => 'error', 'message' => 'Código MFA inválido'];
        }

        // Buscar código válido y no usado
        $stmt = $pdo->prepare("
            SELECT id, user_id FROM mfa_codes 
            WHERE user_id = ? AND code = ? AND type = 'auth' AND used = 0 AND expires_at > NOW()
            ORDER BY created_at DESC LIMIT 1
        ");
        $stmt->execute([$userId, $code]);
        $mfa = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$mfa) {
            self::recordFailedAttempt("mfa_{$userId}");
            return ['status' => 'error', 'message' => 'Código expirado o inválido'];
        }

        // Marcar código como usado
        $pdo->prepare("UPDATE mfa_codes SET used = 1 WHERE id = ?")->execute([$mfa['id']]);

        // Obtener datos del usuario
        $stmt = $pdo->prepare("
            SELECT u.*, r.name as role 
            FROM users u 
            JOIN roles r ON u.role_id = r.id 
            WHERE u.id = ?
        ");
        $stmt->execute([$userId]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            return ['status' => 'error', 'message' => 'Usuario no encontrado'];
        }

        // Generar tokens (igual que en login)
        $accessToken = JWTService::encode([
            'id' => $user['id'],
            'email' => $user['email'],
            'role' => $user['role'],
            'iat' => time(),
            'exp' => time() + JWT_EXPIRE
        ]);

        $refreshToken = JWTService::generateRefreshToken($user['id'], $pdo);

        // Cookies seguras
        setcookie('access_token', $accessToken, [
            'expires' => time() + JWT_EXPIRE,
            'path' => '/',
            'secure' => !self::isDev(),
            'httponly' => true,
            'samesite' => 'Lax'
        ]);

        setcookie('refresh_token', $refreshToken, [
            'expires' => time() + REFRESH_EXPIRE,
            'path' => '/',
            'secure' => !self::isDev(),
            'httponly' => true,
            'samesite' => 'Strict'
        ]);

        // Registrar sesión
        $sessionId = bin2hex(random_bytes(32));
        $pdo->prepare("
            INSERT INTO sessions (id, user_id, ip_address, user_agent, expires_at) 
            VALUES (?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL 7 DAY))
        ")->execute([
            $sessionId, $user['id'],
            $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0',
            $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
        ]);

        self::auditEvent('mfa_verified', ['user_id' => $user['id']], $pdo);

        return [
            'status' => 'success',
            'message' => 'Verificación MFA exitosa',
            'user' => [
                'id' => $user['id'],
                'email' => $user['email'],
                'role' => $user['role']
            ],
            'redirect' => self::getRedirectByRole($user['role'])
        ];
    }

    /**
     * Registra un nuevo usuario
     */
    public static function register($data, $pdo) {
        // Validación de campos requeridos
        $required = ['username', 'email', 'password', 'confirm_password'];
        foreach ($required as $field) {
            if (empty($data[$field])) {
                return ['status' => 'error', 'message' => "El campo '{$field}' es requerido"];
            }
        }

        if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            return ['status' => 'error', 'message' => 'Formato de correo inválido'];
        }

        if (!Security::validatePasswordStrength($data['password'])) {
            return ['status' => 'error', 'message' => 'La contraseña debe tener al menos 8 caracteres, 1 mayúscula, 1 minúscula y 1 número'];
        }

        if ($data['password'] !== $data['confirm_password']) {
            return ['status' => 'error', 'message' => 'Las contraseñas no coinciden'];
        }

        // Verificar unicidad
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? OR username = ?");
        $stmt->execute([$data['email'], $data['username']]);
        if ($stmt->fetch()) {
            return ['status' => 'error', 'message' => 'El correo o nombre de usuario ya está registrado'];
        }

        // Hashear contraseña
        $passwordHash = password_hash($data['password'], PASSWORD_BCRYPT, ['cost' => 12]);

        // Insertar usuario
        $stmt = $pdo->prepare("
            INSERT INTO users (username, email, password_hash, role_id, created_at) 
            VALUES (?, ?, ?, 3, NOW())
        ");
        $stmt->execute([
            Security::sanitize($data['username']),
            Security::sanitize($data['email']),
            $passwordHash
        ]);

        $userId = $pdo->lastInsertId();

        // Auditoría
        self::auditEvent('user_registered', ['user_id' => $userId, 'email' => $data['email']], $pdo);

        return [
            'status' => 'success',
            'message' => 'Registro exitoso. Por favor inicia sesión.',
            'redirect' => SITE_URL . 'auth/login.php'
        ];
    }

    /**
     * Solicita recuperación de contraseña por email
     */
    public static function requestReset($email, $pdo) {
        // Prevención de enumeración
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND is_active = 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            return ['status' => 'success', 'message' => 'Si el correo está registrado, recibirás instrucciones.'];
        }

        $token = bin2hex(random_bytes(32));
        $tokenHash = hash('sha256', $token);

        // Invalidar tokens anteriores
        $pdo->prepare("UPDATE password_resets SET used = 1 WHERE user_id = ?")->execute([$user['id']]);

        // Guardar nuevo token
        $stmt = $pdo->prepare("
            INSERT INTO password_resets (user_id, token, expires_at) 
            VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 1 HOUR))
        ");
        $stmt->execute([$user['id'], $tokenHash]);

        // Simular envío de email
        $resetLink = SITE_URL . "auth/reset.php?token={$token}&email=" . urlencode($email);
        error_log("🔗 Password reset for {$email}: {$resetLink}");

        self::auditEvent('password_reset_requested', ['email' => $email], $pdo);

        return [
            'status' => 'success',
            'message' => 'Instrucciones enviadas. Revisa tu correo.'
        ];
    }

    /**
     * Restablece contraseña con token válido
     */
    public static function resetPassword($token, $newPassword, $confirmPassword, $pdo) {
        if ($newPassword !== $confirmPassword) {
            return ['status' => 'error', 'message' => 'Las contraseñas no coinciden'];
        }

        if (!Security::validatePasswordStrength($newPassword)) {
            return ['status' => 'error', 'message' => 'La contraseña no cumple con los requisitos de seguridad'];
        }

        $tokenHash = hash('sha256', $token);
        $stmt = $pdo->prepare("
            SELECT pr.user_id, u.email 
            FROM password_resets pr
            JOIN users u ON pr.user_id = u.id
            WHERE pr.token = ? AND pr.used = 0 AND pr.expires_at > NOW()
        ");
        $stmt->execute([$tokenHash]);
        $reset = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$reset) {
            return ['status' => 'error', 'message' => 'Token inválido o expirado'];
        }

        // Actualizar contraseña
        $passwordHash = password_hash($newPassword, PASSWORD_BCRYPT, ['cost' => 12]);
        $pdo->prepare("UPDATE users SET password_hash = ?, updated_at = NOW() WHERE id = ?")
            ->execute([$passwordHash, $reset['user_id']]);

        // Invalidar token usado
        $pdo->prepare("UPDATE password_resets SET used = 1 WHERE id = ?")
            ->execute([$reset['id']]);

        // Opcional: invalidar todas las sesiones activas del usuario
        $pdo->prepare("UPDATE sessions SET is_active = 0 WHERE user_id = ?")
            ->execute([$reset['user_id']]);

        self::auditEvent('password_reset_completed', ['user_id' => $reset['user_id']], $pdo);

        return [
            'status' => 'success',
            'message' => 'Contraseña actualizada. Inicia sesión con tus nuevas credenciales.',
            'redirect' => SITE_URL . 'auth/login.php'
        ];
    }

    /**
     * Cierra sesión y limpia tokens
     */
    public static function logout($pdo) {
        $payload = JWTService::decode($_COOKIE['access_token'] ?? '');
        
        if ($payload && isset($payload['id'])) {
            // Invalidar refresh token
            if (!empty($_COOKIE['refresh_token'])) {
                $pdo->prepare("UPDATE refresh_tokens SET revoked = 1 WHERE user_id = ?")
                    ->execute([$payload['id']]);
            }
            // Desactivar sesión actual
            $sessionId = $_COOKIE['session_id'] ?? null;
            if ($sessionId) {
                $pdo->prepare("UPDATE sessions SET is_active = 0 WHERE id = ?")
                    ->execute([$sessionId]);
            }
            self::auditEvent('logout', ['user_id' => $payload['id']], $pdo);
        }

        // Eliminar cookies
        if (!headers_sent()) {
            setcookie('access_token', '', time() - 3600, '/', '', true, true);
            setcookie('refresh_token', '', time() - 3600, '/', '', true, true);
            setcookie('session_id', '', time() - 3600, '/', '', true, true);
        }

        return ['status' => 'success', 'message' => 'Sesión cerrada correctamente'];
    }

    // ==================== MÉTODOS AUXILIARES DE SEGURIDAD ====================

    /**
     * Registra intento fallido para rate limiting
     */
    private static function recordFailedAttempt($identifier) {
        $key = "failed_attempts_{$identifier}";
        $attempts = $_SESSION[$key] ?? ['count' => 0, 'last_attempt' => time()];
        $attempts['count']++;
        $attempts['last_attempt'] = time();
        $_SESSION[$key] = $attempts;
        
        // Log de auditoría
        self::auditEvent('failed_login_attempt', ['identifier' => $identifier, 'attempts' => $attempts['count']]);
    }

    /**
     * Resetea intentos fallidos
     */
    private static function resetFailedAttempts($identifier) {
        unset($_SESSION["failed_attempts_{$identifier}"]);
    }

    /**
     * Verifica si la cuenta está bloqueada por intentos fallidos
     */
    private static function isAccountLocked($identifier, $maxAttempts = 5, $lockoutTime = 900) {
        $key = "failed_attempts_{$identifier}";
        $attempts = $_SESSION[$key] ?? ['count' => 0, 'last_attempt' => 0];
        
        if ($attempts['count'] >= $maxAttempts) {
            if (time() - $attempts['last_attempt'] < $lockoutTime) {
                return true;
            }
            // Resetear si pasó el tiempo de bloqueo
            self::resetFailedAttempts($identifier);
        }
        return false;
    }

    /**
     * Enmascara email para mostrar en respuestas (ej: j***@example.com)
     */
    private static function maskEmail($email) {
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) return '***@***.***';
        list($user, $domain) = explode('@', $email);
        $maskedUser = substr($user, 0, 2) . str_repeat('*', max(0, strlen($user) - 2));
        return "{$maskedUser}@{$domain}";
    }

    /**
     * Registra evento de auditoría de seguridad
     */
    private static function auditEvent($action, $context = [], $pdo = null) {
        $logEntry = [
            'timestamp' => date('c'),
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
            'action' => $action,
            'context' => array_filter($context, function($k) {
                return !in_array(strtolower($k), ['password', 'token', 'secret', 'answer'], true);
            }, ARRAY_FILTER_USE_KEY)
        ];
        
        // Log en archivo
        $logFile = __DIR__ . '/../logs/security_audit.log';
        if (!is_dir(dirname($logFile))) {
            mkdir(dirname($logFile), 0755, true);
        }
        file_put_contents($logFile, json_encode($logEntry) . PHP_EOL, FILE_APPEND | LOCK_EX);
        
        // Opcional: guardar en BD
        if ($pdo && isset($context['user_id'])) {
            try {
                $stmt = $pdo->prepare("
                    INSERT INTO security_logs (user_id, action, ip_address, user_agent, context, created_at) 
                    VALUES (?, ?, ?, ?, ?, NOW())
                ");
                $stmt->execute([
                    $context['user_id'],
                    $action,
                    $logEntry['ip'],
                    $logEntry['user_agent'],
                    json_encode($logEntry['context'])
                ]);
            } catch (PDOException $e) {
                error_log("Audit log DB error: " . $e->getMessage());
            }
        }
    }

    /**
     * Obtiene ruta de redirección según rol
     */
    private static function getRedirectByRole($role) {
        $routes = [
            'admin' => 'admin.php',
            'editor' => 'dashboard/editor.php',
            'user' => 'dashboard/user.php'
        ];
        return $routes[$role] ?? 'index.php';
    }

    /**
     * Verifica si estamos en desarrollo
     */
    private static function isDev() {
        return $_SERVER['HTTP_HOST'] === 'localhost' || $_SERVER['HTTP_HOST'] === '127.0.0.1';
    }
}