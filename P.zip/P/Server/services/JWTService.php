<?php
/**
 * SERVICIO DE JSON WEB TOKENS (Práctica 1 U3)
 * Implementa codificación, decodificación y gestión segura de tokens JWT
 * 
 * @package BarberMonkey\Services
 */

// Verificar que config.php esté cargado
if (!defined('JWT_SECRET')) {
    // Intentar cargar config.php automáticamente
    $configPaths = [
        __DIR__ . '/../config.php',
        __DIR__ . '/../../server/config.php',
        __DIR__ . '/config.php'
    ];
    
    $loaded = false;
    foreach ($configPaths as $path) {
        if (file_exists($path)) {
            require_once $path;
            $loaded = true;
            break;
        }
    }
    
    if (!$loaded || !defined('JWT_SECRET')) {
        throw new RuntimeException('JWTService requiere que config.php esté cargado primero');
    }
}

class JWTService {

    /**
     * Codifica un payload en token JWT firmado con HS256
     */
    public static function encode(array $payload, array $options = []): string {
        // Validar payload mínimo
        if (empty($payload['id']) && empty($payload['sub'])) {
            throw new InvalidArgumentException('El payload debe contener "id" o "sub"');
        }

        // Claims estándar
        $defaultClaims = [
            'iss' => defined('SITE_URL') ? SITE_URL : 'barbermonkey',
            'iat' => time(),
            'nbf' => time(),
            'jti' => bin2hex(random_bytes(16)),
            'aud' => $options['aud'] ?? 'barbermonkey'
        ];

        $claims = array_merge($defaultClaims, $options, $payload);

        if (!isset($claims['exp'])) {
            $claims['exp'] = time() + (defined('JWT_EXPIRE') ? JWT_EXPIRE : 900);
        }

        // Header
        $header = json_encode(['alg' => defined('JWT_ALGO') ? JWT_ALGO : 'HS256', 'typ' => 'JWT']);
        
        // Codificar partes
        $b64Header = self::base64UrlEncode($header);
        $b64Payload = self::base64UrlEncode(json_encode($claims));
        
        // Firmar
        $signature = hash_hmac('sha256', "{$b64Header}.{$b64Payload}", defined('JWT_SECRET') ? JWT_SECRET : 'fallback_secret', true);
        $b64Signature = self::base64UrlEncode($signature);

        return "{$b64Header}.{$b64Payload}.{$b64Signature}";
    }

    /**
     * Decodifica y valida un token JWT
     */
    public static function decode(string $token, array $options = []) {
        try {
            $parts = explode('.', $token);
            if (count($parts) !== 3) {
                return false;
            }

            list($b64Header, $b64Payload, $b64Signature) = $parts;

            // Verificar firma
            $expectedSig = hash_hmac('sha256', "{$b64Header}.{$b64Payload}", defined('JWT_SECRET') ? JWT_SECRET : 'fallback_secret', true);
            $providedSig = self::base64UrlDecode($b64Signature);
            
            if (!hash_equals($expectedSig, $providedSig)) {
                return false;
            }

            // Decodificar payload
            $payload = json_decode(self::base64UrlDecode($b64Payload), true);
            if (!$payload || !is_array($payload)) {
                return false;
            }

            // Validar expiración
            if (isset($payload['exp']) && $payload['exp'] < time()) {
                return false;
            }

            // Validar "not before"
            if (isset($payload['nbf']) && $payload['nbf'] > time()) {
                return false;
            }

            // Validar emisor
            if (isset($payload['iss']) && defined('SITE_URL') && $payload['iss'] !== SITE_URL) {
                return false;
            }

            // Validar audiencia
            $expectedAud = $options['audience'] ?? 'barbermonkey';
            if (isset($payload['aud']) && $payload['aud'] !== $expectedAud) {
                return false;
            }

            return $payload;

        } catch (Exception $e) {
            if (defined('IS_DEV') && IS_DEV) {
                error_log("JWT Decode Error: " . $e->getMessage());
            }
            return false;
        }
    }

    /**
     * Genera y almacena un refresh token seguro
     */
    public static function generateRefreshToken(int $userId, PDO $pdo, string $audience = 'barbermonkey'): string {
        $token = bin2hex(random_bytes(32));
        $tokenHash = hash('sha256', $token);
        $tokenId = bin2hex(random_bytes(16));

        // Verificar que la tabla existe antes de insertar
        try {
            $stmt = $pdo->query("SHOW TABLES LIKE 'refresh_tokens'");
            if (!$stmt->fetch()) {
                // Tabla no existe, retornar token sin guardar (modo desarrollo)
                return $token;
            }
            
            $stmt = $pdo->prepare("
                INSERT INTO refresh_tokens 
                (token_hash, token_id, user_id, audience, expires_at, created_at) 
                VALUES (?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL 7 DAY), NOW())
            ");
            $stmt->execute([$tokenHash, $tokenId, $userId, $audience]);
        } catch (PDOException $e) {
            error_log("Refresh token insert error: " . $e->getMessage());
            // Continuar sin guardar en BD para no romper el flujo
        }

        // Configurar cookie
        if (!headers_sent()) {
            setcookie('refresh_token', $token, [
                'expires' => time() + (defined('REFRESH_EXPIRE') ? REFRESH_EXPIRE : 604800),
                'path' => '/',
                'domain' => '',
                'secure' => !self::isDev(),
                'httponly' => true,
                'samesite' => 'Strict'
            ]);
        }

        return $token;
    }

    /**
     * Revoca un refresh token por su ID
     */
    public static function revokeRefreshToken(string $tokenId, PDO $pdo): bool {
        try {
            $stmt = $pdo->prepare("
                UPDATE refresh_tokens 
                SET revoked = TRUE, revoked_at = NOW() 
                WHERE token_id = ? AND revoked = FALSE
            ");
            return $stmt->execute([$tokenId]);
        } catch (PDOException $e) {
            error_log("Revoke error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Valida un refresh token y retorna el user_id si es válido
     */
    public static function validateRefreshToken(string $token, PDO $pdo, string $audience = 'barbermonkey') {
        $tokenHash = hash('sha256', $token);
        
        try {
            // Verificar que la tabla existe
            $stmt = $pdo->query("SHOW TABLES LIKE 'refresh_tokens'");
            if (!$stmt->fetch()) {
                // En desarrollo, aceptar cualquier token válido (simulación)
                return 1;
            }
            
            $stmt = $pdo->prepare("
                SELECT user_id, token_id, audience
                FROM refresh_tokens 
                WHERE token_hash = ? 
                AND revoked = FALSE 
                AND expires_at > NOW()
                LIMIT 1
            ");
            $stmt->execute([$tokenHash]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($result && $result['audience'] !== $audience) {
                return false;
            }
            
            return $result ? (int)$result['user_id'] : false;
        } catch (PDOException $e) {
            error_log("Validate refresh token error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Renueva un access token usando refresh token
     */
    public static function refreshAccessToken(string $refreshToken, PDO $pdo, string $audience = 'barbermonkey') {
        $userId = self::validateRefreshToken($refreshToken, $pdo, $audience);
        if (!$userId) {
            return false;
        }

        try {
            // Verificar que la tabla users existe
            $stmt = $pdo->query("SHOW TABLES LIKE 'users'");
            if (!$stmt->fetch()) {
                // Simular usuario para desarrollo
                return [
                    'access_token' => self::encode(['id' => $userId, 'email' => 'dev@local', 'role' => 'user'], ['aud' => $audience]),
                    'token_type' => 'Bearer',
                    'expires_in' => defined('JWT_EXPIRE') ? JWT_EXPIRE : 900
                ];
            }
            
            $stmt = $pdo->prepare("
                SELECT u.id, u.email, r.name as role 
                FROM users u 
                LEFT JOIN roles r ON u.role_id = r.id 
                WHERE u.id = ? AND u.is_active = 1
            ");
            $stmt->execute([$userId]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$user) {
                return false;
            }

            $newAccessToken = self::encode([
                'id' => $user['id'],
                'email' => $user['email'],
                'role' => $user['role'] ?? 'user',
                'sub' => $user['id']
            ], ['aud' => $audience]);

            return [
                'access_token' => $newAccessToken,
                'token_type' => 'Bearer',
                'expires_in' => defined('JWT_EXPIRE') ? JWT_EXPIRE : 900
            ];
        } catch (PDOException $e) {
            error_log("Refresh access token error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Añade un token a la blacklist (para logout anticipado)
     */
    public static function blacklistToken(string $jti, int $exp, PDO $pdo): bool {
        if ($exp < time()) {
            return true;
        }
        
        try {
            // Verificar que la tabla existe
            $stmt = $pdo->query("SHOW TABLES LIKE 'token_blacklist'");
            if (!$stmt->fetch()) {
                return true; // Simular éxito si la tabla no existe
            }
            
            $stmt = $pdo->prepare("
                INSERT INTO token_blacklist (jti, expires_at, created_at) 
                VALUES (?, FROM_UNIXTIME(?), NOW())
                ON DUPLICATE KEY UPDATE expires_at = FROM_UNIXTIME(?)
            ");
            return $stmt->execute([$jti, $exp, $exp]);
        } catch (PDOException $e) {
            error_log("Blacklist error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Verifica si un token está en la blacklist
     */
    public static function isTokenBlacklisted(string $jti, int $exp, PDO $pdo): bool {
        try {
            $stmt = $pdo->query("SHOW TABLES LIKE 'token_blacklist'");
            if (!$stmt->fetch()) {
                return false; // No hay blacklist, asumir que no está blacklisteado
            }
            
            // Limpieza ocasional de entries expirados
            if (random_int(1, 100) <= 5) {
                $pdo->prepare("DELETE FROM token_blacklist WHERE expires_at < NOW()")->execute();
            }
            
            $stmt = $pdo->prepare("SELECT id FROM token_blacklist WHERE jti = ? AND expires_at > NOW()");
            $stmt->execute([$jti]);
            return (bool) $stmt->fetch();
        } catch (PDOException $e) {
            return false;
        }
    }

    /**
     * Obtiene metadata de un token sin validar firma (SOLO PARA DEBUG)
     */
    public static function debugPayload(string $token): ?array {
        if (!self::isDev()) {
            return null;
        }
        
        $parts = explode('.', $token);
        if (count($parts) !== 3) return null;
        
        try {
            return json_decode(self::base64UrlDecode($parts[1]), true);
        } catch (Throwable $e) {
            return null;
        }
    }

    /**
     * Obtiene información detallada de un token válido
     */
    public static function getTokenInfo(string $token): ?array {
        $payload = self::decode($token);
        if (!$payload) return null;
        
        return [
            'jti' => $payload['jti'] ?? null,
            'sub' => $payload['sub'] ?? null,
            'iss' => $payload['iss'] ?? null,
            'aud' => $payload['aud'] ?? null,
            'issued_at' => $payload['iat'] ?? null,
            'expires_at' => $payload['exp'] ?? null,
            'remaining_seconds' => isset($payload['exp']) ? max(0, $payload['exp'] - time()) : null,
            'is_expired' => isset($payload['exp']) && $payload['exp'] < time()
        ];
    }

    /**
     * Codifica datos en Base64URL (estándar JWT RFC 7515)
     */
    private static function base64UrlEncode(string $data): string {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    /**
     * Decodifica Base64URL a datos originales
     */
    private static function base64UrlDecode(string $data): string {
        $data = strtr($data, '-_', '+/');
        $pad = strlen($data) % 4;
        if ($pad === 2) {
            $data .= '==';
        } elseif ($pad === 3) {
            $data .= '=';
        }
        return base64_decode($data, true);
    }

    /**
     * Verifica si estamos en entorno de desarrollo
     */
    private static function isDev(): bool {
        if (defined('IS_DEV')) {
            return IS_DEV;
        }
        $host = $_SERVER['HTTP_HOST'] ?? '';
        return in_array($host, ['localhost', '127.0.0.1', '::1'], true);
    }
}