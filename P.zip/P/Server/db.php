<?php
/**
 * CONEXIÓN A BASE DE DATOS (Práctica 1 U3)
 * Establece conexión PDO segura con MySQL, manejo de errores y logging
 * 
 * @package BarberMonkey\Database
 */

require_once 'config.php';

// ==================== CONFIGURACIÓN DE CONEXIÓN ====================
$dsn = defined('DB_DSN') ? DB_DSN : 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;

$options = [
    // Modo de errores: lanzar excepciones para manejo centralizado
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    
    // Fetch por defecto: array asociativo (más legible)
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    
    // Prepared statements reales (previene SQL injection)
    PDO::ATTR_EMULATE_PREPARES => false,
    
    // Timeout de conexión (evitar bloqueos largos)
    PDO::ATTR_TIMEOUT => 10,
    
    // Habilitar buffering de consultas
    PDO::MYSQL_ATTR_USE_BUFFERED_QUERY => true,
    
    // Codificación de caracteres
    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8mb4' COLLATE 'utf8mb4_unicode_ci'"
];

// ==================== LISTA BLANCA DE TABLAS (Seguridad) ====================
// Previene SQL injection en funciones helper que interpolan nombres de tabla
const ALLOWED_TABLES = [
    'users', 'roles', 'sessions', 'refresh_tokens', 
    'password_resets', 'mfa_codes', 'citas', 'security_logs',
    'secret_questions', 'email_verifications'
];

/**
 * Valida que un nombre de tabla esté en la lista permitida
 * @param string $table
 * @return bool
 * @throws InvalidArgumentException si la tabla no es permitida
 */
function validateTableName(string $table): bool {
    if (!in_array($table, ALLOWED_TABLES, true)) {
        throw new InvalidArgumentException("Tabla no permitida: {$table}");
    }
    return true;
}

/**
 * Escapa un identificador de columna para prevenir SQL injection
 * @param string $column
 * @return string
 */
function escapeIdentifier(string $column): string {
    // Solo permitir caracteres alfanuméricos y guion bajo
    return preg_match('/^[a-zA-Z0-9_]+$/', $column) ? "`{$column}`" : '`id`';
}

// ==================== ESTABLECER CONEXIÓN ====================
$pdo = null;

try {
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    
    // Verificar conexión con ping simple
    $pdo->query('SELECT 1')->fetchColumn();
    
    // Log opcional en desarrollo
    if (isDev()) {
        error_log("✅ DB connected: " . DB_NAME);
    }
    
} catch (PDOException $e) {
    // Log interno seguro (ocultar credenciales)
    $errorContext = [
        'timestamp' => date('c'),
        'error' => $e->getMessage(),
        'file' => $e->getFile(),
        'line' => $e->getLine(),
        'dsn' => preg_replace('/password=[^&]+/', 'password=***', $dsn)
    ];
    
    error_log("DB Connection Error: " . json_encode($errorContext));
    auditLog('db_connection_failed', ['error' => $e->getMessage()]);
    
    // Respuesta genérica al cliente
    if (!headers_sent()) {
        http_response_code(503);
        header('Content-Type: application/json; charset=utf-8');
    }
    echo json_encode(['success' => false, 'message' => 'Error de conexión al servidor']);
    exit;
}

// ==================== FUNCIONES AUXILIARES SEGURAS ====================

/**
 * Ejecuta consulta con manejo de errores y auditoría opcional
 * @param PDO $pdo
 * @param string $sql
 * @param array $params
 * @param string|null $auditAction Acción para auditoría (opcional)
 * @return PDOStatement|false
 */
function safeQuery(PDO $pdo, string $sql, array $params = [], ?string $auditAction = null) {
    try {
        $start = microtime(true);
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $duration = round((microtime(true) - $start) * 1000, 2);
        
        // Auditoría opcional de consultas lentas
        if ($auditAction && $duration > 1000) { // >1 segundo
            auditLog('slow_query', [
                'action' => $auditAction,
                'duration_ms' => $duration,
                'sql' => substr($sql, 0, 200) . '...'
            ]);
        }
        
        return $stmt;
    } catch (PDOException $e) {
        error_log("Query Error: {$e->getMessage()} | SQL: " . substr($sql, 0, 200));
        auditLog('query_failed', ['error' => $e->getMessage(), 'sql' => substr($sql, 0, 200)]);
        return false;
    }
}

/**
 * Obtiene un único registro por ID con validación de tabla
 * @param PDO $pdo
 * @param string $table
 * @param int|string $id
 * @param string $column
 * @return array|false
 * @throws InvalidArgumentException si la tabla no es permitida
 */
function fetchById(PDO $pdo, string $table, $id, string $column = 'id') {
    validateTableName($table);
    $safeColumn = escapeIdentifier($column);
    
    $sql = "SELECT * FROM `{$table}` WHERE {$safeColumn} = ? LIMIT 1";
    $stmt = safeQuery($pdo, $sql, [$id]);
    return $stmt ? $stmt->fetch() : false;
}

/**
 * Inserta registro con validación y retorna ID generado
 * @param PDO $pdo
 * @param string $table
 * @param array $data
 * @return int|false ID insertado o false en error
 * @throws InvalidArgumentException si la tabla no es permitida
 */
function insertRecord(PDO $pdo, string $table, array $data) {
    validateTableName($table);
    
    // Filtrar y sanitizar claves
    $columns = array_map('escapeIdentifier', array_keys($data));
    $placeholders = implode(', ', array_fill(0, count($data), '?'));
    
    $sql = "INSERT INTO `{$table}` (" . implode(', ', $columns) . ") VALUES ({$placeholders})";
    
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute(array_values($data));
        
        auditLog('record_inserted', ['table' => $table, 'id' => $pdo->lastInsertId()]);
        return $pdo->lastInsertId();
    } catch (PDOException $e) {
        error_log("Insert Error [{$table}]: {$e->getMessage()}");
        auditLog('insert_failed', ['table' => $table, 'error' => $e->getMessage()]);
        return false;
    }
}

/**
 * Actualiza registro por ID con validación
 * @param PDO $pdo
 * @param string $table
 * @param int|string $id
 * @param array $data
 * @param string $column
 * @return bool
 * @throws InvalidArgumentException si la tabla no es permitida
 */
function updateRecord(PDO $pdo, string $table, $id, array $data, string $column = 'id'): bool {
    validateTableName($table);
    
    // Construir SET clause con columnas validadas
    $setParts = [];
    foreach (array_keys($data) as $col) {
        $setParts[] = escapeIdentifier($col) . ' = ?';
    }
    
    $sql = "UPDATE `{$table}` SET " . implode(', ', $setParts) . " WHERE " . escapeIdentifier($column) . " = ?";
    
    try {
        $params = array_values($data);
        $params[] = $id;
        
        $stmt = $pdo->prepare($sql);
        $result = $stmt->execute($params);
        
        if ($result) {
            auditLog('record_updated', ['table' => $table, 'id' => $id]);
        }
        return $result;
    } catch (PDOException $e) {
        error_log("Update Error [{$table}]: {$e->getMessage()}");
        auditLog('update_failed', ['table' => $table, 'error' => $e->getMessage()]);
        return false;
    }
}

/**
 * Elimina registro por ID con validación
 * @param PDO $pdo
 * @param string $table
 * @param int|string $id
 * @param string $column
 * @return bool
 * @throws InvalidArgumentException si la tabla no es permitida
 */
function deleteRecord(PDO $pdo, string $table, $id, string $column = 'id'): bool {
    validateTableName($table);
    
    $sql = "DELETE FROM `{$table}` WHERE " . escapeIdentifier($column) . " = ?";
    
    try {
        $stmt = $pdo->prepare($sql);
        $result = $stmt->execute([$id]);
        
        if ($result) {
            auditLog('record_deleted', ['table' => $table, 'id' => $id]);
        }
        return $result;
    } catch (PDOException $e) {
        error_log("Delete Error [{$table}]: {$e->getMessage()}");
        auditLog('delete_failed', ['table' => $table, 'error' => $e->getMessage()]);
        return false;
    }
}

/**
 * Ejecuta transacción con callback (patrón Unit of Work)
 * @param PDO $pdo
 * @param callable $callback
 * @return mixed Resultado del callback o false si falla
 */
function withTransaction(PDO $pdo, callable $callback) {
    try {
        $pdo->beginTransaction();
        $result = $callback($pdo);
        $pdo->commit();
        return $result;
    } catch (Exception $e) {
        $pdo->rollBack();
        error_log("Transaction failed: " . $e->getMessage());
        auditLog('transaction_failed', ['error' => $e->getMessage()]);
        return false;
    }
}

/**
 * Obtiene contador de registros con filtros dinámicos seguros
 * @param PDO $pdo
 * @param string $table
 * @param array $filters [column => value]
 * @return int
 */
function countRecords(PDO $pdo, string $table, array $filters = []): int {
    validateTableName($table);
    
    $sql = "SELECT COUNT(*) as total FROM `{$table}` WHERE 1=1";
    $params = [];
    
    foreach ($filters as $column => $value) {
        $sql .= " AND " . escapeIdentifier($column) . " = ?";
        $params[] = $value;
    }
    
    $stmt = safeQuery($pdo, $sql, $params);
    return $stmt ? (int)$stmt->fetch()['total'] : 0;
}

/**
 * Paginación segura con offset y limit
 * @param PDO $pdo
 * @param string $table
 * @param int $page
 * @param int $limit
 * @param string $orderBy
 * @param string $orderDir
 * @param array $filters
 * @return array { data: [], pagination: {} }
 */
function paginateRecords(PDO $pdo, string $table, int $page = 1, int $limit = 20, 
                        string $orderBy = 'id', string $orderDir = 'DESC', array $filters = []): array {
    validateTableName($table);
    $page = max(1, $page);
    $limit = min(100, $limit); // Máximo 100 por página
    $offset = ($page - 1) * $limit;
    
    // Validar columnas de ordenamiento permitidas
    $allowedOrder = ['id', 'created_at', 'updated_at', 'nombre', 'email', 'estado'];
    $orderBy = in_array($orderBy, $allowedOrder, true) ? $orderBy : 'id';
    $orderDir = strtoupper($orderDir) === 'ASC' ? 'ASC' : 'DESC';
    
    // Construir WHERE clause
    $whereParts = [];
    $params = [];
    foreach ($filters as $column => $value) {
        if (in_array($column, $allowedOrder, true) || $column === 'status') {
            $whereParts[] = escapeIdentifier($column) . " = ?";
            $params[] = $value;
        }
    }
    $whereClause = $whereParts ? "WHERE " . implode(' AND ', $whereParts) : '';
    
    // Consulta principal
    $sql = "SELECT * FROM `{$table}` {$whereClause} ORDER BY {$orderBy} {$orderDir} LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    
    $stmt = safeQuery($pdo, $sql, $params);
    $data = $stmt ? $stmt->fetchAll() : [];
    
    // Contar total para paginación
    $countSql = "SELECT COUNT(*) as total FROM `{$table}` {$whereClause}";
    $countParams = array_filter($params, fn($k) => $k < count($params) - 2, ARRAY_FILTER_USE_KEY);
    $totalStmt = safeQuery($pdo, $countSql, array_values($countParams));
    $total = $totalStmt ? (int)$totalStmt->fetch()['total'] : 0;
    
    return [
        'data' => $data,
        'pagination' => [
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'pages' => (int)ceil($total / $limit),
            'has_next' => $page < ceil($total / $limit),
            'has_prev' => $page > 1
        ]
    ];
}