<?php
/**
 * CONFIGURACIÓN GLOBAL DEL BACKEND (Práctica 1 U3)
 * Centraliza constantes, seguridad, sesiones y entorno
 * 
 * @package BarberMonkey\Config
 */

// ==================== DETECCIÓN DE ENTORNO ====================
/**
 * Verifica si estamos en entorno de desarrollo
 * @return bool
 */
if (!function_exists('isDev')) {
    function isDev(): bool {
        $host = $_SERVER['HTTP_HOST'] ?? '';
        $ip = $_SERVER['SERVER_ADDR'] ?? '';
        return in_array($host, ['localhost', '127.0.0.1', '::1'], true) || 
               in_array($ip, ['127.0.0.1', '::1'], true);
    }
}

// ==================== CONFIGURACIÓN DE SESIONES ====================
// ⚠️ session_name DEBE ir ANTES de session_start
session_name('bm_sess');

session_start([
    'cookie_httponly' => true,
    'cookie_secure' => !isDev(),
    'cookie_samesite' => 'Lax',
    'use_strict_mode' => true,
    'lazy_write' => true,
    'gc_maxlifetime' => 604800
]);

// ==================== BASE DE DATOS ====================
define('DB_HOST', 'localhost');
define('DB_NAME', 'barbermonkey_auth');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');
define('DB_DSN', 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET);

// ==================== JWT Y TOKENS ====================
define('JWT_SECRET', getenv('JWT_SECRET') ?: 'IDGS8B_SuperSecretKey_2026_ChangeInProduction!');
define('JWT_ALGO', 'HS256');
define('JWT_EXPIRE', 900); // 15 min
define('REFRESH_EXPIRE', 604800); // 7 días

// ==================== MFA Y RECUPERACIÓN (Práctica 1 U3) ====================
define('MFA_CODE_LENGTH', 6);
define('MFA_CODE_EXPIRY', 300); // 5 min
define('MFA_MAX_ATTEMPTS', 3);
define('RESET_TOKEN_EXPIRY', 3600); // 1 hora
define('RESET_TOKEN_LENGTH', 64);
define('EMAIL_VERIFY_TOKEN_EXPIRY', 86400); // 24 horas
define('SESSION_IDLE_TIMEOUT', 1800); // 30 min inactividad

// ==================== URLS Y RUTAS ====================
define('SITE_URL', getenv('SITE_URL') ?: 'http://localhost/barbermonkey/');
define('API_URL', SITE_URL . 'server/');
define('ASSETS_URL', SITE_URL . 'assets/');

// ==================== SEGURIDAD ====================
define('RATE_LIMIT_LOGIN', ['max' => 5, 'window' => 15 * 60 * 1000]);
define('RATE_LIMIT_REGISTER', ['max' => 3, 'window' => 60 * 60 * 1000]);
define('RATE_LIMIT_RECOVERY', ['max' => 3, 'window' => 60 * 60 * 1000]);

define('PASSWORD_MIN_LENGTH', 8);
define('PASSWORD_REQUIRE_UPPER', true);
define('PASSWORD_REQUIRE_LOWER', true);
define('PASSWORD_REQUIRE_NUMBER', true);
define('PASSWORD_REQUIRE_SPECIAL', false);

// ==================== EMAIL (Para recuperación/MFA) ====================
define('MAIL_FROM', getenv('MAIL_FROM') ?: 'noreply@barbermonkey.com');
define('MAIL_FROM_NAME', getenv('MAIL_FROM_NAME') ?: 'BarberMonkey');
define('SMTP_HOST', getenv('SMTP_HOST') ?: 'localhost');
define('SMTP_PORT', getenv('SMTP_PORT') ?: 587);
define('SMTP_SECURE', getenv('SMTP_SECURE') ?: 'tls');

// ==================== ARCHIVOS (Si aplica) ====================
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('UPLOAD_MAX_SIZE', 5 * 1024 * 1024); // 5MB
define('UPLOAD_ALLOWED_TYPES', ['image/jpeg', 'image/png', 'image/gif', 'image/webp']);
define('UPLOAD_ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif', 'webp']);

// ==================== CABECERAS DE SEGURIDAD ====================
if (!headers_sent()) {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('X-XSS-Protection: 1; mode=block');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
    
    $cspDirectives = [
        "default-src 'self'",
        "script-src 'self'" . (isDev() ? " 'unsafe-inline' 'unsafe-eval'" : ""),
        "style-src 'self'" . (isDev() ? " 'unsafe-inline'" : ""),
        "img-src 'self' https: data:",
        "font-src 'self' https:",
        "connect-src 'self' https:",
        "frame-ancestors 'none'",
        "form-action 'self'"
    ];
    header('Content-Security-Policy: ' . implode('; ', $cspDirectives));
    
    if (!isDev() && isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
}

// ==================== REPORTES DE ERRORES ====================
if (isDev()) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    ini_set('log_errors', 1);
    ini_set('error_log', __DIR__ . '/../logs/php_errors.log');
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
    ini_set('log_errors', 1);
    ini_set('error_log', __DIR__ . '/../logs/php_errors.log');
    
    set_error_handler(function($errno, $errstr, $errfile, $errline) {
        error_log("[$errno] $errstr in $errfile on line $errline");
        return true;
    });
}

// ==================== ZONA HORARIA ====================
date_default_timezone_set('America/Mexico_City');

// ==================== FUNCIONES AUXILIARES ====================

function sanitizeRedirect(string $url): ?string {
    if (preg_match('#^https?://#i', $url) && strpos($url, SITE_URL) !== 0) {
        return null;
    }
    return filter_var($url, FILTER_SANITIZE_URL) ?: null;
}

function generateCsrfToken(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCsrfToken(string $token): bool {
    return hash_equals($_SESSION['csrf_token'] ?? '', $token);
}

function auditLog(string $action, array $context = []): void {
    $logEntry = [
        'timestamp' => date('c'),
        'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        'action' => $action,
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
        'context' => array_filter($context, function($k) {
            return !in_array(strtolower($k), ['password', 'token', 'secret', 'key'], true);
        }, ARRAY_FILTER_USE_KEY)
    ];
    
    $logFile = __DIR__ . '/../logs/audit.log';
    if (!is_dir(dirname($logFile))) {
        mkdir(dirname($logFile), 0755, true);
    }
    file_put_contents($logFile, json_encode($logEntry) . PHP_EOL, FILE_APPEND | LOCK_EX);
}

function getUserIP(): string {
    $ipKeys = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'];
    foreach ($ipKeys as $key) {
        if (!empty($_SERVER[$key])) {
            $ip = explode(',', $_SERVER[$key])[0];
            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                return $ip;
            }
        }
    }
    return '0.0.0.0';
}

/**
 * Valida contraseña contra política definida
 * @param string $password
 * @return array { valid: bool, errors: string[] }
 */
function validatePasswordPolicy(string $password): array {
    $errors = [];
    
    if (strlen($password) < PASSWORD_MIN_LENGTH) {
        $errors[] = "Mínimo " . PASSWORD_MIN_LENGTH . " caracteres";
    }
    if (PASSWORD_REQUIRE_UPPER && !preg_match('/[A-Z]/', $password)) {
        $errors[] = "Al menos una letra mayúscula";
    }
    if (PASSWORD_REQUIRE_LOWER && !preg_match('/[a-z]/', $password)) {
        $errors[] = "Al menos una letra minúscula";
    }
    if (PASSWORD_REQUIRE_NUMBER && !preg_match('/[0-9]/', $password)) {
        $errors[] = "Al menos un número";
    }
    if (PASSWORD_REQUIRE_SPECIAL && !preg_match('/[^A-Za-z0-9]/', $password)) {
        $errors[] = "Al menos un carácter especial";
    }
    
    return ['valid' => empty($errors), 'errors' => $errors];
}

/**
 * Obtiene configuración con fallback (feature flags)
 * @param string $key
 * @param mixed $default
 * @return mixed
 */
function getConfig(string $key, $default = null) {
    $config = [
        'features.mfa_enabled' => true,
        'features.sso_enabled' => false,
        'features.dark_mode' => true,
        'app.maintenance' => false,
        'app.version' => '1.0.0'
    ];
    return $config[$key] ?? $default;
}