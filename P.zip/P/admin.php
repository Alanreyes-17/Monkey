<?php 
$page = 'admin'; 
// Cargar configuración para CSRF y funciones de seguridad
require_once 'server/config.php'; 

// 🔐 Protección de ruta (comentario para implementación backend)
// En producción: descomentar y usar requireAuth(['admin', 'editor']) desde middleware.php
// $user = requireAuth(['admin', 'editor']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Panel de Administración - BarberMonkey">
    
    <!-- Token CSRF para seguridad en formularios -->
    <meta name="csrf-token" content="<?= generateCsrfToken() ?>">
    
    <title>Admin - BarberMonkey</title>
    
    <!-- CSS: Orden correcto para cascada de estilos -->
    <link rel="stylesheet" href="css/base.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/animations.css">
</head>
<body>
    <!-- HEADER & NAV -->
    <header>
        <div class="container nav-wrapper">
            <a href="index.php" class="logo" aria-label="Ir al inicio">
                <span aria-hidden="true">🐒</span> BarberMonkey
            </a>
            
            <nav aria-label="Navegación principal">
                <ul>
                    <li><a href="index.php">Inicio</a></li>
                    <li>
                        <a href="servicios.php" aria-haspopup="true">Servicios</a>
                        <ul aria-label="Submenú de servicios">
                            <li><a href="servicios.php#corte-pelo">Corte de Pelo</a></li>
                            <li><a href="servicios.php#barba">Barba</a></li>
                            <li><a href="servicios.php#afeitado">Afeitado</a></li>
                        </ul>
                    </li>
                    <li><a href="barberos.php">Equipo</a></li>
                    <li><a href="reservas.php">Agendar Cita</a></li>
                    <!-- 🔐 Admin: Visible solo para admin/editor (RBAC visual) -->
                    <li><a href="admin.php" class="active" data-role="admin,editor" aria-current="page">🔐 Admin</a></li>
                </ul>
            </nav>
            
            <!-- 🔑 Contenedor de autenticación (se llena con JS) -->
            <div class="auth-buttons">
                <div id="auth-container"></div>
            </div>
            
            <!-- Botón de modo oscuro -->
            <button id="theme-toggle" class="magnetic-btn" aria-label="Cambiar modo oscuro/claro" title="Cambiar tema">🌙</button>
        </div>
    </header>

    <!-- BREADCRUMBS -->
    <div class="container">
        <nav id="breadcrumbs" aria-label="Migas de pan">
            <a href="index.php">Inicio</a> <span aria-hidden="true">/</span> <span>Panel de Administración</span>
        </nav>
    </div>

    <!-- MAIN CONTENT -->
    <main class="container section">
        <h1 class="section-title">👤 Panel de Administración</h1>
        
        <!-- Mensaje de acceso denegado (oculto por defecto, se muestra con JS si no tiene rol) -->
        <div id="access-denied" class="card" style="display:none;padding:2rem;text-align:center;margin-bottom:2rem;">
            <span style="font-size:3rem;">🚫</span>
            <h2 style="color:var(--danger);margin:1rem 0;">Acceso Denegado</h2>
            <p>No tienes permisos para ver esta sección.</p>
            <a href="index.php" class="btn" style="margin-top:1rem;">← Volver al inicio</a>
        </div>
        
        <!-- Contenido protegido (se oculta si no tiene rol) -->
        <div id="admin-content">
            <!-- Estadísticas rápidas (se llenan con JS) -->
            <div id="admin-stats" class="grid-3" style="margin-bottom:2rem;" aria-live="polite"></div>

            <!-- FORMULARIO DE GESTIÓN DE CITAS -->
            <section class="card" style="padding:2rem;margin-bottom:2rem;">
                <h2 style="color:var(--primary);margin-bottom:1.5rem;">✏️ Gestión de Citas</h2>
                
                <form id="cita-form" novalidate aria-label="Formulario de gestión de citas">
                    <!-- Token CSRF oculto para seguridad -->
                    <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                    <input type="hidden" id="cita-id">
                    
                    <div class="grid-3">
                        <div class="form-group">
                            <label for="nombre">Cliente <span aria-hidden="true">*</span></label>
                            <input type="text" id="nombre" name="nombre" required autocomplete="name" placeholder="Ej: Juan Pérez">
                            <span class="error-msg" id="nombre-error" role="alert" aria-live="polite"></span>
                        </div>
                        <div class="form-group">
                            <label for="email">Email <span aria-hidden="true">*</span></label>
                            <input type="email" id="email" name="email" required autocomplete="email" placeholder="ejemplo@correo.com">
                            <span class="error-msg" id="email-error" role="alert" aria-live="polite"></span>
                        </div>
                        <div class="form-group">
                            <label for="servicio">Servicio <span aria-hidden="true">*</span></label>
                            <select id="servicio" name="servicio" required>
                                <option value="">Seleccionar...</option>
                                <option value="Corte de Pelo">Corte de Pelo</option>
                                <option value="Barba">Arreglo de Barba</option>
                                <option value="Afeitado">Afeitado Clásico</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="grid-3">
                        <div class="form-group">
                            <label for="barbero">Barbero (Opcional)</label>
                            <select id="barbero" name="barbero">
                                <option value="">Sin preferencia</option>
                                <option value="Juan Pérez">Juan Pérez</option>
                                <option value="Pedro García">Pedro García</option>
                                <option value="Carlos López">Carlos López</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="estado">Estado</label>
                            <select id="estado" name="estado">
                                <option value="Pendiente">Pendiente</option>
                                <option value="Completado">Completado</option>
                                <option value="Cancelado">Cancelado</option>
                            </select>
                        </div>
                        <div class="form-group captcha-box">
                            <label for="captcha-input">🛡️ Verificación <span aria-hidden="true">*</span></label>
                            <span id="captcha-question" aria-live="polite"></span>
                            <input type="number" id="captcha-input" name="captcha" required style="width:80px;" inputmode="numeric" placeholder="?">
                            <span class="error-msg" id="captcha-input-error" role="alert" aria-live="polite"></span>
                        </div>
                    </div>
                    
                    <button type="submit" id="btn-submit" class="btn magnetic-btn">💾 Guardar Cita</button>
                </form>
            </section>

            <!-- BÚSQUEDA Y FILTROS -->
            <section class="card" style="padding:2rem;">
                <h2 style="color:var(--primary);margin-bottom:1.5rem;">🔍 Buscar y Filtrar</h2>
                
                <div class="search-bar" role="search">
                    <label for="search-simple" class="visually-hidden">Buscar citas</label>
                    <input type="text" id="search-simple" placeholder="Buscar por cliente, email o servicio..." autocomplete="off">
                    
                    <label for="filter-estado" class="visually-hidden">Filtrar por estado</label>
                    <select id="filter-estado">
                        <option value="all">Todos los estados</option>
                        <option value="Pendiente">Pendiente</option>
                        <option value="Completado">Completado</option>
                        <option value="Cancelado">Cancelado</option>
                    </select>
                    
                    <label for="filter-fecha" class="visually-hidden">Filtrar por fecha</label>
                    <input type="date" id="filter-fecha">
                    
                    <label for="filter-sort" class="visually-hidden">Ordenar por</label>
                    <select id="filter-sort">
                        <option value="">Ordenar por...</option>
                        <option value="A-Z">Nombre (A-Z)</option>
                        <option value="Z-A">Nombre (Z-A)</option>
                        <option value="fecha">Fecha (más reciente)</option>
                    </select>
                </div>

                <!-- TABLA DE CITAS -->
                <div class="table-container">
                    <h3 style="margin:1.5rem 0 1rem;color:var(--primary);">📋 Citas Registradas</h3>
                    <table aria-label="Lista de citas registradas">
                        <thead>
                            <tr>
                                <th scope="col">Cliente</th>
                                <th scope="col">Email</th>
                                <th scope="col">Servicio</th>
                                <th scope="col">Barbero</th>
                                <th scope="col">Estado</th>
                                <th scope="col">Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="citas-list" aria-live="polite">
                            <!-- Se llena dinámicamente con JS -->
                            <tr>
                                <td colspan="6" class="text-center" style="padding:2rem;">Cargando citas...</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </section>
        </div>
    </main>

    <!-- FOOTER -->
    <footer>
        <div class="container footer-grid">
            <div>
                <h4>BarberMonkey</h4>
                <p>Tu barbería de confianza desde 2020.</p>
            </div>
            <div>
                <h4>Enlaces</h4>
                <ul>
                    <li><a href="index.php">Inicio</a></li>
                    <li><a href="servicios.php">Servicios</a></li>
                    <li><a href="barberos.php">Equipo</a></li>
                    <li><a href="admin.php" data-role="admin,editor">Admin</a></li>
                    <li><a href="login.php">Iniciar Sesión</a></li>
                </ul>
            </div>
            <div>
                <h4>Contacto</h4>
                <p>📍 Av. Principal 123</p>
                <p>📞 +52 123 456 7890</p>
                <p>✉️ info@barbermonkey.com</p>
            </div>
        </div>
        <div class="container footer-bottom">
            <p>© 2026 BarberMonkey | Desarrollado para IDGS 8B - UTA</p>
        </div>
    </footer>

    <!-- SCRIPTS: Cargar al final para mejor rendimiento -->
    <script type="module" src="js/app.js"></script>
    
    <!-- Fallback para usuarios sin JavaScript -->
    <noscript>
        <style>
            .scroll-reveal { opacity: 1 !important; transform: none !important; }
            #citas-list td { text-align: center; padding: 2rem; }
            #auth-container { display: none; }
        </style>
        <div class="container" style="text-align:center;padding:1rem;background:var(--surface);border-radius:8px;margin:1rem 0;">
            <p>⚠️ El panel de administración requiere JavaScript para funcionar correctamente.</p>
            <p><a href="login.php" style="color:var(--primary);">🔐 Iniciar Sesión</a></p>
        </div>
    </noscript>
    
    <!-- Estilos utilitarios para accesibilidad -->
    <style>
        .visually-hidden {
            position: absolute;
            width: 1px;
            height: 1px;
            padding: 0;
            margin: -1px;
            overflow: hidden;
            clip: rect(0, 0, 0, 0);
            white-space: nowrap;
            border: 0;
        }
    </style>
    
    <!-- Script para protección frontend (RBAC visual) -->
    <script>
        // Ejecutar protección básica si JS está deshabilitado o como fallback
        document.addEventListener('DOMContentLoaded', function() {
            // Nota: La protección real debe hacerse en backend con middleware
            // Esto es solo para mejorar la experiencia de usuario
            const adminLinks = document.querySelectorAll('[data-role]');
            // Los enlaces se muestran/ocultan vía js/app.js → updateAuthNav()
        });
    </script>
</body>
</html>