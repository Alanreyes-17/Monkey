<?php 
$page = 'reservas'; 
// Cargar configuración para CSRF y funciones de seguridad
require_once 'server/config.php'; 
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Agenda tu cita en BarberMonkey - Cortes, barba y afeitado profesional.">
    
    <!-- Token CSRF para seguridad en formularios -->
    <meta name="csrf-token" content="<?= generateCsrfToken() ?>">
    
    <title>Reservaciones - BarberMonkey</title>
    
    <!-- CSS: Orden correcto para cascada de estilos -->
    <link rel="stylesheet" href="css/base.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/animations.css">
</head>
<body>
    <!-- HEADER & NAV -->
    <header>
        <div class="container nav-wrapper">
            <a href="index.php" class="logo" aria-label="Ir al inicio">
                <span aria-hidden="true">🐒</span> BarberMonkey
            </a>
            
            <nav aria-label="Navegación principal">
                <ul>
                    <li><a href="index.php">Inicio</a></li>
                    <li><a href="servicios.php">Servicios</a></li>
                    <li><a href="barberos.php">Equipo</a></li>
                    <li><a href="reservas.php" class="active" aria-current="page">Agendar Cita</a></li>
                    <li><a href="admin.php" data-role="admin,editor">🔐 Admin</a></li>
                </ul>
            </nav>
            
            <!-- Botón de modo oscuro con clase magnetic para animación -->
            <button id="theme-toggle" class="magnetic-btn" aria-label="Cambiar modo oscuro/claro" title="Cambiar tema">🌙</button>
        </div>
    </header>

    <!-- BREADCRUMBS -->
    <div class="container">
        <nav id="breadcrumbs" aria-label="Migas de pan">
            <a href="index.php">Inicio</a> <span aria-hidden="true">/</span> <span>Agendar Cita</span>
        </nav>
    </div>

    <!-- MAIN CONTENT -->
    <main class="container section">
        <h1 class="section-title">📅 Agendar Cita</h1>
        
        <article class="card" style="max-width:700px;margin:0 auto;padding:2rem;">
            <p style="margin-bottom:1.5rem;text-align:center;">Completa tus datos para confirmar la reserva.</p>
            
            <form id="reserva-form" novalidate aria-label="Formulario de reserva de cita">
                <!-- Token CSRF oculto para seguridad -->
                <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                
                <div class="form-group">
                    <label for="nombre">Nombre Completo <span aria-hidden="true">*</span></label>
                    <input type="text" id="nombre" name="nombre" required autocomplete="name" placeholder="Ej: Juan Pérez">
                    <span class="error-msg" id="nombre-error" role="alert" aria-live="polite"></span>
                </div>
                
                <div class="form-group">
                    <label for="email">Correo Electrónico <span aria-hidden="true">*</span></label>
                    <input type="email" id="email" name="email" required autocomplete="email" placeholder="ejemplo@correo.com">
                    <span class="error-msg" id="email-error" role="alert" aria-live="polite"></span>
                </div>
                
                <div class="form-group">
                    <label for="telefono">Teléfono (Móvil) <span aria-hidden="true">*</span></label>
                    <input type="tel" id="telefono" name="telefono" required pattern="[0-9]{10}" inputmode="numeric" placeholder="10 dígitos sin espacios">
                    <span class="error-msg" id="telefono-error" role="alert" aria-live="polite"></span>
                </div>
                
                <div class="form-group">
                    <label for="servicio">Servicio <span aria-hidden="true">*</span></label>
                    <select id="servicio" name="servicio" required>
                        <option value="">Selecciona...</option>
                        <option value="Corte de Pelo">Corte de Pelo</option>
                        <option value="Arreglo de Barba">Arreglo de Barba</option>
                        <option value="Afeitado Tradicional">Afeitado Tradicional</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="barbero">Barbero (Opcional)</label>
                    <select id="barbero" name="barbero">
                        <option value="">Sin preferencia</option>
                        <option value="Juan Pérez">Juan Pérez</option>
                        <option value="Pedro García">Pedro García</option>
                        <option value="Carlos López">Carlos López</option>
                    </select>
                </div>
                
                <!-- Sección de contraseña para gestión futura de la cita -->
                <div class="form-group">
                    <label for="password">Contraseña (para gestionar tu cita) <span aria-hidden="true">*</span></label>
                    <input type="password" id="password" name="password" required 
                           pattern="^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$"
                           title="Mínimo 8 caracteres, 1 letra y 1 número"
                           autocomplete="new-password">
                    <small style="color:var(--text-muted);display:block;margin-top:0.3rem;">
                        Mínimo 8 caracteres, 1 letra y 1 número.
                    </small>
                    <span class="error-msg" id="password-error" role="alert" aria-live="polite"></span>
                </div>
                
                <div class="form-group">
                    <label for="confirmPassword">Confirmar Contraseña <span aria-hidden="true">*</span></label>
                    <input type="password" id="confirmPassword" name="confirmPassword" required autocomplete="new-password">
                    <span class="error-msg" id="confirmPassword-error" role="alert" aria-live="polite"></span>
                </div>
                
                <!-- CAPTCHA de verificación humana -->
                <div class="captcha-box" role="group" aria-label="Verificación de seguridad">
                    <label for="captcha-input">🛡️ Verificación <span aria-hidden="true">*</span></label>
                    <span id="captcha-question" aria-live="polite"></span>
                    <input type="number" id="captcha-input" name="captcha" required style="width:80px;" inputmode="numeric" aria-describedby="captcha-question">
                    <span class="error-msg" id="captcha-input-error" role="alert" aria-live="polite"></span>
                </div>
                
                <button type="submit" class="btn magnetic-btn" style="width:100%;padding:1rem;font-size:1.1rem;margin-top:1rem;">
                    ✅ Confirmar Reserva
                </button>
            </form>
        </article>
        
        <!-- Información adicional -->
        <section style="max-width:700px;margin:2rem auto 0;text-align:center;color:var(--text-muted);">
            <p>🔒 Tus datos están protegidos. Recibirás confirmación por correo.</p>
            <p><small>¿Necesitas ayuda? <a href="tel:+521234567890">📞 +52 123 456 7890</a></small></p>
        </section>
    </main>

    <!-- FOOTER -->
    <footer>
        <div class="container footer-grid">
            <div>
                <h4>BarberMonkey</h4>
                <p>Tu barbería de confianza desde 2020.</p>
            </div>
            <div>
                <h4>Enlaces</h4>
                <ul>
                    <li><a href="index.php">Inicio</a></li>
                    <li><a href="servicios.php">Servicios</a></li>
                    <li><a href="barberos.php">Equipo</a></li>
                    <li><a href="reservas.php">Reservas</a></li>
                </ul>
            </div>
            <div>
                <h4>Contacto</h4>
                <p>📍 Av. Principal 123</p>
                <p>📞 +52 123 456 7890</p>
                <p>✉️ info@barbermonkey.com</p>
            </div>
        </div>
        <div class="container footer-bottom">
            <p>© 2026 BarberMonkey | Desarrollado para IDGS 8B - UTA</p>
        </div>
    </footer>

    <!-- SCRIPTS: Cargar al final para mejor rendimiento -->
    <script type="module" src="js/app.js"></script>
    
    <!-- Fallback para usuarios sin JavaScript -->
    <noscript>
        <style>
            .scroll-reveal { opacity: 1 !important; transform: none !important; }
            .captcha-box { display: none; }
        </style>
        <div class="container" style="text-align:center;padding:1rem;background:var(--surface);border-radius:8px;margin:1rem 0;max-width:700px;">
            <p>⚠️ Para confirmar tu reserva, necesitas tener JavaScript habilitado.</p>
            <p><small>Esto nos permite verificar que eres una persona real y proteger tus datos.</small></p>
        </div>
    </noscript>
    
    <!-- Estilos utilitarios para accesibilidad -->
    <style>
        .visually-hidden {
            position: absolute;
            width: 1px;
            height: 1px;
            padding: 0;
            margin: -1px;
            overflow: hidden;
            clip: rect(0, 0, 0, 0);
            white-space: nowrap;
            border: 0;
        }
    </style>
</body>
</html>