/**
 * MÓDULO DE CARRUSEL AVANZADO (Práctica 2 U2)
 * Autoplay, controles, indicadores, touch, loop infinito, pausa al hover
 * 
 * @module Carousel
 */

import { CONFIG } from './config.js';

export class Carousel {
    /**
     * Crea una nueva instancia de Carousel
     * @param {HTMLElement} container - Elemento contenedor del carrusel
     * @param {Object} options - Configuración opcional
     */
    constructor(container, options = {}) {
        if (!container) {
            console.error('Carousel: contenedor no encontrado');
            return;
        }

        this.container = container;
        this.track = container.querySelector('.track') || container.querySelector('.carousel-track');
        this.slides = container.querySelectorAll('.slide');
        this.dotsContainer = container.querySelector('.dots') || container.querySelector('.carousel-indicators');
        this.prevBtn = container.querySelector('.prev') || container.querySelector('.carousel-btn.prev');
        this.nextBtn = container.querySelector('.next') || container.querySelector('.carousel-btn.next');

        // Configuración con valores por defecto
        this.config = {
            autoplay: true,
            autoplayDelay: options.autoplayDelay || 5000,
            loop: options.loop !== false,
            touchEnabled: options.touchEnabled !== false,
            pauseOnHover: options.pauseOnHover !== false,
            animationDuration: options.animationDuration || 500,
            ...options
        };

        // Estado interno
        this.currentIndex = 0;
        this.isPlaying = this.config.autoplay;
        this.intervalId = null;
        this.isTransitioning = false;

        // Inicializar
        if (this.track && this.slides.length > 0) {
            this.init();
        } else {
            console.warn('Carousel: elementos requeridos no encontrados');
        }
    }

    /**
     * Inicializa el carrusel: indicadores, eventos, autoplay
     * @private
     */
    init() {
        this._createIndicators();
        this._bindEvents();
        this._setupTouch();
        
        if (this.config.autoplay) {
            this._startAutoplay();
        }
        
        if (this.config.pauseOnHover) {
            this._setupPauseOnHover();
        }

        // Actualizar estado inicial
        this._updateActiveSlide();
    }

    /**
     * Crea los indicadores (puntos) dinámicamente
     * @private
     */
    _createIndicators() {
        if (!this.dotsContainer) return;

        this.dotsContainer.innerHTML = '';
        
        this.slides.forEach((_, index) => {
            const dot = document.createElement('button');
            dot.className = `dot ${index === 0 ? 'active' : ''}`;
            dot.setAttribute('aria-label', `Ir a diapositiva ${index + 1}`);
            dot.setAttribute('type', 'button');
            dot.addEventListener('click', (e) => {
                e.preventDefault();
                this.goTo(index);
            });
            this.dotsContainer.appendChild(dot);
        });
    }

    /**
     * Vincula eventos de navegación
     * @private
     */
    _bindEvents() {
        if (this.prevBtn) {
            this.prevBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.prev();
            });
        }

        if (this.nextBtn) {
            this.nextBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.next();
            });
        }

        // Soporte teclado
        this.container.addEventListener('keydown', (e) => {
            if (e.key === 'ArrowLeft') this.prev();
            if (e.key === 'ArrowRight') this.next();
        });
    }

    /**
     * Configura soporte táctil para móviles
     * @private
     */
    _setupTouch() {
        if (!this.config.touchEnabled || !this.track) return;

        let startX = 0;
        let startY = 0;

        this.track.addEventListener('touchstart', (e) => {
            startX = e.touches[0].clientX;
            startY = e.touches[0].clientY;
            this.pause();
        }, { passive: true });

        this.track.addEventListener('touchend', (e) => {
            const endX = e.changedTouches[0].clientX;
            const endY = e.changedTouches[0].clientY;
            
            const diffX = startX - endX;
            const diffY = startY - endY;

            // Solo actuar si el deslizamiento fue horizontal y significativo
            if (Math.abs(diffX) > Math.abs(diffY) && Math.abs(diffX) > 50) {
                diffX > 0 ? this.next() : this.prev();
            }
            
            if (this.config.autoplay) {
                setTimeout(() => this.resume(), 3000);
            }
        }, { passive: true });
    }

    /**
     * Configura pausa al pasar el mouse
     * @private
     */
    _setupPauseOnHover() {
        this.container.addEventListener('mouseenter', () => this.pause());
        this.container.addEventListener('mouseleave', () => {
            if (this.config.autoplay) {
                setTimeout(() => this.resume(), 500);
            }
        });
    }

    /**
     * Inicia el autoplay
     * @private
     */
    _startAutoplay() {
        if (this.intervalId) clearInterval(this.intervalId);
        
        this.intervalId = setInterval(() => {
            if (this.isPlaying && !this.isTransitioning) {
                this.next();
            }
        }, this.config.autoplayDelay);
    }

    /**
     * Actualiza clases activas en slide e indicadores
     * @private
     */
    _updateActiveSlide() {
        // Actualizar slides
        this.slides.forEach((slide, index) => {
            slide.classList.toggle('active', index === this.currentIndex);
            slide.setAttribute('aria-hidden', index !== this.currentIndex);
        });

        // Actualizar indicadores
        if (this.dotsContainer) {
            this.dotsContainer.querySelectorAll('.dot').forEach((dot, index) => {
                dot.classList.toggle('active', index === this.currentIndex);
            });
        }

        // Disparar evento personalizado para que otros módulos escuchen
        this.container.dispatchEvent(new CustomEvent('carousel:change', {
            detail: { index: this.currentIndex, slide: this.slides[this.currentIndex] }
        }));
    }

    /**
     * Navega a una diapositiva específica
     * @param {number} index - Índice de la diapositiva
     */
    goTo(index) {
        if (this.isTransitioning) return;

        const total = this.slides.length;
        
        // Manejar loop infinito
        if (this.config.loop) {
            this.currentIndex = (index + total) % total;
        } else {
            this.currentIndex = Math.max(0, Math.min(index, total - 1));
        }

        this._transitionTo(this.currentIndex);
    }

    /**
     * Ejecuta la transición CSS al índice dado
     * @param {number} index 
     * @private
     */
    _transitionTo(index) {
        this.isTransitioning = true;
        
        if (this.track) {
            this.track.style.transition = `transform ${this.config.animationDuration}ms ease-in-out`;
            this.track.style.transform = `translateX(-${index * 100}%)`;
        }

        this._updateActiveSlide();

        // Resetear transición después de completar
        setTimeout(() => {
            if (this.track) {
                this.track.style.transition = '';
            }
            this.isTransitioning = false;
        }, this.config.animationDuration);
    }

    /**
     * Navega a la diapositiva anterior
     */
    prev() {
        this.goTo(this.currentIndex - 1);
    }

    /**
     * Navega a la siguiente diapositiva
     */
    next() {
        this.goTo(this.currentIndex + 1);
    }

    /**
     * Pausa el autoplay
     */
    pause() {
        this.isPlaying = false;
    }

    /**
     * Reanuda el autoplay
     */
    resume() {
        if (this.config.autoplay) {
            this.isPlaying = true;
            this._startAutoplay();
        }
    }

    /**
     * Detiene completamente el carrusel y limpia recursos
     */
    destroy() {
        if (this.intervalId) {
            clearInterval(this.intervalId);
            this.intervalId = null;
        }
        this.isPlaying = false;
        
        // Remover listeners si es necesario en producción
        this.container.dispatchEvent(new CustomEvent('carousel:destroy'));
    }

    /**
     * Obtiene el índice actual
     * @returns {number}
     */
    getCurrentIndex() {
        return this.currentIndex;
    }

    /**
     * Obtiene la diapositiva actual
     * @returns {HTMLElement|null}
     */
    getCurrentSlide() {
        return this.slides[this.currentIndex] || null;
    }
}

/**
 * Inicializa todos los carruseles en la página
 * @param {string} selector - Selector CSS para contenedores de carrusel
 * @param {Object} options - Configuración global opcional
 * @returns {Carousel[]} Array de instancias creadas
 */
export function initCarousels(selector = '.carousel', options = {}) {
    const containers = document.querySelectorAll(selector);
    const instances = [];
    
    containers.forEach(container => {
        instances.push(new Carousel(container, options));
    });
    
    return instances;
}

// Exportación por defecto para compatibilidad
export default Carousel;