/**
 * MÓDULO DE ANIMACIONES Y EFECTOS VISUALES (Práctica 2 U2)
 * IntersectionObserver, parallax, magnético, transiciones suaves
 * 
 * @module Animations
 */

import { CONFIG } from './config.js';
import { throttle } from './api.js';

// ==================== CONFIGURACIÓN INTERNA ====================
const ANIM_CONFIG = {
    scroll: {
        threshold: 0.15,
        rootMargin: '0px 0px -50px 0px',
        className: 'visible',
        unobserveAfter: true
    },
    parallax: {
        defaultSpeed: 0.05,
        throttleMs: 16 // ~60fps
    },
    magnetic: {
        strength: 0.3,
        scale: 1.02,
        transition: 'transform 0.2s cubic-bezier(0.175, 0.885, 0.32, 1.275)'
    },
    fade: {
        duration: 300,
        easing: 'ease-out'
    }
};

// ==================== SCROLL ANIMATIONS ====================

/**
 * Inicializa animaciones de aparición al hacer scroll con IntersectionObserver
 * @param {Object} options - Configuración opcional
 * @param {string} options.selector - Selector CSS de elementos a animar
 * @param {string} options.className - Clase a agregar cuando es visible
 * @param {boolean} options.unobserveAfter - Dejar de observar después de animar
 */
export function initScrollAnimations(options = {}) {
    const {
        selector = '.scroll-reveal',
        className = ANIM_CONFIG.scroll.className,
        unobserveAfter = ANIM_CONFIG.scroll.unobserveAfter
    } = options;

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add(className);
                if (unobserveAfter) {
                    observer.unobserve(entry.target);
                }
            }
        });
    }, {
        threshold: ANIM_CONFIG.scroll.threshold,
        rootMargin: ANIM_CONFIG.scroll.rootMargin
    });

    document.querySelectorAll(selector).forEach(el => {
        // Solo observar si no está ya visible (para SPA navigation)
        if (!el.classList.contains(className)) {
            observer.observe(el);
        }
    });

    // Retornar método para desconectar (cleanup)
    return () => observer.disconnect();
}

/**
 * Versión simplificada como método del objeto Anim
 */
function initScroll() {
    return initScrollAnimations();
}

// ==================== PARALLAX EFFECT ====================

// Store para cleanup
let _parallaxCleanup = null;

/**
 * Inicializa efecto parallax basado en movimiento del mouse
 * @param {Object} options - Configuración opcional
 * @param {string} options.selector - Selector de elementos parallax
 * @param {number} options.speed - Velocidad del efecto (0-1)
 * @param {boolean} options.throttle - Activar throttle para rendimiento
 */
export function initParallax(options = {}) {
    const {
        selector = '.parallax-element',
        speed = ANIM_CONFIG.parallax.defaultSpeed,
        throttle: useThrottle = true
    } = options;

    const elements = document.querySelectorAll(selector);
    if (elements.length === 0) return () => {};

    const handleMouseMove = (e) => {
        elements.forEach(el => {
            const elSpeed = parseFloat(el.dataset.speed) || speed;
            const x = (window.innerWidth - e.pageX * 2) * elSpeed;
            const y = (window.innerHeight - e.pageY * 2) * elSpeed;
            el.style.transform = `translate3d(${x}px, ${y}px, 0)`;
            el.style.willChange = 'transform'; // Optimización de rendimiento
        });
    };

    // Aplicar throttle si se solicita para mejor rendimiento
    const handler = useThrottle ? throttle(handleMouseMove, ANIM_CONFIG.parallax.throttleMs) : handleMouseMove;

    document.addEventListener('mousemove', handler, { passive: true });

    // Cleanup function
    _parallaxCleanup = () => {
        document.removeEventListener('mousemove', handler);
        elements.forEach(el => {
            el.style.transform = '';
            el.style.willChange = '';
        });
    };

    return _parallaxCleanup;
}

/**
 * Versión simplificada para objeto Anim (usa selector .parallax-bg)
 */
function initParallaxSimple() {
    return initParallax({ selector: '.parallax-bg', speed: 0.02 });
}

// ==================== MAGNETIC BUTTONS ====================

// Store para cleanup de magnéticos
const _magneticCleanup = new Map();

/**
 * Inicializa efecto magnético en botones (se mueven hacia el cursor)
 * @param {Object} options - Configuración opcional
 * @param {string} options.selector - Selector de botones magnéticos
 * @param {number} options.strength - Fuerza del efecto (0-1)
 * @param {number} options.scale - Escala al hacer hover
 * @param {Array} options.exclude - Selectores a excluir (ej: ['#theme-toggle'])
 */
export function initMagneticButtons(options = {}) {
    const {
        selector = '.magnetic',
        strength = ANIM_CONFIG.magnetic.strength,
        scale = ANIM_CONFIG.magnetic.scale,
        exclude = []
    } = options;

    const buttons = Array.from(document.querySelectorAll(selector)).filter(btn => {
        return !exclude.some(exc => btn.matches(exc) || btn.closest(exc));
    });

    if (buttons.length === 0) return () => {};

    buttons.forEach(btn => {
        // Aplicar transición suave
        btn.style.transition = ANIM_CONFIG.magnetic.transition;
        btn.style.willChange = 'transform';

        const onMouseMove = (e) => {
            const rect = btn.getBoundingClientRect();
            const x = e.clientX - rect.left - rect.width / 2;
            const y = e.clientY - rect.top - rect.height / 2;
            btn.style.transform = `translate(${x * strength}px, ${y * strength}px) scale(${scale})`;
        };

        const onMouseLeave = () => {
            btn.style.transform = 'translate(0, 0) scale(1)';
        };

        btn.addEventListener('mousemove', onMouseMove, { passive: true });
        btn.addEventListener('mouseleave', onMouseLeave);

        // Guardar cleanup para este botón
        _magneticCleanup.set(btn, () => {
            btn.removeEventListener('mousemove', onMouseMove);
            btn.removeEventListener('mouseleave', onMouseLeave);
            btn.style.transform = '';
            btn.style.transition = '';
            btn.style.willChange = '';
        });
    });

    // Cleanup global
    return () => {
        _magneticCleanup.forEach(cleanup => cleanup());
        _magneticCleanup.clear();
    };
}

/**
 * Versión simplificada para objeto Anim (excluye theme-toggle automáticamente)
 */
function initMagnetic() {
    return initMagneticButtons({ exclude: ['#theme-toggle'] });
}

// ==================== FADE TRANSITIONS ====================

/**
 * Muestra/oculta elemento con transición fade suave (sin display:none brusco)
 * @param {HTMLElement} el - Elemento a animar
 * @param {boolean} show - True para mostrar, false para ocultar
 * @param {Object} options - Configuración opcional
 */
export function fadeElement(el, show, options = {}) {
    if (!el) return;

    const {
        duration = ANIM_CONFIG.fade.duration,
        easing = ANIM_CONFIG.fade.easing,
        onEnd = null
    } = options;

    // Asegurar que el elemento sea visible para animar opacity
    if (show && el.style.display === 'none') {
        el.style.display = '';
        el.style.opacity = '0';
    }

    // Forzar reflow para que el navegador registre el cambio inicial
    void el.offsetHeight;

    // Aplicar transición
    el.style.transition = `opacity ${duration}ms ${easing}`;
    el.style.opacity = show ? '1' : '0';

    // Callback al finalizar
    const onTransitionEnd = (e) => {
        if (e.propertyName === 'opacity') {
            el.removeEventListener('transitionend', onTransitionEnd);
            if (!show) {
                el.style.display = 'none';
            }
            el.style.transition = '';
            if (onEnd) onEnd();
        }
    };

    el.addEventListener('transitionend', onTransitionEnd);
}

/**
 * Fade in escalonado para listas (ej: filas de tabla)
 * @param {NodeList|Array} elements - Elementos a animar
 * @param {number} delay - Delay entre cada elemento (ms)
 */
export function fadeInStaggered(elements, delay = 50) {
    elements.forEach((el, index) => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(10px)';
        el.style.transition = `opacity ${ANIM_CONFIG.fade.duration}ms ${ANIM_CONFIG.fade.easing}, transform ${ANIM_CONFIG.fade.duration}ms ${ANIM_CONFIG.fade.easing}`;
        
        setTimeout(() => {
            el.style.opacity = '1';
            el.style.transform = 'translateY(0)';
        }, index * delay);
    });
}

// ==================== OBJETO UNIFICADO Anim ====================

/**
 * Objeto Anim para compatibilidad con código existente
 * Contiene versiones simplificadas de las funciones principales
 */
export const Anim = {
    /**
     * Inicializa animaciones de scroll (versión simplificada)
     */
    initScroll,
    
    /**
     * Inicializa parallax (versión simplificada con selector .parallax-bg)
     */
    initParallax: initParallaxSimple,
    
    /**
     * Inicializa botones magnéticos (excluye #theme-toggle)
     */
    initMagnetic,
    
    /**
     * Limpia todos los event listeners de animaciones
     */
    cleanup() {
        if (_parallaxCleanup) _parallaxCleanup();
        _magneticCleanup.forEach(cleanup => cleanup());
        _magneticCleanup.clear();
    },
    
    /**
     * Fade element wrapper
     */
    fade: fadeElement,
    
    /**
     * Fade staggered wrapper
     */
    fadeInStaggered
};

// ==================== AUTO-INIT (OPCIONAL) ====================

/**
 * Inicializa todas las animaciones con configuración por defecto
 * Útil para carga inicial de página
 * @returns {Function} Función de cleanup global
 */
export function initAll() {
    const cleanups = [
        initScrollAnimations(),
        initParallax(),
        initMagneticButtons({ exclude: ['#theme-toggle'] })
    ];
    
    // Retornar función para limpiar todo
    return () => cleanups.forEach(cleanup => cleanup?.());
}

// ==================== EVENT LISTENER PARA SPA NAVIGATION ====================

/**
 * Re-inicializa animaciones después de navegación SPA (History API)
 * Útil cuando el contenido cambia sin recargar la página
 */
export function reinitAfterNavigation() {
    // Pequeño delay para asegurar que el nuevo DOM está renderizado
    setTimeout(() => {
        initScrollAnimations();
        // Parallax y magnetic ya tienen listeners globales, no necesitan re-init
    }, 100);
}

// ==================== CLEANUP GLOBAL AL UNLOAD ====================

if (typeof window !== 'undefined') {
    window.addEventListener('beforeunload', () => {
        // Limpiar listeners para evitar memory leaks
        if (_parallaxCleanup) _parallaxCleanup();
        _magneticCleanup.forEach(cleanup => cleanup());
        _magneticCleanup.clear();
    });
}

// Exportación por defecto para compatibilidad
export default Anim;