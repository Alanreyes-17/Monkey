/**
 * MÓDULO DE INTERFAZ DE USUARIO (UI)
 * Maneja renderizado DOM, mensajes, validaciones, breadcrumbs y RBAC visual
 * Prácticas: U1 P2, U2 P1, U3 P1
 */

import { Data } from './data.js';
import { Auth } from './auth.js';
import { CONFIG } from './config.js';

export const UI = {

    // ==================== MENSAJES TOAST ====================
    /**
     * Muestra mensaje flotante tipo toast
     * @param {string} msg - Texto del mensaje
     * @param {string} type - 'success' | 'error' | 'warning'
     */
    toast(msg, type = 'success') {
        // Eliminar toast anterior si existe
        const existing = document.querySelector('.toast');
        if (existing) existing.remove();

        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.textContent = msg;
        toast.style.cssText = `
            position: fixed; top: 20px; right: 20px; 
            padding: 1rem 1.5rem; border-radius: 8px; 
            background: ${type === 'error' ? '#e57373' : type === 'warning' ? '#ff9800' : '#81c784'}; 
            color: #000; font-weight: 500; z-index: 10000;
            animation: slideInRight 0.3s ease-out;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        `;
        document.body.appendChild(toast);
        setTimeout(() => toast.remove(), 3000);
    },

    // ==================== RENDERIZADO DE TABLAS ====================
    /**
     * Renderiza tabla de citas con animación escalonada
     * @param {HTMLElement} el - Elemento tbody donde se renderizará
     * @param {Array} data - Array de objetos cita
     */
    renderCitasTable(el, data) {
        if (!el) return;
        el.innerHTML = '';

        if (!data || data.length === 0) {
            el.innerHTML = '<tr><td colspan="6" class="text-center p-3">No hay registros</td></tr>';
            return;
        }

        data.forEach((cita, index) => {
            const tr = document.createElement('tr');
            tr.className = 'fade-row';
            tr.style.animationDelay = `${index * 0.05}s`;
            tr.innerHTML = `
                <td>${this.escape(cita.nombre)}</td>
                <td>${this.escape(cita.servicio)}</td>
                <td>${this.escape(cita.barbero || '-')}</td>
                <td><span class="badge status-${cita.estado}">${cita.estado}</span></td>
                <td class="actions">
                    <button data-act="edit" data-id="${cita.id}" class="btn-sm" title="Editar">✏️</button>
                    <button data-act="del" data-id="${cita.id}" class="btn-sm danger" title="Eliminar">🗑️</button>
                </td>
            `;
            el.appendChild(tr);
        });
    },

    // ==================== RENDERIZADO DE BARBEROS ====================
    /**
     * Renderiza cards de barberos con filtro por experiencia
     * @param {HTMLElement} container - Contenedor donde se renderizarán las cards
     * @param {Array} barberos - Array de objetos barbero
     * @param {string} filtro - Filtro por experiencia ('all', 'Más de 5 años', etc.)
     */
    renderBarberos(container, barberos, filtro = 'all') {
        if (!container) return;
        container.innerHTML = '';

        const filtered = filtro === 'all' 
            ? barberos 
            : barberos.filter(b => b.experiencia?.includes(filtro));

        filtered.forEach(barbero => {
            const card = document.createElement('div');
            card.className = 'card hover-lift scroll-reveal';
            card.innerHTML = `
                <img src="${barbero.imagen}" alt="${barbero.nombre}" loading="lazy">
                <div class="card-body">
                    <h3>${this.escape(barbero.nombre)}</h3>
                    <p>${this.escape(barbero.especialidad)}</p>
                    <p style="color:var(--primary);font-weight:bold;margin-top:0.5rem;">
                        ${this.escape(barbero.experiencia)}
                    </p>
                    <button class="btn magnetic" style="width:100%;margin-top:1rem;" 
                        onclick="window.location.href='reservas.php?barbero=${encodeURIComponent(barbero.nombre)}'">
                        Seleccionar
                    </button>
                </div>
            `;
            container.appendChild(card);
        });
    },

    // ==================== RENDERIZADO DE SERVICIOS ====================
    /**
     * Renderiza cards de servicios con búsqueda en tiempo real
     * @param {HTMLElement} container - Contenedor donde se renderizarán las cards
     * @param {Array} servicios - Array de objetos servicio
     * @param {string} query - Texto de búsqueda para filtrar
     */
    renderServicios(container, servicios, query = '') {
        if (!container) return;
        container.innerHTML = '';

        const filtered = query 
            ? servicios.filter(s => 
                s.nombre?.toLowerCase().includes(query.toLowerCase()) || 
                s.descripcion?.toLowerCase().includes(query.toLowerCase())
            )
            : servicios;

        filtered.forEach(servicio => {
            const card = document.createElement('div');
            card.className = 'card hover-lift scroll-reveal';
            card.innerHTML = `
                <div style="background:var(--primary);height:10px;"></div>
                <div class="card-body">
                    <h3 style="font-size:1.5rem;">${servicio.icono || ''} ${this.escape(servicio.nombre)}</h3>
                    <p style="margin:1rem 0;">${this.escape(servicio.descripcion)}</p>
                    <a href="reservas.php?servicio=${encodeURIComponent(servicio.nombre)}" 
                       class="btn magnetic" style="width:100%;display:block;text-align:center;">
                        Seleccionar Servicio
                    </a>
                </div>
            `;
            container.appendChild(card);
        });
    },

    // ==================== BREADCRUMBS ====================
    /**
     * Actualiza dinámicamente las migas de pan según la URL
     */
    updateBreadcrumbs() {
        const bc = document.getElementById('breadcrumbs');
        if (!bc) return;

        const path = window.location.pathname.split('/').pop().replace('.php', '') || 'inicio';
        const map = { 
            index: 'Inicio', 
            servicios: 'Servicios', 
            barberos: 'Equipo', 
            reservas: 'Agendar', 
            admin: 'Panel', 
            login: 'Acceso',
            settings: 'Configuración'
        };

        bc.innerHTML = `
            <a href="index.php">Inicio</a> 
            <span>/</span> 
            <span>${map[path] || path}</span>
        `;
    },

    // ==================== RBAC VISUAL ====================
    /**
     * Aplica control de acceso visual según el rol del usuario
     * Oculta/muestra elementos con atributo data-role
     */
    applyRBAC() {
        const role = Auth.getRole();
        if (!role) return;

        document.querySelectorAll('[data-role]').forEach(el => {
            const allowed = el.dataset.role.split(',');
            el.style.display = allowed.includes(role) ? '' : 'none';
        });

        // Actualizar texto de enlace admin según rol
        const adminLink = document.querySelector('a[href="admin.php"]');
        if (adminLink) {
            adminLink.textContent = role === CONFIG.ROLES.ADMIN ? '👑 Admin' : '🔐 Panel';
        }
    },

    // ==================== VALIDACIÓN DE FORMULARIOS ====================
    /**
     * Valida formulario con reglas HTML5 + expresiones regulares
     * @param {string} formId - ID del formulario a validar
     * @returns {Object} { ok: boolean, data: Object }
     */
    validateForm(formId) {
        const form = document.getElementById(formId);
        if (!form) return { ok: false, data: null };

        const errors = {};
        const data = {};
        let ok = true;

        form.querySelectorAll('input, select, textarea').forEach(inp => {
            const v = inp.value.trim();
            data[inp.id] = v;

            // Campo requerido
            if (inp.hasAttribute('required') && !v) {
                errors[inp.id] = 'Este campo es obligatorio';
                ok = false;
            }

            // Email válido
            if (inp.type === 'email' && v && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) {
                errors[inp.id] = 'Correo electrónico inválido';
                ok = false;
            }

            // Teléfono 10 dígitos
            if (inp.id === 'telefono' && v && !/^[0-9]{10}$/.test(v)) {
                errors[inp.id] = 'Teléfono debe tener 10 dígitos';
                ok = false;
            }

            // Contraseña segura
            if (inp.id === 'password' && v && !/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{6,}$/.test(v)) {
                errors[inp.id] = 'Mínimo 6 caracteres, 1 letra y 1 número';
                ok = false;
            }

            // Confirmación de contraseña
            if (inp.id === 'confirmPassword' && v && v !== data.password) {
                errors[inp.id] = 'Las contraseñas no coinciden';
                ok = false;
            }

            // Mostrar error en elemento asociado
            const errEl = document.getElementById(`${inp.id}-err`);
            if (errEl) errEl.textContent = errors[inp.id] || '';
        });

        return { ok, data };
    },

    // ==================== UTILIDADES ====================
    /**
     * Limpia formulario y mensajes de error
     * @param {string} formId - ID del formulario
     */
    clearForm(formId) {
        const form = document.getElementById(formId);
        if (form) form.reset();
        document.querySelectorAll('.error-msg').forEach(e => e.textContent = '');
    },

    /**
     * Escapa HTML para prevenir XSS
     * @param {string} str - Texto a escapar
     * @returns {string} Texto seguro
     */
    escape(str) {
        if (!str) return '';
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    },

    /**
     * Muestra/oculta elemento con transición suave
     * @param {HTMLElement} el - Elemento a animar
     * @param {boolean} show - true para mostrar, false para ocultar
     */
    toggleVisibility(el, show) {
        if (!el) return;
        if (show) {
            el.style.opacity = '0';
            el.style.display = '';
            requestAnimationFrame(() => {
                el.style.transition = 'opacity 0.3s ease';
                el.style.opacity = '1';
            });
        } else {
            el.style.transition = 'opacity 0.3s ease';
            el.style.opacity = '0';
            setTimeout(() => el.style.display = 'none', 300);
        }
    }
};