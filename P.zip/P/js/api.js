<?php
/**
 * API PRINCIPAL - BarberMonkey (Práctica 1 U3 + Práctica 2 U2)
 * Punto de entrada único para todas las peticiones AJAX
 */

// === CONFIGURACIÓN INICIAL ===
@ini_set('display_errors', 0); // Ocultar warnings que rompen JSON
@ini_set('log_errors', 1);
error_reporting(E_ALL);

// Headers CORS y JSON
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-CSRF-Token');
header('Content-Type: application/json; charset=utf-8');

// Manejar preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Buffer para capturar output accidental (espacios en blanco, warnings filtrados)
ob_start();

// === CARGAR DEPENDENCIAS ===
try {
    require_once __DIR__ . '/config.php';
    require_once __DIR__ . '/db.php';
    require_once __DIR__ . '/security.php';
    require_once __DIR__ . '/middleware.php';
    require_once __DIR__ . '/services/JWTService.php';
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error de configuración: ' . $e->getMessage()
    ]);
    ob_end_flush(); // Asegurar que el buffer se vacíe y se envíe
    exit;
}

// === OBTENER RUTA Y MÉTODO ===
$route = $_GET['route'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];

// === ENRUTADOR PRINCIPAL ===
try {
    // Rutas de autenticación
    if (str_starts_with($route, 'auth/')) {

        switch ($route) {

            // ========================================
            // REGISTRO DE USUARIO
            // ========================================
            case 'auth/register':
                // Rate limiting (primero que todo)
                if (defined('IS_DEV') && IS_DEV) {
                    if (!rateLimitHandler('register', 50, 60)) { exit; }
                } else {
                    if (!rateLimitHandler('register', 5, 900)) { exit; }
                }

                if ($method !== 'POST') {
                    throw new Exception('Método no permitido');
                }

                // Leer JSON
                $input = json_decode(file_get_contents('php://input'), true);
                if (!$input) {
                    throw new Exception('Datos JSON inválidos');
                }

                // Validar campos requeridos (camelCase para coincidir con frontend)
                $required = ['username', 'fullname', 'email', 'phone', 'password', 'confirmPassword', 'terms'];
                foreach($required as $field) {
                    if (empty($input[$field])) {
                        throw new Exception("El campo '{$field}' es requerido");
                    }
                }

                // Validar email
                if (!filter_var($input['email'], FILTER_VALIDATE_EMAIL)) {
                    throw new Exception('Formato de correo inválido');
                }

                // Validar contraseñas
                if ($input['password'] !== $input['confirmPassword']) {
                    throw new Exception('Las contraseñas no coinciden');
                }

                // Validar política de contraseña
                if (strlen($input['password']) < 8 ||
                    !preg_match('/[A-Za-z]/', $input['password']) ||
                    !preg_match('/\d/', $input['password'])) {
                    throw new Exception('La contraseña debe tener 8+ caracteres, 1 letra y 1 número');
                }

                // Verificar términos
                if (empty($input['terms'])) {
                    throw new Exception('Debes aceptar los términos y condiciones');
                }

                // Verificar email/username único
                $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? OR username = ?");
                $stmt->execute([$input['email'], $input['username']]);
                if ($stmt->fetch()) {
                    throw new Exception('El correo o nombre de usuario ya está registrado');
                }

                // Hashear contraseña e insertar
                $passwordHash = password_hash($input['password'], PASSWORD_BCRYPT, ['cost' => 12]);

                $stmt = $pdo->prepare("
                    INSERT INTO users (username, email, password_hash, full_name, phone, role_id, is_active, created_at) 
                    VALUES (?, ?, ?, ?, ?, 3, 1, NOW())
                ");
                
                $stmt->execute([
                    trim($input['username']),
                    trim($input['email']),
                    $passwordHash,
                    trim($input['fullname']),
                    trim($input['phone'])
                ]);

                $userId = $pdo->lastInsertId();

                // Auditoría
                auditLog('user_registered', ['user_id' => $userId, 'email' => $input['email']], $pdo);

                // ✅ Éxito
                echo json_encode([
                    'success' => true,
                    'message' => 'Registro exitoso. Inicia sesión.',
                    'user_id' => $userId,
                    'redirect' => '/P/login.php'
                ]);
                break;

            // ========================================
            // LOGIN DE USUARIO
            // ========================================
            case 'auth/login':
                if ($method !== 'POST') {
                    throw new Exception('Método no permitido');
                }

                if (!rateLimitHandler('login', 5, 900)) { exit; }

                $input = json_decode(file_get_contents('php://input'), true);
                if (!$input || empty($input['email']) || empty($input['password'])) {
                    throw new Exception('Email y contraseña son requeridos');
                }

                // Buscar usuario
                $stmt = $pdo->prepare("
                    SELECT u.id, u.username, u.email, u.password_hash, u.is_active, u.is_verified, r.name as role 
                    FROM users u 
                    LEFT JOIN roles r ON u.role_id = r.id 
                    WHERE u.email = ?
                ");
                $stmt->execute([$input['email']]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$user || !password_verify($input['password'], $user['password_hash'])) {
                    recordFailedAttempt($input['email']);
                    throw new Exception('Credenciales incorrectas');
                }

                if (!$user['is_active']) {
                    throw new Exception('Cuenta inactiva. Verifica tu email.');
                }

                // Resetear intentos fallidos
                resetFailedAttempts($input['email']);

                // Generar tokens
                $accessToken = JWTService::encode([
                    'id' => $user['id'],
                    'email' => $user['email'],
                    'role' => $user['role'] ?? 'user',
                    'sub' => $user['id']
                ]);

                $refreshToken = JWTService::generateRefreshToken($user['id'], $pdo);

                // Crear sesión en BD
                $sessionId = bin2hex(random_bytes(32));
                $stmt = $pdo->prepare("
                    INSERT INTO sessions (id, user_id, ip_address, user_agent, expires_at) 
                    VALUES (?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL 7 DAY))
                ");
                $stmt->execute([
                    $sessionId,
                    $user['id'],
                    $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0',
                    $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
                ]);

                // Auditoría
                auditLog('login_success', ['user_id' => $user['id']], $pdo);

                // Configurar cookies
                if (!headers_sent()) {
                    $params = session_get_cookie_params();
                    setcookie('access_token', $accessToken, [
                        'expires' => time() + (defined('JWT_EXPIRE') ? JWT_EXPIRE : 900),
                        'path' => $params['path'] ?? '/',
                        'secure' => !isDev(),
                        'httponly' => true,
                        'samesite' => 'Strict'
                    ]);
                    setcookie('session_id', $sessionId, [
                        'expires' => time() + 604800,
                        'path' => $params['path'] ?? '/',
                        'secure' => !isDev(),
                        'httponly' => true,
                        'samesite' => 'Strict'
                    ]);
                }
                
                echo json_encode([
                    'success' => true,
                    'message' => 'Login exitoso',
                    'user' => [
                        'id' => $user['id'],
                        'email' => $user['email'],
                        'username' => $user['username'],
                        'role' => $user['role']
                    ],
                    'redirect' => '/P/index.php'
                ]);
                break;

            // ========================================
            // LOGOUT
            // ========================================
            case 'auth/logout':
                $sessionId = $_COOKIE['session_id'] ?? null;
                $token = $_COOKIE['access_token'] ?? null;

                if ($sessionId) {
                    $stmt = $pdo->prepare("UPDATE sessions SET is_active = 0 WHERE id = ?");
                    $stmt->execute([$sessionId]);
                }

                if ($token) {
                    $payload = JWTService::decode($token);
                    if ($payload && isset($payload['jti'])) {
                        JWTService::blacklistToken($payload['jti'], $payload['exp'] ?? time(), $pdo);
                    }
                }

                // Limpiar cookies
                if (!headers_sent()) {
                    $cookies = ['access_token', 'refresh_token', 'session_id'];
                    foreach($cookies as $name) {
                        setcookie($name, '', ['expires' => time() - 3600, 'path' => '/']);
                    }
                }

                auditLog('logout', ['session_id' => $sessionId], $pdo);
                
                echo json_encode(['success' => true, 'message' => 'Sesión cerrada']);
                break;

            // ========================================
            // REFRESH TOKEN
            // ========================================
            case 'auth/refresh':
                // Decodificar JSON en caso de que se envíe por body
                $input = json_decode(file_get_contents('php://input'), true) ?? [];
                
                $refreshToken = $_COOKIE['refresh_token'] ?? $input['refresh_token'] ?? null;
                if (!$refreshToken) {
                    throw new Exception('Refresh token requerido');
                }

                $result = JWTService::refreshAccessToken($refreshToken, $pdo);
                if (!$result) {
                    throw new Exception('Refresh token inválido o expirado');
                }
                
                echo json_encode($result);
                break;

            // ========================================
            // VERIFICAR EMAIL
            // ========================================
            case 'auth/verify-email':
                $token = $_GET['token'] ?? '';
                if (!$token) {
                    throw new Exception('Token de verificación requerido');
                }

                $stmt = $pdo->prepare("
                    SELECT ev.user_id FROM email_verifications ev
                    WHERE ev.token = ? AND ev.used = FALSE AND ev.expires_at > NOW()
                ");
                $stmt->execute([hash('sha256', $token)]);
                $verification = $stmt->fetch();

                if (!$verification) {
                    throw new Exception('Token inválido o expirado');
                }

                // Activar usuario
                $stmt = $pdo->prepare("UPDATE users SET is_verified = TRUE, is_active = TRUE WHERE id = ?");
                $stmt->execute([$verification['user_id']]);

                // Marcar token como usado
                $stmt = $pdo->prepare("UPDATE email_verifications SET used = TRUE, used_at = NOW() WHERE user_id = ?");
                $stmt->execute([$verification['user_id']]);

                auditLog('email_verified', ['user_id' => $verification['user_id']], $pdo);
                
                echo json_encode(['success' => true, 'message' => 'Email verificado. Ahora puedes iniciar sesión.']);
                break;

            // ========================================
            // RECUPERAR CONTRASEÑA - SOLICITAR
            // ========================================
            case 'auth/recover-request':
                if ($method !== 'POST') {
                    throw new Exception('Método no permitido');
                }

                $input = json_decode(file_get_contents('php://input'), true);
                if (empty($input['email'])) {
                    throw new Exception('Email requerido');
                }

                // Buscar usuario (sin revelar si existe o no)
                $stmt = $pdo->prepare("SELECT id, email FROM users WHERE email = ? AND is_active = 1");
                $stmt->execute([$input['email']]);
                $user = $stmt->fetch();

                if ($user) {
                    $token = bin2hex(random_bytes(32));
                    $tokenHash = hash('sha256', $token);

                    $stmt = $pdo->prepare("
                        INSERT INTO password_resets (user_id, token, expires_at, requested_ip, requested_user_agent) 
                        VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 1 HOUR), ?, ?)
                    ");
                    $stmt->execute([
                        $user['id'],
                        $tokenHash,
                        $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0',
                        $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
                    ]);

                    if (defined('IS_DEV') && IS_DEV) {
                        auditLog('recover_token_generated', ['user_id' => $user['id'], 'token' => $token], $pdo);
                        echo json_encode([
                            'success' => true,
                            'message' => 'Código de recuperación generado (solo desarrollo)',
                            'debug_code' => '123456'
                        ]);
                    } else {
                        auditLog('recover_email_sent', ['user_id' => $user['id']], $pdo);
                        echo json_encode([
                            'success' => true,
                            'message' => 'Si el email existe, recibirás instrucciones de recuperación.'
                        ]);
                    }
                } else {
                    echo json_encode([
                        'success' => true,
                        'message' => 'Si el email existe, recibirás instrucciones de recuperación.'
                    ]);
                }
                break;

            // ========================================
            // RECUPERAR CONTRASEÑA - VERIFICAR CÓDIGO
            // ========================================
            case 'auth/recover-verify':
                if ($method !== 'POST') {
                    throw new Exception('Método no permitido');
                }

                $input = json_decode(file_get_contents('php://input'), true);
                if (empty($input['email']) || empty($input['code'])) {
                    throw new Exception('Email y código requeridos');
                }

                if (defined('IS_DEV') && IS_DEV && $input['code'] === '123456') {
                    echo json_encode([
                        'success' => true,
                        'message' => 'Código verificado (modo desarrollo)',
                        'temp_token' => bin2hex(random_bytes(16))
                    ]);
                    break;
                }

                $stmt = $pdo->prepare("
                    SELECT pr.user_id FROM password_resets pr
                    JOIN users u ON pr.user_id = u.id
                    WHERE u.email = ? AND pr.token = ? AND pr.used = FALSE AND pr.expires_at > NOW()
                ");
                $stmt->execute([$input['email'], hash('sha256', $input['code'])]);

                if (!$stmt->fetch()) {
                    throw new Exception('Código inválido o expirado');
                }
                
                echo json_encode([
                    'success' => true,
                    'message' => 'Código verificado',
                    'temp_token' => bin2hex(random_bytes(16))
                ]);
                break;

            // ========================================
            // RECUPERAR CONTRASEÑA - CAMBIAR
            // ========================================
            case 'auth/recover-change':
                if ($method !== 'POST') {
                    throw new Exception('Método no permitido');
                }

                $input = json_decode(file_get_contents('php://input'), true);
                if (empty($input['temp_token']) || empty($input['new_password']) || empty($input['confirm_password'])) {
                    throw new Exception('Todos los campos son requeridos');
                }

                if ($input['new_password'] !== $input['confirm_password']) {
                    throw new Exception('Las contraseñas no coinciden');
                }

                if (strlen($input['new_password']) < 8 ||
                    !preg_match('/[A-Za-z]/', $input['new_password']) ||
                    !preg_match('/\d/', $input['new_password'])) {
                    throw new Exception('La contraseña debe tener 8+ caracteres, 1 letra y 1 número');
                }

                if (defined('IS_DEV') && IS_DEV) {
                    echo json_encode([
                        'success' => true,
                        'message' => 'Contraseña actualizada. Inicia sesión con tu nueva contraseña.',
                        'redirect' => '/P/login.php'
                    ]);
                } else {
                    throw new Exception('Funcionalidad no implementada en producción');
                }
                break;

            // ========================================
            // OBTENER DATOS DEL USUARIO ACTUAL
            // ========================================
            case 'auth/me':
                $payload = requireAuthApi();
                if (!$payload) {
                    exit;
                }
                
                echo json_encode([
                    'success' => true,
                    'user' => $payload
                ]);
                break;

            // ========================================
            // RUTA NO ENCONTRADA
            // ========================================
            default:
                throw new Exception('Endpoint de autenticación no encontrado: ' . $route);
        }

    }
    // ========================================
    // OTRAS RUTAS
    // ========================================
    elseif(str_starts_with($route, 'citas/')) {
        switch ($route) {
            case 'citas/list':
                echo json_encode(['success' => true, 'data' => []]);
                break;
            case 'citas/create':
                echo json_encode(['success' => true, 'message' => 'Cita creada']);
                break;
            default:
                throw new Exception('Endpoint de citas no encontrado: ' . $route);
        }
    }
    else {
        throw new Exception('Ruta no encontrada: ' . $route);
    }

} catch (Exception $e) {
    error_log("API Error [{$route}]: " . $e->getMessage() . " | Trace: " . $e->getTraceAsString());

    http_response_code($e->getCode() ?: 400);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}

// === MANEJO FINAL DEL BUFFER ===
// Recuperamos todo lo impreso durante el script
$output = ob_get_clean();

// Revisamos si hay advertencias u HTML que ensucie la respuesta JSON
if ($output && strpos(trim($output), '{"') !== 0) {
    error_log("API Output contaminado: " . substr($output, 0, 500));
    // En producción podrías limpiar $output dejando solo el JSON válido usando expresiones regulares, 
    // pero idealmente deberías resolver qué es lo que está generando ese output accidental.
}

// IMPRIMIMOS EL RESULTADO FINAL PARA EL CLIENTE
echo $output;