/**
 * MÓDULO DE AUTENTICACIÓN Y SEGURIDAD (Práctica 1 U3)
 * Gestiona login, MFA, JWT, refresh tokens, roles y recuperación de contraseña
 * 
 * @module Auth
 */

import { CONFIG } from './config.js';

// ==================== UTILIDADES INTERNAS ====================

/**
 * Decodifica payload de JWT de forma segura
 * @param {string} token - Token JWT
 * @returns {Object|null} Payload decodificado o null si es inválido
 */
function decodeJWT(token) {
    if (!token) return null;
    try {
        const parts = token.split('.');
        if (parts.length !== 3) return null;
        // Decodificar Base64URL
        const payload = atob(parts[1].replace(/-/g, '+').replace(/_/g, '/'));
        return JSON.parse(payload);
    } catch {
        return null;
    }
}

/**
 * Verifica si un token JWT está expirado
 * @param {string} token - Token JWT
 * @returns {boolean} True si está expirado o inválido
 */
function isTokenExpired(token) {
    const payload = decodeJWT(token);
    if (!payload || !payload.exp) return true;
    // exp está en segundos, Date.now() en milisegundos
    return payload.exp * 1000 < Date.now();
}

// ==================== MÓDULO AUTH PÚBLICO ====================

export const Auth = {

    // ==================== GESTIÓN DE TOKENS ====================

    /**
     * Obtiene el access token desde localStorage
     * @returns {string|null} Token o null si no existe
     */
    getToken() {
        return localStorage.getItem(CONFIG.STORAGE.TOKEN) || null;
    },

    /**
     * Obtiene el refresh token desde localStorage
     * @returns {string|null} Token o null si no existe
     */
    getRefreshToken() {
        return localStorage.getItem(CONFIG.STORAGE.REFRESH) || null;
    },

    /**
     * Decodifica y retorna el payload del token actual
     * @returns {Object|null} Datos del usuario o null
     */
    getPayload() {
        const token = this.getToken();
        return decodeJWT(token);
    },

    /**
     * Verifica si el usuario está autenticado con token válido
     * @returns {boolean} True si tiene sesión activa
     */
    isAuthenticated() {
        const token = this.getToken();
        if (!token) return false;
        return !isTokenExpired(token);
    },

    /**
     * Obtiene datos del usuario almacenados
     * @returns {Object|null} Información del usuario o null
     */
    getUser() {
        const data = localStorage.getItem(CONFIG.STORAGE.USER);
        return data ? JSON.parse(data) : null;
    },

    /**
     * Obtiene el rol del usuario actual
     * @returns {string|null} Nombre del rol o null
     */
    getRole() {
        const user = this.getUser();
        return user?.role || null;
    },

    /**
     * Verifica si el usuario tiene uno de los roles permitidos
     * @param {string|string[]} roles - Rol o array de roles permitidos
     * @returns {boolean} True si tiene acceso
     */
    checkRole(roles) {
        const userRole = this.getRole();
        if (!userRole) return false;
        const allowed = Array.isArray(roles) ? roles : [roles];
        return allowed.includes(userRole);
    },

    /**
     * Verifica si el usuario tiene un permiso específico
     * @param {string} permission - Permiso a verificar
     * @returns {boolean} True si tiene el permiso
     */
    hasPermission(permission) {
        const role = this.getRole();
        if (!role) return false;
        // Usar CONFIG si está disponible, sino fallback manual
        const rolePerms = {
            admin: ['read', 'write', 'delete', 'manage_users', 'manage_sessions'],
            editor: ['read', 'write', 'delete'],
            user: ['read']
        };
        return rolePerms[role]?.includes(permission) || false;
    },

    // ==================== LOGIN Y REGISTRO ====================

    /**
     * Simula proceso de login (en producción: llamar a backend)
     * @param {string} email - Correo del usuario
     * @param {string} password - Contraseña
     * @returns {Promise<Object>} Resultado del login
     */
    async login(email, password) {
        // Validación básica frontend
        if (!email || !password) {
            return { error: 'Correo y contraseña son requeridos' };
        }

        // Simular delay de red
        await new Promise(res => setTimeout(res, 500));

        // Credenciales de prueba para demostración
        if (email === 'admin@barbermonkey.com' && password === 'Admin1234') {
            return { 
                success: true, 
                requiresMFA: true, 
                message: 'MFA requerido para administrador' 
            };
        }
        
        if (email.includes('@') && password.length >= 6) {
            return { 
                success: true, 
                requiresMFA: false, 
                message: 'Login exitoso' 
            };
        }

        return { error: 'Credenciales incorrectas' };
    },

    /**
     * Verifica código MFA y establece sesión completa
     * @param {string} code - Código de 6 dígitos
     * @returns {Promise<Object>} Resultado de la verificación
     */
    async verifyMFA(code) {
        if (!code || code.length !== 6) {
            return { error: 'Código MFA debe tener 6 dígitos' };
        }

        await new Promise(res => setTimeout(res, 400));

        // Simular verificación exitosa
        if (code === '123456' || /^\d{6}$/.test(code)) {
            // Crear payload del usuario
            const payload = {
                id: 1,
                email: 'admin@barbermonkey.com',
                role: CONFIG.ROLES.ADMIN.name,
                exp: Math.floor(Date.now() / 1000) + (CONFIG.EXPIRY.ACCESS / 1000)
            };

            // Generar JWT simulado (en producción: backend lo firma)
            const fakeJWT = `${btoa(JSON.stringify(payload))}.${btoa(JSON.stringify(payload))}.signature`;

            // Almacenar tokens y datos de usuario
            localStorage.setItem(CONFIG.STORAGE.TOKEN, fakeJWT);
            localStorage.setItem(CONFIG.STORAGE.REFRESH, 'refresh_' + Math.random().toString(36).substr(2, 16));
            localStorage.setItem(CONFIG.STORAGE.USER, JSON.stringify(payload));

            return { success: true, message: 'Autenticación completada' };
        }

        return { error: 'Código MFA inválido o expirado' };
    },

    /**
     * Registra un nuevo usuario (simulado)
     * @param {Object} userData - Datos del nuevo usuario
     * @returns {Promise<Object>} Resultado del registro
     */
    async register(userData) {
        if (!userData?.email || !userData?.password) {
            return { error: 'Email y contraseña son requeridos' };
        }

        await new Promise(res => setTimeout(res, 600));

        // Simular éxito
        return { 
            success: true, 
            message: 'Registro exitoso. Por favor inicia sesión.',
            redirect: 'login.php'
        };
    },

    // ==================== REFRESH TOKEN ====================

    /**
     * Intenta refrescar el access token usando refresh token
     * @returns {Promise<boolean>} True si se renovó exitosamente
     */
    async refreshToken() {
        const refresh = this.getRefreshToken();
        if (!refresh) return false;

        try {
            // Simular llamada a endpoint /auth/refresh
            await new Promise(res => setTimeout(res, 300));

            // Crear nuevo payload con expiración extendida
            const payload = {
                id: 1,
                email: 'admin@barbermonkey.com',
                role: CONFIG.ROLES.ADMIN.name,
                exp: Math.floor(Date.now() / 1000) + (CONFIG.EXPIRY.ACCESS / 1000)
            };

            const newToken = `${btoa(JSON.stringify(payload))}.${btoa(JSON.stringify(payload))}.sig`;
            
            localStorage.setItem(CONFIG.STORAGE.TOKEN, newToken);
            return true;
        } catch {
            return false;
        }
    },

    /**
     * Renueva token automáticamente si está por expirar
     * @param {number} threshold - Milisegundos antes de expirar para renovar
     * @returns {Promise<boolean>} True si se renovó o no era necesario
     */
    async autoRefresh(threshold = 60000) {
        const payload = this.getPayload();
        if (!payload?.exp) return false;

        const expiryTime = payload.exp * 1000;
        const timeUntilExpiry = expiryTime - Date.now();

        if (timeUntilExpiry < threshold) {
            return await this.refreshToken();
        }
        return true; // No necesitaba refresh aún
    },

    // ==================== RECUPERACIÓN DE CONTRASEÑA ====================

    /**
     * Solicita enlace de recuperación por email
     * @param {string} email - Correo del usuario
     * @returns {Promise<Object>} Resultado de la solicitud
     */
    async requestPasswordReset(email) {
        if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            return { error: 'Correo electrónico inválido' };
        }

        await new Promise(res => setTimeout(res, 500));

        // En producción: backend genera token y envía email
        // Aquí simulamos éxito para no revelar si el email existe
        return { 
            success: true, 
            message: 'Si el correo está registrado, recibirás instrucciones.' 
        };
    },

    /**
     * Restablece contraseña con token válido
     * @param {string} token - Token de recuperación
     * @param {string} newPassword - Nueva contraseña
     * @param {string} confirm - Confirmación de contraseña
     * @returns {Promise<Object>} Resultado del cambio
     */
    async resetPassword(token, newPassword, confirm) {
        if (!token || !newPassword || newPassword !== confirm) {
            return { error: 'Datos inválidos o contraseñas no coinciden' };
        }

        if (newPassword.length < 6) {
            return { error: 'La contraseña debe tener al menos 6 caracteres' };
        }

        await new Promise(res => setTimeout(res, 400));

        // Simular éxito
        return { 
            success: true, 
            message: 'Contraseña actualizada. Inicia sesión con tus nuevas credenciales.',
            redirect: 'login.php'
        };
    },

    /**
     * Verifica respuesta de pregunta secreta (mecanismo alternativo)
     * @param {string} answer - Respuesta del usuario
     * @param {string} hashedAnswer - Hash de la respuesta correcta
     * @returns {boolean} True si coincide
     */
    verifySecretAnswer(answer, hashedAnswer) {
        // En producción: comparar hash con bcrypt/argon2
        // Aquí simulamos comparación simple
        return btoa(answer.toLowerCase().trim()) === hashedAnswer;
    },

    // ==================== SESIÓN Y LOGOUT ====================

    /**
     * Cierra sesión y limpia todos los datos de autenticación
     * @param {string} redirectUrl - URL a la que redirigir después
     */
    logout(redirectUrl = 'index.php') {
        // Eliminar tokens y datos de usuario
        Object.values(CONFIG.STORAGE).forEach(key => {
            localStorage.removeItem(key);
        });

        // Limpiar cookies si se usaron
        document.cookie.split(';').forEach(cookie => {
            const name = cookie.split('=')[0].trim();
            if (['access_token', 'refresh_token', 'session_id'].includes(name)) {
                document.cookie = `${name}=; Max-Age=0; path=/; domain=${window.location.hostname}`;
            }
        });

        // Redirigir
        window.location.href = redirectUrl;
    },

    /**
     * Invalida todas las sesiones activas (logout global)
     * @returns {Promise<Object>} Resultado de la operación
     */
    async logoutEverywhere() {
        // En producción: llamar a backend para revocar refresh tokens
        await new Promise(res => setTimeout(res, 300));
        
        this.logout();
        return { success: true, message: 'Todas las sesiones cerradas' };
    },

    // ==================== UTILIDADES DE SEGURIDAD ====================

    /**
     * Genera hash simulado para preguntas secretas (NO USAR EN PRODUCCIÓN)
     * @param {string} answer - Respuesta en texto plano
     * @returns {string} Hash Base64 (simulado)
     * @warning En producción usar bcrypt/argon2 en backend
     */
    hashSecretAnswer(answer) {
        return btoa(answer.toLowerCase().trim());
    },

    /**
     * Valida fortaleza de contraseña
     * @param {string} password - Contraseña a validar
     * @returns {Object} { valid: boolean, errors: string[] }
     */
    validatePassword(password) {
        const errors = [];
        
        if (password.length < 8) errors.push('Mínimo 8 caracteres');
        if (!/[A-Z]/.test(password)) errors.push('Al menos una mayúscula');
        if (!/[a-z]/.test(password)) errors.push('Al menos una minúscula');
        if (!/[0-9]/.test(password)) errors.push('Al menos un número');
        
        return {
            valid: errors.length === 0,
            errors,
            strength: errors.length === 0 ? 'strong' : errors.length <= 2 ? 'medium' : 'weak'
        };
    },

    /**
     * Obtiene información de depuración del estado de auth (solo desarrollo)
     * @returns {Object} Estado actual para debugging
     */
    debugInfo() {
        if (!CONFIG.isDevelopment?.()) return {};
        
        const payload = this.getPayload();
        return {
            authenticated: this.isAuthenticated(),
            role: this.getRole(),
            tokenExpiry: payload?.exp ? new Date(payload.exp * 1000).toLocaleString() : null,
            hasRefresh: !!this.getRefreshToken(),
            user: this.getUser()
        };
    }
};

// Exportación por defecto para compatibilidad
export default Auth;