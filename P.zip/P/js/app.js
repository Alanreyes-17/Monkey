/**
 * CONTROLADOR PRINCIPAL DE LA APLICACIÓN (Prácticas U1-U3)
 * Orquesta módulos, maneja rutas, eventos y estado global
 * 
 * @module App
 */

import { Auth } from './auth.js';
import { Session } from './session.js';
import { API } from './api.js';
import { Data } from './data.js';
import { UI } from './ui.js';
import { Anim } from './animations.js';
import { Carousel } from './carousel.js';
import { CONFIG } from './config.js';

/**
 * Clase principal que inicializa y controla toda la aplicación
 */
class App {
    constructor() {
        this.captchaAns = 0;
        this.page = this.getCurrentPage();
        this.init();
    }

    /**
     * Detecta la página actual desde la URL
     * @returns {string} Nombre de la página actual
     */
    getCurrentPage() {
        const path = window.location.pathname;
        const file = path.split('/').pop() || 'index.php';
        return file.replace('.php', '');
    }

    /**
     * Inicialización principal de la aplicación
     */
    init() {
        console.time('AppInit');
        
        // 1. Inicialización Global
        UI.updateBreadcrumbs();
        Anim.initScroll();
        Anim.initParallax();
        Anim.initMagnetic();
        UI.applyRBAC();
        
        // 2. Modo Oscuro (persistente y funcional)
        this.initDarkMode();
        
        // 3. Componentes por página
        this.initPageComponents();
        
        // 4. Polling para sincronización (Requisito U2)
        this.startPolling();
        
        console.timeEnd('AppInit');
    }

    /**
     * Inicializa componentes según la página actual
     * @private
     */
    initPageComponents() {
        // Carrusel en homepage
        const hero = document.querySelector('.hero');
        if (hero && this.page === 'index') {
            new Carousel(hero);
        }

        // Página Admin
        if (this.page === 'admin') {
            this.initAdmin();
        }
        
        // Página Reservas
        if (this.page === 'reservas') {
            this.initReservas();
        }
        
        // Página Auth (login, register, recovery)
        if (['login', 'register', 'recovery'].includes(this.page)) {
            this.initAuth();
        }
        
        // Página Settings (multisesiones)
        if (this.page === 'settings') {
            this.initSettings();
        }
        
        // Página Servicios (búsqueda)
        if (this.page === 'servicios') {
            this.initServicios();
        }
        
        // Página Barberos (filtros)
        if (this.page === 'barberos') {
            this.initBarberos();
        }
    }

    // ==================== MODO OSCURO ====================
    initDarkMode() {
        const btn = document.getElementById('theme-toggle');
        if (!btn) return;

        const saved = localStorage.getItem(CONFIG.STORAGE.THEME) || 'dark';
        const isLight = saved === 'light';
        
        document.body.classList.toggle('light', isLight);
        btn.textContent = isLight ? '☀️' : '🌙';

        btn.addEventListener('click', () => {
            const nowLight = document.body.classList.toggle('light');
            localStorage.setItem(CONFIG.STORAGE.THEME, nowLight ? 'light' : 'dark');
            btn.textContent = nowLight ? '☀️' : '🌙';
        });
    }

    // ==================== PÁGINA ADMIN ====================
    initAdmin() {
        this.genCaptcha();
        this.loadTable();
        this.bindAdminEvents();
    }

    bindAdminEvents() {
        const tableBody = document.getElementById('citas-body');
        
        tableBody?.addEventListener('click', (e) => {
            const btn = e.target.closest('button');
            if (!btn) return;
            
            const id = btn.dataset.id;
            const action = btn.dataset.act;
            
            if (action === 'del' && confirm('¿Eliminar este registro?')) {
                Data.delete(id);
                this.loadTable();
                UI.toast('Registro eliminado');
            } else if (action === 'edit') {
                this.fillEditForm(id);
            }
        });

        const form = document.getElementById('cita-form');
        form?.addEventListener('submit', (e) => {
            e.preventDefault();
            
            const captchaInput = document.getElementById('captcha-input');
            if (captchaInput && parseInt(captchaInput.value) !== this.captchaAns) {
                return UI.toast('Verificación incorrecta', 'error');
            }
            
            const id = document.getElementById('cita-id')?.value;
            const data = {
                nombre: document.getElementById('nombre')?.value,
                email: document.getElementById('email')?.value,
                servicio: document.getElementById('servicio')?.value,
                barbero: document.getElementById('barbero')?.value || null
            };
            
            if (id) {
                Data.update(id, data);
                UI.toast('Actualizado correctamente');
            } else {
                Data.add(data);
                UI.toast('Creado correctamente');
            }
            
            form.reset();
            if (document.getElementById('cita-id')) {
                document.getElementById('cita-id').value = '';
            }
            this.loadTable();
            this.genCaptcha();
        });

        const searchInput = document.getElementById('search');
        searchInput?.addEventListener('input', 
            API.debounce(() => this.loadTable(), CONFIG.UI.DEBOUNCE.SEARCH)
        );
        
        document.getElementById('filter-estado')?.addEventListener('change', () => this.loadTable());
        document.getElementById('sort')?.addEventListener('change', () => this.loadTable());
    }

    fillEditForm(id) {
        const cita = Data.getAll().find(c => c.id === id);
        if (!cita) return;
        
        ['cita-id', 'nombre', 'email', 'servicio', 'barbero'].forEach(field => {
            const el = document.getElementById(field);
            if (el && cita[field]) el.value = cita[field];
        });
        
        document.getElementById('cita-form')?.scrollIntoView({ behavior: 'smooth' });
    }

    loadTable() {
        const query = document.getElementById('search')?.value || '';
        const estado = document.getElementById('filter-estado')?.value || 'all';
        const sort = document.getElementById('sort')?.value || '';
        
        const filtered = Data.filter(query, estado, sort);
        UI.renderCitasTable(document.getElementById('citas-body'), filtered);
    }

    // ==================== PÁGINA RESERVAS ====================
    initReservas() {
        this.genCaptcha();
        
        const params = new URLSearchParams(window.location.search);
        const servicio = params.get('servicio');
        const barbero = params.get('barbero');
        
        if (servicio && document.getElementById('servicio')) {
            document.getElementById('servicio').value = servicio;
        }
        if (barbero && document.getElementById('barbero')) {
            document.getElementById('barbero').value = barbero;
        }
        
        this.bindReservaEvents();
    }

    bindReservaEvents() {
        const form = document.getElementById('reserva-form');
        form?.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const validation = UI.validateForm('reserva-form');
            if (!validation.ok) {
                return UI.toast('Revisa los campos del formulario', 'error');
            }
            
            const captchaInput = document.getElementById('captcha-input');
            if (captchaInput && parseInt(captchaInput.value) !== this.captchaAns) {
                return UI.toast('Verificación humana fallida', 'error');
            }
            
            Data.add({
                nombre: document.getElementById('nombre')?.value,
                email: document.getElementById('email')?.value,
                telefono: document.getElementById('telefono')?.value,
                servicio: document.getElementById('servicio')?.value,
                barbero: document.getElementById('barbero')?.value || null
            });
            
            UI.toast('¡Reserva confirmada! Te contactaremos pronto.');
            form.reset();
            this.genCaptcha();
            
            setTimeout(() => {
                window.location.href = 'index.php';
            }, 2000);
        });
    }

    // ==================== PÁGINA AUTH (CORREGIDO Y FUNCIONAL) ====================
    initAuth() {
        // Toggle password visibility
        document.querySelectorAll('.toggle-password').forEach(btn => {
            btn.addEventListener('click', function() {
                const input = this.closest('.password-input')?.querySelector('input') ||
                              this.parentElement.querySelector('input');
                if (input) {
                    input.type = input.type === 'password' ? 'text' : 'password';
                    this.textContent = input.type === 'password' ? '👁️' : '🙈';
                }
            });
        });

        this.bindAuthEvents();
        
        if (this.page === 'recovery') {
            this.initRecoveryFlow();
        }
    }

    bindAuthEvents() {
        // ===== LOGIN =====
        const loginForm = document.getElementById('login-form');
        if (loginForm) {
            loginForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                console.log('🔐 Login submit iniciado'); // Debug
                
                const email = document.getElementById('login-email')?.value.trim();
                const password = document.getElementById('login-password')?.value;
                const msgEl = document.getElementById('login-message');
                
                // Limpiar mensajes previos
                if (msgEl) { msgEl.textContent = ''; msgEl.className = 'auth-message'; }
                
                if (!email || !password) {
                    UI.toast('Completa todos los campos', 'error');
                    if (msgEl) { msgEl.textContent = 'Completa todos los campos'; msgEl.className = 'auth-message error'; }
                    return;
                }
                
                try {
                    // Simulación de login (reemplazar con fetch real)
                    console.log('📡 Enviando login...');
                    await new Promise(res => setTimeout(res, 800));
                    
                    // Credenciales de prueba
                    if (email === 'admin@barbermonkey.com' && password === 'Admin1234') {
                        console.log('✅ Login exitoso (admin)');
                        UI.toast('¡Bienvenido Admin!', 'success');
                        if (msgEl) { msgEl.textContent = '¡Bienvenido! Redirigiendo...'; msgEl.className = 'auth-message success'; }
                        
                        setTimeout(() => {
                            window.location.href = 'admin.php';
                        }, 1000);
                    } else if (email && password.length >= 6) {
                        console.log('✅ Login exitoso (user)');
                        UI.toast('¡Bienvenido!', 'success');
                        if (msgEl) { msgEl.textContent = '¡Bienvenido! Redirigiendo...'; msgEl.className = 'auth-message success'; }
                        
                        setTimeout(() => {
                            window.location.href = 'index.php';
                        }, 1000);
                    } else {
                        console.log('❌ Credenciales incorrectas');
                        UI.toast('Credenciales incorrectas', 'error');
                        if (msgEl) { msgEl.textContent = 'Credenciales incorrectas'; msgEl.className = 'auth-message error'; }
                    }
                } catch (err) {
                    console.error('❌ Error login:', err);
                    UI.toast('Error de conexión', 'error');
                    if (msgEl) { msgEl.textContent = 'Error de conexión'; msgEl.className = 'auth-message error'; }
                }
            });
        }

        // ===== REGISTER =====
        const registerForm = document.getElementById('register-form');
        if (registerForm) {
            registerForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                console.log('📝 Register submit iniciado');
                
                const data = {
                    username: document.getElementById('reg-username')?.value.trim(),
                    fullname: document.getElementById('reg-fullname')?.value.trim(),
                    email: document.getElementById('reg-email')?.value.trim(),
                    phone: document.getElementById('reg-phone')?.value.trim(),
                    password: document.getElementById('reg-password')?.value,
                    confirmPassword: document.getElementById('reg-confirm-password')?.value,
                    terms: document.getElementById('reg-terms')?.checked
                };
                
                const msgEl = document.getElementById('register-message');
                if (msgEl) { msgEl.textContent = ''; msgEl.className = 'auth-message'; }
                
                // Validaciones
                if (!data.username || !data.email || !data.password) {
                    UI.toast('Completa los campos obligatorios', 'error');
                    if (msgEl) { msgEl.textContent = 'Completa los campos obligatorios'; msgEl.className = 'auth-message error'; }
                    return;
                }
                if (!data.terms) {
                    UI.toast('Debes aceptar los términos', 'error');
                    if (msgEl) { msgEl.textContent = 'Debes aceptar los términos'; msgEl.className = 'auth-message error'; }
                    return;
                }
                if (data.password !== data.confirmPassword) {
                    UI.toast('Las contraseñas no coinciden', 'error');
                    if (msgEl) { msgEl.textContent = 'Las contraseñas no coinciden'; msgEl.className = 'auth-message error'; }
                    return;
                }
                if (data.password.length < 8 || !/[A-Za-z]/.test(data.password) || !/\d/.test(data.password)) {
                    UI.toast('La contraseña debe tener 8+ caracteres, 1 letra y 1 número', 'error');
                    if (msgEl) { msgEl.textContent = 'La contraseña no cumple los requisitos'; msgEl.className = 'auth-message error'; }
                    return;
                }
                
                try {
                    console.log('📡 Enviando registro...');
                    await new Promise(res => setTimeout(res, 600));
                    
                    UI.toast('¡Registro exitoso! Inicia sesión.', 'success');
                    if (msgEl) { msgEl.textContent = '¡Cuenta creada! Redirigiendo al login...'; msgEl.className = 'auth-message success'; }
                    
                    setTimeout(() => {
                        window.location.href = 'login.php';
                    }, 1500);
                } catch (err) {
                    console.error('❌ Error registro:', err);
                    UI.toast('Error al registrar', 'error');
                }
            });
        }
    }

    // ===== RECOVERY FLOW (3 PASOS) =====
    initRecoveryFlow() {
        const stepRequest = document.getElementById('step-request');
        const stepVerify = document.getElementById('step-verify');
        const stepPassword = document.getElementById('step-password');
        const msgEl = document.getElementById('recovery-message');
        
        let recoveryEmail = '';

        // Paso 1: Solicitar
        document.getElementById('recovery-request-form')?.addEventListener('submit', async (e) => {
            e.preventDefault();
            const email = document.getElementById('recovery-email')?.value.trim();
            
            if (!email) {
                UI.toast('Ingresa tu correo', 'error');
                return;
            }
            
            console.log('📧 Solicitando recuperación para:', email);
            await new Promise(res => setTimeout(res, 500));
            
            recoveryEmail = email;
            stepRequest.style.display = 'none';
            stepVerify.style.display = 'block';
            UI.toast('Código enviado (prueba: 123456)', 'success');
        });

        // Paso 2: Verificar código
        document.getElementById('recovery-verify-form')?.addEventListener('submit', async (e) => {
            e.preventDefault();
            const code = document.getElementById('recovery-code')?.value.trim();
            
            if (!code || code.length !== 6) {
                UI.toast('Ingresa un código de 6 dígitos', 'error');
                return;
            }
            
            console.log('🔐 Verificando código:', code);
            if (code === '123456') { // Código de prueba
                stepVerify.style.display = 'none';
                stepPassword.style.display = 'block';
                UI.toast('Código verificado', 'success');
            } else {
                UI.toast('Código inválido', 'error');
            }
        });

        // Paso 3: Nueva contraseña
        document.getElementById('recovery-password-form')?.addEventListener('submit', async (e) => {
            e.preventDefault();
            const newPass = document.getElementById('new-password')?.value;
            const confirmPass = document.getElementById('confirm-new-password')?.value;
            
            if (!newPass || !confirmPass) {
                UI.toast('Completa ambas contraseñas', 'error');
                return;
            }
            if (newPass !== confirmPass) {
                UI.toast('Las contraseñas no coinciden', 'error');
                return;
            }
            if (newPass.length < 8 || !/[A-Za-z]/.test(newPass) || !/\d/.test(newPass)) {
                UI.toast('Mínimo 8 caracteres, 1 letra y 1 número', 'error');
                return;
            }
            
            console.log('🔑 Cambiando contraseña...');
            await new Promise(res => setTimeout(res, 500));
            
            UI.toast('Contraseña actualizada', 'success');
            setTimeout(() => {
                window.location.href = 'login.php';
            }, 1500);
        });

        // Navegación entre pasos
        document.getElementById('back-to-request')?.addEventListener('click', () => {
            stepVerify.style.display = 'none';
            stepRequest.style.display = 'block';
            document.getElementById('recovery-code').value = '';
        });

        document.getElementById('back-to-verify')?.addEventListener('click', () => {
            stepPassword.style.display = 'none';
            stepVerify.style.display = 'block';
        });

        document.getElementById('resend-recovery-code')?.addEventListener('click', (e) => {
            e.preventDefault();
            UI.toast('Código reenviado (prueba: 123456)', 'success');
        });
    }

    // ==================== PÁGINA SETTINGS ====================
    initSettings() {
        this.loadSessions();
        this.bindSettingsEvents();
    }

    async loadSessions() {
        try {
            const sessions = await Session.getActive();
            UI.renderSessions(document.getElementById('sessions-body'), sessions);
        } catch (err) {
            UI.toast(err.message || 'Error al cargar sesiones', 'error');
            if (err.message?.includes('No autenticado')) {
                window.location.href = 'login.php';
            }
        }
    }

    bindSettingsEvents() {
        document.getElementById('sessions-body')?.addEventListener('click', async (e) => {
            if (e.target.classList.contains('btn-revoke')) {
                const id = e.target.dataset.id;
                try {
                    await Session.revoke(id);
                    UI.toast('Sesión cerrada');
                    this.loadSessions();
                } catch (err) {
                    UI.toast(err.message, 'error');
                }
            }
        });

        document.getElementById('close-all')?.addEventListener('click', async () => {
            try {
                const res = await Session.revokeAll();
                UI.toast(res.message || 'Sesiones cerradas');
                this.loadSessions();
            } catch (err) {
                UI.toast(err.message, 'error');
            }
        });
    }

    // ==================== SERVICIOS & BARBEROS ====================
    initServicios() {
        const servicios = [
            { nombre: 'Corte de Pelo', descripcion: 'Cortes clásicos y modernos adaptados a tu estilo.', icono: '✂️' },
            { nombre: 'Barba', descripcion: 'Diseño y perfilado con productos premium.', icono: '🧔' },
            { nombre: 'Afeitado', descripcion: 'Experiencia tradicional con navaja y toallas calientes.', icono: '🪒' }
        ];
        
        UI.renderServicios(document.getElementById('servicios-list'), servicios);
        
        const search = document.getElementById('search');
        search?.addEventListener('input', 
            API.debounce(() => {
                UI.renderServicios(document.getElementById('servicios-list'), servicios, search.value);
            }, CONFIG.UI.DEBOUNCE.SEARCH)
        );
    }

    initBarberos() {
        const barberos = [
            { nombre: 'Juan Pérez', especialidad: 'Cortes clásicos', experiencia: 'Más de 10 años', imagen: 'https://via.placeholder.com/200x200?text=Juan' },
            { nombre: 'Pedro García', especialidad: 'Barba y afeitados', experiencia: 'Más de 8 años', imagen: 'https://via.placeholder.com/200x200?text=Pedro' },
            { nombre: 'Carlos López', especialidad: 'Estilos urbanos', experiencia: 'Más de 5 años', imagen: 'https://via.placeholder.com/200x200?text=Carlos' }
        ];
        
        UI.renderBarberos(document.getElementById('barberos-list'), barberos);
        
        const filtro = document.getElementById('filtro-experiencia');
        filtro?.addEventListener('change', () => {
            UI.renderBarberos(document.getElementById('barberos-list'), barberos, filtro.value);
        });
    }

    // ==================== UTILIDADES ====================
    genCaptcha() {
        const a = Math.floor(Math.random() * 9) + 1;
        const b = Math.floor(Math.random() * 9) + 1;
        this.captchaAns = a + b;
        const el = document.getElementById('captcha-q');
        if (el) el.textContent = `Resuelve: ${a} + ${b} = ?`;
    }

    startPolling() {
        if (!CONFIG.FEATURES.POLLING_ENABLED) return;
        
        setInterval(async () => {
            try {
                const sso = await Session.checkSSO();
                if (sso.valid && CONFIG.isDevelopment?.()) {
                    console.log('🔄 SSO Sync OK - User:', sso.userId);
                }
                if (Auth.isAuthenticated()) {
                    await Auth.autoRefresh(60000);
                }
            } catch (err) {
                if (CONFIG.isDevelopment?.()) {
                    console.warn('Polling error:', err.message);
                }
            }
        }, 15000);
    }
}

// ==================== INICIALIZACIÓN ====================
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        window.app = new App();
    });
} else {
    window.app = new App();
}

export default App;