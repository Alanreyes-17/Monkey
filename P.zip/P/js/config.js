/**
 * CONFIGURACIÓN GLOBAL DEL PROYECTO
 * Centraliza constantes, rutas, roles y ajustes de seguridad
 * Prácticas: U1 P2, U2 P1, U2 P2, U3 P1
 * 
 * @module CONFIG
 */

// Detección de entorno (dev/prod)
const isDev = window.location.hostname === 'localhost' || 
              window.location.hostname === '127.0.0.1';

export const CONFIG = {
    
    // ==================== ENTORNO ====================
    ENV: isDev ? 'development' : 'production',
    
    // ==================== RUTAS Y API ====================
    API: {
        BASE_URL: isDev ? 'http://localhost/barbermonkey/server' : '/server',
        ENDPOINTS: {
            AUTH: '/auth.php',
            USERS: '/users.php',
            CITAS: '/citas.php',
            SESSIONS: '/sessions.php',
            RECOVERY: '/recovery.php'
        },
        TIMEOUT: 10000, // 10 segundos
        RETRIES: 3
    },
    
    // ==================== ALMACENAMIENTO LOCAL ====================
    STORAGE: {
        PREFIX: 'bm_', // Prefijo para evitar colisiones
        TOKEN: 'bm_access_token',
        REFRESH: 'bm_refresh_token',
        USER: 'bm_user_data',
        THEME: 'bm_theme',
        CITAS: 'bm_citas',
        SESSIONS: 'bm_sessions',
        CSRF: 'bm_csrf_token',
        TTL: {
            TOKEN: 15 * 60 * 1000,      // 15 min
            REFRESH: 7 * 24 * 60 * 60 * 1000, // 7 días
            CACHE: 5 * 60 * 1000,       // 5 min para caché
            CAPTCHA: 300000              // 5 min para CAPTCHA
        }
    },
    
    // ==================== ROLES Y PERMISOS (RBAC) ====================
    ROLES: {
        ADMIN: {
            id: 1,
            name: 'admin',
            label: 'Administrador',
            permissions: ['read', 'write', 'delete', 'manage_users', 'manage_sessions']
        },
        EDITOR: {
            id: 2,
            name: 'editor', 
            label: 'Editor',
            permissions: ['read', 'write', 'delete']
        },
        USER: {
            id: 3,
            name: 'user',
            label: 'Usuario',
            permissions: ['read']
        }
    },
    
    // ==================== SEGURIDAD ====================
    SECURITY: {
        // Rate limiting: intentos máximos por ventana de tiempo
        RATE_LIMIT: {
            LOGIN: { max: 5, window: 15 * 60 * 1000 },    // 5 intentos en 15 min
            REGISTER: { max: 3, window: 60 * 60 * 1000 },  // 3 registros por hora
            RECOVERY: { max: 3, window: 60 * 60 * 1000 }   // 3 recuperaciones por hora
        },
        // Password policy
        PASSWORD: {
            MIN_LENGTH: 8,
            REQUIRE_UPPERCASE: true,
            REQUIRE_LOWERCASE: true,
            REQUIRE_NUMBER: true,
            REQUIRE_SPECIAL: false
        },
        // Headers de seguridad (para inyectar en fetch)
        HEADERS: {
            'X-Content-Type-Options': 'nosniff',
            'X-Frame-Options': 'DENY',
            'X-XSS-Protection': '1; mode=block'
        }
    },
    
    // ==================== UI Y EXPERIENCIA ====================
    UI: {
        // Animaciones
        ANIMATIONS: {
            DURATION: 300, // ms
            EASING: 'ease-out',
            SCROLL_THRESHOLD: 0.15 // Para IntersectionObserver
        },
        // Toast messages
        TOAST: {
            DURATION: 3000, // ms
            POSITION: 'top-right'
        },
        // Debounce/Throttle
        DEBOUNCE: {
            SEARCH: 300,    // ms para búsqueda
            INPUT: 200,     // ms para validación en tiempo real
            SCROLL: 100     // ms para eventos de scroll
        },
        THROTTLE: {
            RESIZE: 250,
            SCROLL: 150
        }
    },
    
    // ==================== FUNCIONALIDADES OPCIONALES ====================
    FEATURES: {
        MFA_ENABLED: true,           // Autenticación multifactor
        SSO_ENABLED: false,          // Single Sign-On (simulado)
        DARK_MODE: true,             // Toggle modo oscuro
        POLLING_ENABLED: true,       // Actualización en tiempo real
        EXPORT_ENABLED: true,        // Exportar datos a JSON
        CAPTCHA_ENABLED: true        // Verificación humana
    },
    
    // ==================== UTILIDADES ====================
    
    /**
     * Obtiene URL completa para endpoint
     * @param {string} endpoint - Clave del endpoint (ej: 'AUTH')
     * @returns {string} URL completa
     */
    getApiUrl(endpoint) {
        return `${this.API.BASE_URL}${this.API.ENDPOINTS[endpoint] || endpoint}`;
    },
    
    /**
     * Verifica si un rol tiene permiso específico
     * @param {string} roleName - Nombre del rol ('admin', 'editor', 'user')
     * @param {string} permission - Permiso a verificar ('read', 'write', etc.)
     * @returns {boolean} True si tiene permiso
     */
    hasPermission(roleName, permission) {
        const role = Object.values(this.ROLES).find(r => r.name === roleName);
        return role?.permissions.includes(permission) || false;
    },
    
    /**
     * Obtiene prefijo para claves de almacenamiento
     * @param {string} key - Clave sin prefijo
     * @returns {string} Clave con prefijo
     */
    storageKey(key) {
        return `${this.STORAGE.PREFIX}${key}`;
    },
    
    /**
     * Verifica si estamos en modo desarrollo
     * @returns {boolean}
     */
    isDevelopment() {
        return this.ENV === 'development';
    }
};

// Exportación por defecto para compatibilidad
export default CONFIG;