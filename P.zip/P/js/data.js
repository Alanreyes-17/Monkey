/**
 * MÓDULO DE DATOS - MODELO (Práctica 1 U2 + U3)
 * Gestiona CRUD de citas con LocalStorage, filtros, búsqueda y CAPTCHA
 * 
 * @module Data
 */

import { CONFIG } from './config.js';

// Clave única para LocalStorage (centralizada en CONFIG)
const STORAGE_KEY = CONFIG.STORAGE.CITAS;

/**
 * Objeto Data con métodos estáticos para operaciones CRUD
 */
export const Data = {

    /**
     * Obtiene todas las citas desde LocalStorage
     * @returns {Array} Lista de citas
     */
    getAll() {
        try {
            const raw = localStorage.getItem(STORAGE_KEY);
            return raw ? JSON.parse(raw) : [];
        } catch (err) {
            console.error('Error al leer citas:', err);
            return [];
        }
    },

    /**
     * Guarda la lista completa de citas en LocalStorage
     * @param {Array} data - Lista de citas a guardar
     */
    save(data) {
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
        } catch (err) {
            console.error('Error al guardar citas:', err);
        }
    },

    /**
     * Agrega una nueva cita
     * @param {Object} item - Datos de la cita (sin id)
     * @returns {Object} La cita creada con id generado
     */
    add(item) {
        const list = this.getAll();
        
        // Generar ID único basado en timestamp
        item.id = Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
        item.estado = item.estado || 'Pendiente';
        item.fecha = item.fecha || new Date().toLocaleDateString('es-MX');
        item.createdAt = item.createdAt || new Date().toISOString();
        
        list.push(item);
        this.save(list);
        return item;
    },

    /**
     * Actualiza una cita existente por ID
     * @param {string} id - ID de la cita a actualizar
     * @param {Object} updates - Campos a actualizar
     * @returns {Object|null} La cita actualizada o null si no se encontró
     */
    update(id, updates) {
        const list = this.getAll();
        const idx = list.findIndex(c => c.id === id);
        
        if (idx !== -1) {
            // Mantener campos que no se están actualizando
            list[idx] = { ...list[idx], ...updates, id }; 
            this.save(list);
            return list[idx];
        }
        return null;
    },

    /**
     * Elimina una cita por ID
     * @param {string} id - ID de la cita a eliminar
     * @returns {boolean} True si se eliminó, false si no existía
     */
    delete(id) {
        const before = this.getAll().length;
        const list = this.getAll().filter(c => c.id !== id);
        
        if (list.length < before) {
            this.save(list);
            return true;
        }
        return false;
    },

    /**
     * Busca y filtra citas con múltiples criterios
     * @param {string} query - Texto de búsqueda (nombre o servicio)
     * @param {string} estado - Filtro por estado ('all', 'Pendiente', 'Completado')
     * @param {string} sort - Ordenamiento ('A-Z', 'Z-A', 'fecha')
     * @returns {Array} Resultados filtrados y ordenados
     */
    filter(query = '', estado = 'all', sort = '') {
        let results = this.getAll();

        // Búsqueda por texto (case-insensitive)
        if (query && query.trim() !== '') {
            const q = query.toLowerCase().trim();
            results = results.filter(c => 
                c.nombre?.toLowerCase().includes(q) || 
                c.email?.toLowerCase().includes(q) || 
                c.servicio?.toLowerCase().includes(q) ||
                c.barbero?.toLowerCase().includes(q)
            );
        }

        // Filtro por estado
        if (estado && estado !== 'all') {
            results = results.filter(c => c.estado === estado);
        }

        // Ordenamiento
        if (sort === 'A-Z') {
            results.sort((a, b) => (a.nombre || '').localeCompare(b.nombre || '', 'es'));
        } else if (sort === 'Z-A') {
            results.sort((a, b) => (b.nombre || '').localeCompare(a.nombre || '', 'es'));
        } else if (sort === 'fecha') {
            // Ordenar por ID (timestamp) descendente = más reciente primero
            results.sort((a, b) => parseInt(b.id) - parseInt(a.id));
        }

        return results;
    },

    /**
     * Obtiene una cita específica por ID
     * @param {string} id - ID de la cita
     * @returns {Object|undefined} La cita encontrada o undefined
     */
    getById(id) {
        return this.getAll().find(c => c.id === id);
    },

    /**
     * Genera un CAPTCHA matemático simple (desafío-respuesta)
     * @returns {Object} { question: string, answer: number }
     */
    generateCaptcha() {
        const a = Math.floor(Math.random() * 9) + 1; // 1-9
        const b = Math.floor(Math.random() * 9) + 1;
        const operations = [
            { op: '+', fn: (x, y) => x + y },
            { op: '-', fn: (x, y) => x - y },
            { op: '*', fn: (x, y) => x * y }
        ];
        const { op, fn } = operations[Math.floor(Math.random() * operations.length)];
        
        // Asegurar que la resta no dé negativo
        const [val1, val2] = op === '-' && a < b ? [b, a] : [a, b];
        
        return {
            question: `Resuelve: ${val1} ${op} ${val2} = ?`,
            answer: fn(val1, val2)
        };
    },

    /**
     * Limpia todas las citas (útil para pruebas o reset)
     * @returns {number} Número de elementos eliminados
     */
    clearAll() {
        const count = this.getAll().length;
        localStorage.removeItem(STORAGE_KEY);
        return count;
    },

    /**
     * Exporta citas a formato JSON para descarga
     * @returns {string} JSON stringified
     */
    exportToJSON() {
        return JSON.stringify(this.getAll(), null, 2);
    },

    /**
     * Importa citas desde JSON string
     * @param {string} jsonString - Datos en formato JSON
     * @returns {number} Número de citas importadas
     */
    importFromJSON(jsonString) {
        try {
            const imported = JSON.parse(jsonString);
            if (Array.isArray(imported)) {
                this.save(imported);
                return imported.length;
            }
            return 0;
        } catch (err) {
            console.error('Error al importar JSON:', err);
            return -1;
        }
    }
};

// Exportación por defecto para compatibilidad
export default Data;