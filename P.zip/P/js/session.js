/**
 * MÓDULO DE GESTIÓN DE MULTISESIONES (Práctica 1 U3)
 * Maneja sesiones activas, revocación, SSO y seguridad
 * 
 * @module Session
 */

import { CONFIG } from './config.js';
import { Auth } from './auth.js';

// Estado local para simulación (en producción, esto viene del backend)
let _sessions = [
    { id: 's1', ip: '192.168.1.50', agent: 'Chrome / Windows', date: '2026-04-14 10:00', active: true, current: true },
    { id: 's2', ip: '10.0.0.12', agent: 'Safari / iPhone', date: '2026-04-14 08:30', active: true, current: false }
];

// Rate limiting simple para prevenir abuso
const _rateLimit = { attempts: 0, lastAttempt: 0, maxAttempts: 5, window: 60000 };

export const Session = {

    /**
     * Verifica si el usuario está autenticado antes de operar
     * @private
     * @returns {boolean}
     */
    _isAuthenticated() {
        return Auth.isAuthenticated();
    },

    /**
     * Verifica límite de intentos (prevención de fuerza bruta)
     * @private
     * @returns {boolean} True si está bloqueado
     */
    _isRateLimited() {
        const now = Date.now();
        if (now - _rateLimit.lastAttempt > _rateLimit.window) {
            _rateLimit.attempts = 0;
        }
        _rateLimit.lastAttempt = now;
        _rateLimit.attempts++;
        return _rateLimit.attempts > _rateLimit.maxAttempts;
    },

    /**
     * Obtiene sesiones activas del usuario
     * @async
     * @returns {Promise<Array>} Lista de sesiones activas
     * @throws {Error} Si no está autenticado o hay error de red
     */
    async getActive() {
        if (!this._isAuthenticated()) {
            throw new Error('No autenticado');
        }
        
        if (this._isRateLimited()) {
            throw new Error('Demasiados intentos. Espera un minuto.');
        }

        // Simulación de llamada a API con delay realista
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                try {
                    // En producción: fetch('/api/sessions', { headers: { Authorization: `Bearer ${token}` } })
                    const activeSessions = _sessions.filter(s => s.active);
                    resolve(activeSessions);
                } catch (err) {
                    reject(new Error('Error al obtener sesiones: ' + err.message));
                }
            }, 300);
        });
    },

    /**
     * Revoca una sesión específica por ID
     * @async
     * @param {string} sessionId - ID de la sesión a revocar
     * @returns {Promise<Object>} Resultado de la operación
     * @throws {Error} Si la sesión no existe o no está autenticado
     */
    async revoke(sessionId) {
        if (!this._isAuthenticated()) {
            throw new Error('No autenticado');
        }

        if (this._isRateLimited()) {
            throw new Error('Demasiados intentos. Espera un minuto.');
        }

        return new Promise((resolve, reject) => {
            setTimeout(() => {
                try {
                    const session = _sessions.find(s => s.id === sessionId);
                    
                    if (!session) {
                        reject(new Error('Sesión no encontrada'));
                        return;
                    }

                    // No permitir cerrar la sesión actual desde esta interfaz
                    if (session.current) {
                        reject(new Error('No puedes cerrar tu sesión actual desde aquí'));
                        return;
                    }

                    session.active = false;
                    
                    // En producción: fetch(`/api/sessions/${sessionId}/revoke`, { method: 'POST', ... })
                    
                    resolve({ ok: true, message: 'Sesión cerrada correctamente' });
                } catch (err) {
                    reject(new Error('Error al revocar sesión: ' + err.message));
                }
            }, 250);
        });
    },

    /**
     * Revoca todas las sesiones excepto la actual
     * @async
     * @returns {Promise<Object>} Resultado con contador de sesiones cerradas
     * @throws {Error} Si hay error en la operación
     */
    async revokeAll() {
        if (!this._isAuthenticated()) {
            throw new Error('No autenticado');
        }

        if (this._isRateLimited()) {
            throw new Error('Demasiados intentos. Espera un minuto.');
        }

        return new Promise((resolve, reject) => {
            setTimeout(() => {
                try {
                    let closedCount = 0;
                    
                    _sessions.forEach(session => {
                        if (!session.current && session.active) {
                            session.active = false;
                            closedCount++;
                        }
                    });

                    // En producción: fetch('/api/sessions/revoke-all', { method: 'POST', ... })
                    
                    resolve({ 
                        ok: true, 
                        message: `${closedCount} sesión(es) cerrada(s)`,
                        closedCount 
                    });
                } catch (err) {
                    reject(new Error('Error al cerrar sesiones: ' + err.message));
                }
            }, 300);
        });
    },

    /**
     * Verifica Single Sign-On (SSO) simulado
     * @async
     * @returns {Promise<Object>} Estado de validez del SSO
     */
    async checkSSO() {
        const token = localStorage.getItem(CONFIG.STORAGE.TOKEN);
        
        if (!token) {
            return { valid: false, reason: 'No hay token de acceso' };
        }

        // Verificar expiración del token (simulado)
        try {
            const payload = JSON.parse(atob(token.split('.')[1]));
            const isExpired = payload.exp * 1000 < Date.now();
            
            if (isExpired) {
                return { valid: false, reason: 'Token expirado' };
            }
            
            return { 
                valid: true, 
                userId: payload.id,
                role: payload.role,
                source: 'AppA' // Simula origen del SSO
            };
        } catch {
            return { valid: false, reason: 'Token inválido' };
        }
    },

    /**
     * Agrega una nueva sesión (para simulación de login desde otro dispositivo)
     * @param {Object} sessionData - Datos de la nueva sesión
     * @returns {Object} Sesión creada
     * @private - Solo para pruebas internas
     */
    _addSession(sessionData) {
        const newSession = {
            id: 's' + (Date.now().toString(36)),
            ip: sessionData.ip || '0.0.0.0',
            agent: sessionData.agent || 'Unknown',
            date: new Date().toLocaleString(),
            active: true,
            current: false,
            ...sessionData
        };
        _sessions.push(newSession);
        return newSession;
    },

    /**
     * Limpia sesiones expiradas (mantenimiento)
     * @private
     */
    _cleanupExpired() {
        const now = Date.now();
        _sessions = _sessions.filter(s => {
            // En producción, verificar contra expires_at de la BD
            return s.active;
        });
    }
};

// Limpieza periódica de sesiones (cada 5 min en producción)
setInterval(() => Session._cleanupExpired(), 300000);