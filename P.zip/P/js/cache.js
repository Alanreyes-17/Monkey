import cache from './js/cache.js';

// === GUARDAR DATOS ===
// Con TTL por defecto (5 min desde CONFIG)
cache.set('users_list', [{ id: 1, name: 'Juan' }]);

// Con TTL personalizado (30 segundos)
cache.set('search_results', results, 30000);

// === OBTENER DATOS ===
const users = cache.get('users_list');
if (users) {
    console.log('Datos del caché:', users);
} else {
    // Cache miss: obtener de API y guardar
    const freshData = await fetchUsers();
    cache.set('users_list', freshData);
}

// === VERIFICAR EXISTENCIA ===
if (cache.has('users_list')) {
    console.log('Los usuarios están en caché');
}

// === ESTADÍSTICAS (para debugging) ===
console.log(cache.getStats());
// Output: { hits: 5, misses: 2, sets: 10, deletes: 1, size: 8, hitRate: '71.43%', keys: [...] }

// === INFORMACIÓN DETALLADA ===
console.log(cache.info('users_list'));
// Output: { key: 'users_list', value: [...], createdAt: 123456, expiry: 123756, remaining: 20000, isExpired: false }

// === ELIMINAR ===
cache.delete('users_list'); // Una entrada
cache.clear(); // Todo el caché

// === LIMPIEZA MANUAL ===
const removed = cache.prune(); // Elimina expirados, retorna contador
console.log(`${removed} entradas eliminadas`);