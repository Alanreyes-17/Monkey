<?php
session_start();
require_once __DIR__ . '/server/config.php';

if (!isset($_SESSION['user_id']) && !isset($_COOKIE['access_token'])) {
    header('Location: /P/login.php');
    exit;
}

$userId = $_SESSION['user_id'] ?? null;
if (!$userId && isset($_COOKIE['access_token'])) {
    require_once __DIR__ . '/server/services/JWTService.php';
    $payload = JWTService::decode($_COOKIE['access_token']);
    $userId = $payload['id'] ?? null;
}

// Obtener datos del usuario
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch();

$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrfToken = $_POST['csrf_token'] ?? '';
    if (!verifyCsrfToken($csrfToken)) {
        $message = 'Token CSRF inválido';
        $messageType = 'error';
    } else {
        $action = $_POST['action'] ?? '';
        
        if ($action === 'update_profile') {
            $fullName = trim($_POST['full_name'] ?? '');
            $phone = trim($_POST['phone'] ?? '');
            
            try {
                $stmt = $pdo->prepare("UPDATE users SET full_name = ?, phone = ?, updated_at = NOW() WHERE id = ?");
                $stmt->execute([$fullName, $phone, $userId]);
                $message = '✅ Perfil actualizado correctamente';
                $messageType = 'success';
                // Recargar datos
                $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
                $stmt->execute([$userId]);
                $user = $stmt->fetch();
            } catch (PDOException $e) {
                $message = 'Error al actualizar';
                $messageType = 'error';
            }
        } elseif ($action === 'change_password') {
            $currentPassword = $_POST['current_password'] ?? '';
            $newPassword = $_POST['new_password'] ?? '';
            $confirmPassword = $_POST['confirm_password'] ?? '';
            
            if (!password_verify($currentPassword, $user['password_hash'])) {
                $message = 'Contraseña actual incorrecta';
                $messageType = 'error';
            } elseif ($newPassword !== $confirmPassword) {
                $message = 'Las nuevas contraseñas no coinciden';
                $messageType = 'error';
            } elseif (strlen($newPassword) < 8) {
                $message = 'La contraseña debe tener al menos 8 caracteres';
                $messageType = 'error';
            } else {
                $passwordHash = password_hash($newPassword, PASSWORD_BCRYPT);
                try {
                    $stmt = $pdo->prepare("UPDATE users SET password_hash = ?, updated_at = NOW() WHERE id = ?");
                    $stmt->execute([$passwordHash, $userId]);
                    $message = '✅ Contraseña actualizada correctamente';
                    $messageType = 'success';
                } catch (PDOException $e) {
                    $message = 'Error al actualizar contraseña';
                    $messageType = 'error';
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?= generateCsrfToken() ?>">
    <title>Mi Perfil - BarberMonkey</title>
    <style>
        body { background: #121212; color: #e0e0e0; font-family: system-ui, sans-serif; margin: 0; }
        .header { background: #1e1e1e; padding: 1rem 2rem; border-bottom: 2px solid #d4af37; display: flex; justify-content: space-between; align-items: center; }
        .logo { color: #d4af37; font-size: 1.5rem; font-weight: bold; text-decoration: none; }
        .container { max-width: 800px; margin: 2rem auto; padding: 2rem; background: #1e1e1e; border-radius: 16px; }
        h1 { color: #d4af37; margin-bottom: 1.5rem; }
        h2 { color: #d4af37; margin: 2rem 0 1rem; font-size: 1.3rem; }
        .form-group { margin-bottom: 1.5rem; }
        label { display: block; margin-bottom: 0.5rem; font-weight: 500; }
        input { width: 100%; padding: 0.8rem; border-radius: 4px; border: 1px solid #444; background: #2a2a2a; color: #e0e0e0; }
        input:disabled { opacity: 0.6; cursor: not-allowed; }
        .btn { padding: 1rem 2rem; background: #d4af37; color: #000; border: none; border-radius: 8px; font-weight: bold; cursor: pointer; }
        .btn:hover { opacity: 0.9; }
        .message { padding: 1rem; border-radius: 8px; margin-bottom: 1rem; }
        .message.success { background: #81c784; color: #000; }
        .message.error { background: #e57373; color: #fff; }
        .user-info { background: #2a2a2a; padding: 1.5rem; border-radius: 12px; margin-bottom: 2rem; }
    </style>
</head>
<body>
    <header class="header">
        <a href="/P/dashboard/user.php" class="logo">🐒 BarberMonkey</a>
        <a href="/P/dashboard/user.php" style="color:#e0e0e0;text-decoration:none;">← Volver</a>
    </header>

    <div class="container">
        <h1>👤 Mi Perfil</h1>

        <?php if ($message): ?>
            <div class="message <?= $messageType ?>"><?= $message ?></div>
        <?php endif; ?>

        <div class="user-info">
            <h3>Información de Cuenta</h3>
            <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
            <p><strong>Usuario:</strong> <?= htmlspecialchars($user['username']) ?></p>
            <p><strong>Miembro desde:</strong> <?= date('d/m/Y', strtotime($user['created_at'])) ?></p>
        </div>

        <h2>✏️ Editar Información</h2>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
            <input type="hidden" name="action" value="update_profile">
            
            <div class="form-group">
                <label>Nombre Completo</label>
                <input type="text" name="full_name" value="<?= htmlspecialchars($user['full_name'] ?? '') ?>">
            </div>
            
            <div class="form-group">
                <label>Teléfono</label>
                <input type="tel" name="phone" value="<?= htmlspecialchars($user['phone'] ?? '') ?>">
            </div>
            
            <div class="form-group">
                <label>Correo Electrónico</label>
                <input type="email" value="<?= htmlspecialchars($user['email']) ?>" disabled>
                <small style="color:#888;">El correo no se puede cambiar</small>
            </div>

            <button type="submit" class="btn">💾 Guardar Cambios</button>
        </form>

        <h2>🔐 Cambiar Contraseña</h2>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
            <input type="hidden" name="action" value="change_password">
            
            <div class="form-group">
                <label>Contraseña Actual</label>
                <input type="password" name="current_password" required>
            </div>
            
            <div class="form-group">
                <label>Nueva Contraseña</label>
                <input type="password" name="new_password" required minlength="8">
            </div>
            
            <div class="form-group">
                <label>Confirmar Nueva Contraseña</label>
                <input type="password" name="confirm_password" required minlength="8">
            </div>

            <button type="submit" class="btn">🔑 Actualizar Contraseña</button>
        </form>
    </div>
</body>
</html>