<?php
$page = 'register';
// No requerir config.php temporalmente para evitar errores
require_once __DIR__ . '/server/config.php'; 
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro - BarberMonkey</title>

    <style>
        body {
            background: #121212;
            color: #e0e0e0;
            font-family: system-ui, sans-serif;
            margin: 0;
            padding: 0;
        }

        .auth-page {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
        }

        .auth-container {
            width: 100%;
            max-width: 500px;
        }

        .auth-card {
            background: #1e1e1e;
            padding: 2.5rem;
            border-radius: 16px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
        }

        .logo {
            font-size: 2rem;
            font-weight: bold;
            color: #d4af37;
            text-decoration: none;
            display: block;
            text-align: center;
            margin-bottom: 2rem;
        }

        .auth-header {
            text-align: center;
            margin-bottom: 2rem;
        }

        .auth-header h1 {
            color: #d4af37;
            margin: 1rem 0 0.5rem;
        }

        .auth-header p {
            color: #888;
        }

        .form-group {
            margin-bottom: 1.2rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
        }

        .form-group input {
            width: 100%;
            padding: 0.8rem;
            border-radius: 4px;
            border: 1px solid #444;
            background: #2a2a2a;
            color: #e0e0e0;
            font-size: 1rem;
            box-sizing: border-box;
        }

        .form-group input:focus {
            outline: none;
            border-color: #d4af37;
        }

        .btn {
            width: 100%;
            padding: 1rem;
            background: #d4af37;
            color: #000;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            font-size: 1.1rem;
        }

        .btn:hover {
            opacity: 0.9;
        }

        .auth-footer {
            text-align: center;
            margin-top: 1.5rem;
            color: #888;
        }

        .auth-footer a {
            color: #d4af37;
            text-decoration: none;
        }

        #msg {
            margin-top: 1rem;
            padding: 1rem;
            border-radius: 8px;
            text-align: center;
            display: none;
        }

        #msg.success {
            background: #81c784;
            color: #000;
            display: block;
        }

        #msg.error {
            background: #e57373;
            color: #fff;
            display: block;
        }
    </style>
</head>

<body class="auth-page">
    <div class="auth-container">
        <div class="auth-card">
            <a href="index.php" class="logo">🐒 BarberMonkey</a>

            <div class="auth-header">
                <h1>Crear Cuenta</h1>
                <p>Únete y agenda tus citas fácilmente</p>
            </div>

            <form id="register-form">
                <div class="form-group">
                    <label>Nombre de Usuario *</label>
                    <input type="text" id="reg-username" required placeholder="usuario123">
                </div>

                <div class="form-group">
                    <label>Nombre Completo *</label>
                    <input type="text" id="reg-fullname" required placeholder="Juan Pérez">
                </div>

                <div class="form-group">
                    <label>Correo Electrónico *</label>
                    <input type="email" id="reg-email" required placeholder="tu@email.com">
                </div>

                <div class="form-group">
                    <label>Teléfono *</label>
                    <input type="tel" id="reg-phone" required placeholder="10 dígitos">
                </div>

                <div class="form-group">
                    <label>Contraseña *</label>
                    <input type="password" id="reg-password" required minlength="8" placeholder="••••••••">
                    <small style="color:#888;font-size:0.8rem;">Mínimo 8 caracteres, 1 letra y 1 número</small>
                </div>

                <div class="form-group">
                    <label>Confirmar Contraseña *</label>
                    <input type="password" id="reg-confirm-password" required placeholder="••••••••">
                </div>

                <div class="form-group">
                    <label style="display:flex;align-items:center;gap:0.5rem;cursor:pointer;">
                        <input type="checkbox" id="reg-terms" required>
                        <span style="font-size:0.9rem;">Acepto términos y condiciones</span>
                    </label>
                </div>

                <button type="submit" class="btn">✅ Crear Cuenta</button>
            </form>

            <p class="auth-footer">
                ¿Ya tienes cuenta? <a href="login.php">Inicia sesión</a>
            </p>

            <div id="msg"></div>
        </div>
    </div>

    <script>
        console.log('📝 Register v4.1 - Nombres consistentes snake_case');

        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('register-form');
            const msgEl = document.getElementById('msg');

            if (!form) return console.error('❌ Formulario NO encontrado');

            form.addEventListener('submit', async function(e) {
                e.preventDefault();

                if (msgEl) {
                    msgEl.textContent = '';
                    msgEl.className = '';
                    msgEl.style.display = 'none';
                }

                // ✅ SE ACTUALIZÓ 'confirmPassword' a 'confirm_password'
                const data = {
                    username: document.getElementById('reg-username')?.value.trim(),
                    fullname: document.getElementById('reg-fullname')?.value.trim(),
                    email: document.getElementById('reg-email')?.value.trim(),
                    phone: document.getElementById('reg-phone')?.value.trim(),
                    password: document.getElementById('reg-password')?.value,
                    confirm_password: document.getElementById('reg-confirm-password')?.value,
                    terms: document.getElementById('reg-terms')?.checked
                };

                console.log('📤 Datos:', data);

                // Validaciones frontend
                if (!data.username || !data.email || !data.password) {
                    return showError('Completa los campos obligatorios');
                }

                // ✅ SE ACTUALIZÓ LA VALIDACIÓN PARA USAR 'confirm_password'
                if (data.password !== data.confirm_password) {
                    return showError('Las contraseñas no coinciden');
                }

                if (!data.terms) {
                    return showError('Debes aceptar los términos');
                }

                const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
                const apiUrl = '/P/server/api.php?route=auth/register';

                try {
                    console.log('📡 POST', apiUrl);

                    const response = await fetch(apiUrl, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-Token': csrfToken
                        },
                        body: JSON.stringify(data),
                        credentials: 'same-origin'
                    });

                    const rawText = await response.text();
                    console.log('📥 Status:', response.status);
                    console.log('📥 Raw:', rawText.substring(0, 200));

                    let result;
                    try {
                        result = JSON.parse(rawText);
                    } catch (parseErr) {
                        console.error('❌ JSON parse failed:', parseErr);
                        return showError('Respuesta inválida del servidor');
                    }

                    if (response.status === 429) {
                        const mins = Math.ceil((result.retry_after || 0) / 60);
                        return showError(`🛡️ Espera ${mins} minutos`);
                    }

                    if (!result.success) {
                        return showError(result.error || result.message || `Error ${response.status}`);
                    }

                    showSuccess(result.message || '¡Cuenta creada!');
                    setTimeout(() => {
                        window.location.href = result.redirect || '/P/login.php';
                    }, 1500);

                } catch (err) {
                    console.error('❌ Fetch error:', err);
                    showError('Error de conexión: ' + err.message);
                }
            });

            function showError(msg) {
                if (msgEl) {
                    msgEl.innerHTML = '❌ ' + msg;
                    msgEl.className = 'error';
                    msgEl.style.cssText = 'display:block;background:#e57373;color:#fff;padding:1rem;border-radius:8px;margin-top:1rem;text-align:center;';
                }
            }

            function showSuccess(msg) {
                if (msgEl) {
                    msgEl.textContent = '✅ ' + msg;
                    msgEl.className = 'success';
                    msgEl.style.cssText = 'display:block;background:#81c784;color:#000;padding:1rem;border-radius:8px;margin-top:1rem;text-align:center;';
                }
            }
            
        });
    </script>
</body>

</html>